"""Five active-parameter ablations built from the existing implementation."""
from __future__ import annotations

import random

import numpy as np
import torch
from torch import nn

from .common import VARIANTS


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.use_deterministic_algorithms(True, warn_only=True)


class ExperimentModel(nn.Module):
    def __init__(self, variant, seed=42, pretrained=True, dropout=.3,
                 backbone="vit_base_patch16_224", encoder_factory=None):
        super().__init__()
        if variant not in VARIANTS:
            raise ValueError(f"Unknown experiment variant: {variant}")
        from training_model.models.favit_cnn import CNN_feature_extractor_branch
        from training_model.models.redesigned_favit import RedesignedFAViT
        self.variant = variant
        if variant != "cnn_only":
            # Restore RNG on exit: the same seed produces the exact same encoder
            # independent of whether a different head or extra branch is created.
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(seed)
                if encoder_factory:
                    self.encoder = encoder_factory()
                else:
                    self.encoder = RedesignedFAViT(backbone_name=backbone, pretrained=pretrained)
                self.encoder.classifier = nn.Identity()
        if variant in ("cnn_only", "favit_cnn"):
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(seed + 100_000)
                self.cnn = CNN_feature_extractor_branch(3, 128)
        dim = 128 if variant == "cnn_only" else 896 if variant == "favit_cnn" else 768
        if variant == "favit_capacity":
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(seed + 300_000)
                self.capacity = nn.Sequential(nn.Linear(768, 168), nn.GELU(), nn.Linear(168, 768))
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed + 200_000)
            self.classifier = nn.Linear(dim, 1) if variant == "favit_linear" else nn.Sequential(
                nn.LayerNorm(dim), nn.Dropout(dropout), nn.Linear(dim, 1))

    def train(self, mode=True):
        super().train(mode)
        # Frozen pretrained weights stay in inference mode; gradients still flow
        # THROUGH the backbone to the trainable adapters (no no_grad wrapper).
        if hasattr(self, "encoder"):
            self.encoder.vit.eval()
        return self

    def forward(self, images):
        if self.variant == "cnn_only":
            features = self.cnn(images)
        else:
            _, features = self.encoder(images)
            if self.variant == "favit_cnn":
                features = torch.cat((features, self.cnn(images)), dim=1)
            elif self.variant == "favit_capacity":
                features = features + self.capacity(features)
        return self.classifier(features).flatten()


def build_experiment_model(variant, config, seed, pretrained=None, encoder_factory=None):
    training = config["training"]
    return ExperimentModel(variant, seed, training.get("pretrained", True) if pretrained is None else pretrained,
                           float(training.get("head_dropout", .3)), training.get("backbone", "vit_base_patch16_224"),
                           encoder_factory=encoder_factory)


def parameter_counts(model):
    return {"trainable": sum(p.numel() for p in model.parameters() if p.requires_grad),
            "total": sum(p.numel() for p in model.parameters())}


def encoder_hash(model):
    import hashlib
    if not hasattr(model, "encoder"):
        return None
    result = hashlib.sha256()
    for name, value in model.encoder.state_dict().items():
        result.update(name.encode())
        result.update(value.detach().cpu().contiguous().numpy().tobytes())
    return result.hexdigest()
