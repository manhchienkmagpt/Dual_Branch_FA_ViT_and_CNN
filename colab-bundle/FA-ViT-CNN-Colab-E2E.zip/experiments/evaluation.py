"""Prediction coverage, paired comparisons, and measured-only report generation."""
from __future__ import annotations

from collections import defaultdict
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm, rankdata
from sklearn.metrics import roc_auc_score
import torch

from .cache import dataset_hash, materialize
from .common import DATASETS, VARIANTS, atomic_json, clean_json, paths, read_json, sha256
from .models import build_experiment_model
from .training import loader_for, precision_context, runtime_settings


def checked_predictions(frame):
    required = {"dataset", "video_id", "crop_path", "label", "probability", "group_id", "grouping_verified", "method"}
    if not required.issubset(frame):
        raise ValueError("Prediction file lacks manifest metadata")
    if frame.empty or frame["crop_path"].duplicated().any():
        raise ValueError("Empty or duplicated crop predictions")
    if not frame.label.isin([0, 1]).all() or not np.isfinite(frame.probability).all() or not frame.probability.between(0, 1).all():
        raise ValueError("Invalid prediction labels/probabilities")
    return frame


def aggregate_videos(frame, aggregation="mean"):
    frame = checked_predictions(frame)
    if aggregation not in ("mean", "median"):
        raise ValueError("Unknown aggregation")
    metadata = ["dataset", "method", "label", "group_id", "grouping_verified"]
    grouped = frame.groupby("video_id", sort=True)
    if any((grouped[column].nunique(dropna=False) != 1).any() for column in metadata):
        raise ValueError("Video metadata/labels differ between its frames")
    output = grouped[metadata].first()
    output["probability"] = grouped.probability.agg(aggregation)
    output["frames"] = grouped.size()
    return output.reset_index()


def paired(left, right, key):
    if left[key].duplicated().any() or right[key].duplicated().any():
        raise ValueError("Duplicate prediction IDs in paired comparison")
    if set(left[key]) != set(right[key]):
        raise ValueError("Models have different test memberships; refusing an inner-join comparison")
    left, right = left.sort_values(key).reset_index(drop=True), right.sort_values(key).reset_index(drop=True)
    for field in ("label", "group_id", "grouping_verified", "dataset", "method", "video_id", "frame_index"):
        if field not in left or field not in right:
            continue
        if not left[field].equals(right[field]):
            raise ValueError(f"Paired prediction metadata mismatch: {field}")
    return left, right


def ensemble(left, right):
    left, right = paired(checked_predictions(left), checked_predictions(right), "crop_path")
    result = left.copy()
    result["probability"] = (left.probability.to_numpy() + right.probability.to_numpy()) / 2
    return result


def delong_paired(labels, predictions_a, predictions_b):
    """DeLong's correlated-AUC covariance using midranks; observations assumed independent."""
    labels = np.asarray(labels, dtype=int)
    scores = np.asarray([predictions_a, predictions_b], dtype=float)
    if len(labels) != scores.shape[1] or not np.isfinite(scores).all():
        raise ValueError("Invalid paired AUC inputs")
    if not np.isin(labels, [0, 1]).all():
        raise ValueError("DeLong requires binary labels")
    order = np.argsort(-labels, kind="stable")
    scores = scores[:, order]
    m, n = int(labels.sum()), int((1 - labels).sum())
    if min(m, n) < 2:
        return {"delta_auc": None, "p_nominal": None, "reason": "at least two positives and negatives required"}
    tx = np.array([rankdata(row[:m], method="average") for row in scores])
    ty = np.array([rankdata(row[m:], method="average") for row in scores])
    tz = np.array([rankdata(row, method="average") for row in scores])
    auc = tz[:, :m].sum(axis=1) / m / n - (m + 1.) / (2. * n)
    v01, v10 = (tz[:, :m] - tx) / n, 1. - (tz[:, m:] - ty) / m
    covariance = np.cov(v01) / m + np.cov(v10) / n
    contrast = np.array([1., -1.])
    variance, delta = float(contrast @ covariance @ contrast), float(auc[0] - auc[1])
    if np.allclose(scores[0], scores[1], rtol=0, atol=0):
        p, reason = 1., "identical predictions"
    elif variance <= 1e-15:
        p, reason = None, "degenerate estimated covariance"
    else:
        p, reason = float(2 * norm.sf(abs(delta) / math.sqrt(variance))), "nominal; unadjusted dependence assumptions"
    return {"delta_auc": delta, "p_nominal": p, "reason": reason}


def holm(values):
    """Preserve family size even if one planned comparison is unavailable."""
    output = [None] * len(values)
    valid = sorted((v, i) for i, v in enumerate(values) if v is not None and np.isfinite(v))
    previous = 0.
    for rank, (p, index) in enumerate(valid):
        previous = max(previous, min(1., (len(values) - rank) * p))
        output[index] = previous
    return output


def paired_bootstrap(pairs, reps=2000, seed=2026):
    """Resample seeds and common video groups; never pool seeds as independent videos."""
    if reps < 20:
        raise ValueError("Use at least 20 bootstrap repetitions (2000 for production)")
    aligned = []
    for left, right in pairs:
        aligned.append(paired(left, right, "video_id"))
    if not aligned:
        return {"status": "missing_paired_seeds"}
    reference = aligned[0][0]
    for left, right in aligned[1:]:
        paired(reference, left, "video_id")
    groups = reference.group_id.astype(str).to_numpy()
    unique = np.unique(groups)
    if len(unique) < 2:
        return {"status": "insufficient_groups"}
    indices = [np.flatnonzero(groups == group) for group in unique]
    labels = reference.label.to_numpy()
    a = np.array([left.probability.to_numpy() for left, _ in aligned])
    b = np.array([right.probability.to_numpy() for _, right in aligned])
    measured = np.mean([roc_auc_score(labels, x) - roc_auc_score(labels, y) for x, y in zip(a, b)])
    rng, deltas = np.random.default_rng(seed), []
    for _ in range(reps * 20):
        selected = np.concatenate([indices[i] for i in rng.integers(0, len(unique), len(unique))])
        if len(np.unique(labels[selected])) != 2:
            continue
        seeds = rng.integers(0, len(aligned), len(aligned))
        deltas.append(float(np.mean([roc_auc_score(labels[selected], a[i, selected]) -
                                    roc_auc_score(labels[selected], b[i, selected]) for i in seeds])))
        if len(deltas) == reps:
            break
    if len(deltas) < reps:
        return {"status": "insufficient_valid_resamples", "valid": len(deltas)}
    verified = bool(pd.to_numeric(reference.grouping_verified).eq(1).all())
    return {"status": "ok", "mean_delta_auc": float(measured),
            "ci95": np.quantile(deltas, [.025, .975]).tolist(), "resamples": len(deltas),
            "paired_seeds": len(aligned), "groups": len(unique),
            "interpretation": "source-grouped; validity depends on manifest grouping" if verified else
                              "EXPLORATORY video bootstrap; source/identity dependence unresolved",
            "grouping_verified": verified, "confirmatory_p_value": None}


def metrics_for(frame, threshold=.5):
    from training_model.utils.metrics import compute_binary_metrics
    return clean_json(compute_binary_metrics(frame.label, frame.probability, threshold=threshold))


def evaluation_tables(predictions, threshold=.5):
    measured = []
    for dataset, frame in predictions.groupby("dataset"):
        for level in ("frame", "video_mean", "video_median"):
            data = frame if level == "frame" else aggregate_videos(frame, level.split("_")[1])
            measured.append({"dataset": dataset, "level": level, "method": "all", "samples": len(data),
                             **metrics_for(data, threshold)})
            if dataset == "ffpp":
                for method in sorted(set(data.method) - {"original"}):
                    selected = data[data.method.isin(["original", method])]
                    measured.append({"dataset": dataset, "level": level, "method": method,
                                     "samples": len(selected), **metrics_for(selected, threshold)})
    return measured


def evaluate_one(config, variant, seed, frames, coverage, index, model_factory=None):
    drive, _ = paths(config)
    folder = drive / "runs" / variant / f"seed-{seed}"
    state = read_json(folder / "state.json")
    if state["status"] != "completed":
        raise ValueError(f"Train {variant}, seed {seed} to completion before evaluating")
    if sha256(folder / "best.pt") != state["best_sha256"]:
        raise IOError("Best checkpoint is corrupt or changed")
    info = read_json(folder / "model-info.json")
    if info["dataset_hash"] != dataset_hash(index):
        raise ValueError("Current cache differs from this model's training data")
    evaluation = folder / "evaluation"
    evaluation.mkdir(exist_ok=True)
    expected = [r for r in coverage if r["split"] == "test"]
    missing = [r["video_id"] for r in expected if int(r["saved_frames"]) == 0]
    available_datasets = {r["dataset"] for r in expected}
    report = {"expected_videos": len(expected), "zero_crop_video_ids": missing,
              "datasets_absent": sorted(set(DATASETS) - available_datasets),
              "allow_missing_videos": bool(config["evaluation"].get("allow_missing_videos")),
              "smoke": bool(config.get("smoke"))}
    atomic_json(evaluation / "coverage.json", report)
    if missing and not config["evaluation"].get("allow_missing_videos"):
        raise ValueError("Some test videos have no crops. Review coverage.json; explicit allow_missing_videos is required for a subset analysis")
    target_rows = [r for r in frames if r["split"] == "test"]
    if not target_rows:
        raise ValueError("No test crops available")
    if (evaluation / "status.json").exists():
        old = read_json(evaluation / "status.json")
        if old.get("best_sha256") == state["best_sha256"] and old.get("dataset_hash") == dataset_hash(index):
            csv = evaluation / "frame-predictions.csv"
            if csv.exists() and sha256(csv) == old.get("predictions_sha256"):
                print(f"Skip verified evaluation: {variant}, seed {seed}")
                return
    checkpoint = torch.load(folder / "best.pt", map_location="cpu", weights_only=False)
    if checkpoint["signature"] != state["signature"]:
        raise ValueError("Checkpoint and run state disagree")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    runtime = info["runtime"]
    if device.type != "cuda" and not config.get("smoke"):
        raise RuntimeError("Production inference requires a Colab GPU")
    model = model_factory() if model_factory else build_experiment_model(variant, config, seed, pretrained=False)
    model.load_state_dict(checkpoint["model"], strict=True)
    model.to(device).eval()
    loader = loader_for(target_rows, config, False, seed, microbatch=runtime["microbatch_size"])
    output = []
    with torch.inference_mode():
        for images, _, row_indices in loader:
            with precision_context(device, runtime["precision"]):
                probability = model(images.to(device)).float().sigmoid().cpu().tolist()
            for idx, value in zip(row_indices.tolist(), probability):
                row = {k: v for k, v in target_rows[idx].items() if k != "local_path"}
                output.append({**row, "label": int(row["label"]), "grouping_verified": int(row["grouping_verified"]),
                               "probability": float(value), "prediction": int(value >= config["evaluation"]["threshold"])})
    frame = checked_predictions(pd.DataFrame(output))
    if set(frame.crop_path) != {r["crop_path"] for r in target_rows}:
        raise ValueError("Inference did not cover exactly the prepared test crops")
    frame.to_csv(evaluation / "frame-predictions.csv", index=False)
    aggregate_videos(frame).to_csv(evaluation / "video-predictions.csv", index=False)
    aggregate_videos(frame, "median").to_csv(evaluation / "video-predictions-median.csv", index=False)
    pd.DataFrame(evaluation_tables(frame, config["evaluation"]["threshold"])).to_csv(evaluation / "metrics.csv", index=False)
    atomic_json(evaluation / "status.json", {"best_sha256": state["best_sha256"], "dataset_hash": dataset_hash(index),
                                             "predictions_sha256": sha256(evaluation / "frame-predictions.csv"),
                                             "smoke": bool(config.get("smoke"))})


def evaluate(config, variants=None, seeds=None):
    frames, coverage, index = materialize(config)
    for seed in seeds or config["training"]["seeds"]:
        for variant in variants or config["training"]["variants"]:
            evaluate_one(config, variant, int(seed), frames, coverage, index)


def summarize(config):
    drive, _ = paths(config)
    folder = drive / "summaries"
    folder.mkdir(exist_ok=True)
    expected = [(variant, int(seed)) for seed in config["training"]["seeds"] for variant in config["training"]["variants"]]
    predictions, measurements, missing, counts, coverage_notes, data_hashes = {}, [], [], [], [], set()
    for variant, seed in expected:
        run = drive / "runs" / variant / f"seed-{seed}"
        evaluation = run / "evaluation"
        if not (run / "state.json").exists() or read_json(run / "state.json").get("status") != "completed" or not (evaluation / "status.json").exists():
            missing.append({"variant": variant, "seed": seed})
            continue
        state, status = read_json(run / "state.json"), read_json(evaluation / "status.json")
        data_hashes.add(status["dataset_hash"])
        coverage_notes.append({"variant": variant, "seed": seed, **read_json(evaluation / "coverage.json")})
        csv = evaluation / "frame-predictions.csv"
        if status["best_sha256"] != state["best_sha256"] or sha256(csv) != status["predictions_sha256"]:
            raise ValueError("Summary input is stale or corrupt; rerun evaluation")
        frame = checked_predictions(pd.read_csv(csv))
        predictions[variant, seed] = frame
        measurements.extend({"variant": variant, "seed": seed, **m}
                            for m in evaluation_tables(frame, config["evaluation"]["threshold"]))
        counts.append({"variant": variant, "seed": seed, **read_json(run / "model-info.json")})
    if len(data_hashes) > 1:
        raise ValueError("Cannot summarize runs using different frozen data caches")
    for seed in config["training"]["seeds"]:
        if ("favit_matched", seed) in predictions and ("cnn_only", seed) in predictions:
            frame = ensemble(predictions["favit_matched", seed], predictions["cnn_only", seed])
            frame.to_csv(folder / f"ensemble-seed-{seed}.csv", index=False)
            measurements.extend({"variant": "score_ensemble_50_50", "seed": seed, **m}
                                for m in evaluation_tables(frame, config["evaluation"]["threshold"]))
    if not measurements:
        atomic_json(folder / "progress.json", {"missing_runs": missing, "measured_runs": 0})
        raise ValueError("No completed evaluations. Summary never generates placeholder results")
    per_seed = pd.DataFrame(measurements)
    per_seed.to_csv(folder / "metrics-per-seed.csv", index=False)
    keys = ["variant", "dataset", "level", "method"]
    numeric = ["accuracy", "auc", "precision", "recall", "f1"]
    summary = per_seed.groupby(keys)[numeric].agg(["mean", "std", "count"])
    summary.columns = ["_".join(pair) for pair in summary.columns]
    summary.reset_index().to_csv(folder / "metrics-mean-std.csv", index=False)
    summary.reset_index().to_latex(folder / "results.tex", index=False, float_format="%.5f", escape=True)
    comparisons = []
    for seed in config["training"]["seeds"]:
        dual = predictions.get(("favit_cnn", seed))
        if dual is None:
            continue
        for dataset in DATASETS:
            family = []
            for reference in [v for v in VARIANTS if v != "favit_cnn"]:
                other = predictions.get((reference, seed))
                if other is None or not (dual.dataset == dataset).any() or not (other.dataset == dataset).any():
                    family.append({"dataset": dataset, "seed": seed, "reference": reference,
                                   "delta_auc": None, "p_nominal": None, "reason": "missing paired run/dataset"})
                    continue
                left, right = paired(aggregate_videos(dual[dual.dataset == dataset]),
                                     aggregate_videos(other[other.dataset == dataset]), "video_id")
                family.append({"dataset": dataset, "seed": seed, "reference": reference,
                               **delong_paired(left.label, left.probability, right.probability)})
            for row, corrected in zip(family, holm([r["p_nominal"] for r in family])):
                comparisons.append({**row, "p_holm": corrected, "family_size": 4, "interpretation": "exploratory nominal DeLong"})
    pd.DataFrame(comparisons).to_csv(folder / "paired-delong-exploratory.csv", index=False)
    bootstraps = {}
    for dataset in DATASETS:
        pairs = []
        for seed in config["training"]["seeds"]:
            a, b = predictions.get(("favit_cnn", seed)), predictions.get(("favit_matched", seed))
            if a is not None and b is not None and (a.dataset == dataset).any() and (b.dataset == dataset).any():
                pairs.append((aggregate_videos(a[a.dataset == dataset]), aggregate_videos(b[b.dataset == dataset])))
        bootstraps[dataset] = paired_bootstrap(pairs, int(config["evaluation"].get("bootstrap_reps", 2000)),
                                              int(config["evaluation"].get("bootstrap_seed", 2026)))
    atomic_json(folder / "primary-comparison-bootstrap.json", clean_json(bootstraps))
    atomic_json(folder / "parameter-counts.json", [{"variant": r["variant"], "seed": r["seed"],
                                                   "trainable": r["trainable"], "total": r["total"]} for r in counts])
    _plots(config, drive, folder, per_seed)
    missing_datasets = sorted(set(DATASETS) - set(per_seed.dataset))
    subset_runs = [{"variant": r["variant"], "seed": r["seed"], "zero_crop_video_ids": r["zero_crop_video_ids"]}
                   for r in coverage_notes if r["zero_crop_video_ids"]]
    progress = {"measured_runs": len(predictions), "expected_runs": len(expected), "missing_runs": missing,
                "datasets_absent": missing_datasets, "subset_analysis_runs": subset_runs,
                "complete": not missing and not missing_datasets and not subset_runs,
                "smoke": bool(config.get("smoke"))}
    atomic_json(folder / "progress.json", progress)
    has_dual_pair = any(("favit_cnn", seed) in predictions and ("favit_matched", seed) in predictions
                        for seed in config["training"]["seeds"])
    comparison_note = ("So sánh chính: FA-ViT-CNN với FA-ViT có cùng LN–Dropout head trên Celeb-DF video AUC."
                       if has_dual_pair else
                       "Thí nghiệm bổ sung; chưa có cặp FA-ViT-CNN/matched-head trong báo cáo này. "
                       "Không suy ra chênh lệch với bảng cũ khi chưa xác minh protocol và dự đoán tương ứng.")
    lines = ["# Kết quả thí nghiệm FA-ViT-CNN", "",
             "**DỮ LIỆU GIẢ / SMOKE TEST — KHÔNG DÙNG CHO PAPER**" if config.get("smoke") else "Chỉ tổng hợp số đo từ các lượt chạy đã hoàn tất.",
             "", f"Hoàn tất {len(predictions)}/{len(expected)} lượt. Dataset thiếu: {', '.join(missing_datasets) or 'không'}.",
             f"Số lượt chỉ đánh giá trên subset do thiếu crop video: {len(subset_runs)}. Xem coverage.json của từng run.",
             "", comparison_note,
             "Mean/std tính theo seed; không coi các seed là video độc lập. Ensemble dùng trọng số cố định 50:50.",
             "", "DeLong và Holm là phân tích exploratory. Bootstrap giữ cặp mô hình và resample seed/nhóm nguồn; "
             "khi chưa xác minh grouping, khoảng tin cậy chỉ là video-bootstrap exploratory.",
             "Không tự cập nhật paper hoặc đưa ra quyết định Accept. Các run thiếu không được thay bằng số giả.",
             "", "## Video AUC trung bình và độ lệch chuẩn", ""]
    table = per_seed[(per_seed.level == "video_mean") & (per_seed.method == "all")]
    for (variant, dataset), group in table.groupby(["variant", "dataset"]):
        std = f"{group.auc.std():.5f}" if len(group) > 1 else "N/A (chỉ một seed)"
        lines.append(f"- {variant} / {dataset}: {group.auc.mean():.5f} ± {std}; n={len(group)} seed.")
    lines += ["", "## So sánh chính và CI95%", "", "```json", json.dumps(clean_json(bootstraps), indent=2, ensure_ascii=False), "```"]
    (folder / "REPORT-VI.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(progress, indent=2))


def _plots(config, drive, folder, per_seed):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    selected = per_seed[(per_seed.level == "video_mean") & (per_seed.method == "all")]
    figure, axes = plt.subplots(1, len(selected.dataset.unique()), figsize=(14, 4), squeeze=False)
    for ax, (dataset, values) in zip(axes[0], selected.groupby("dataset")):
        stats = values.groupby("variant").auc.agg(["mean", "std"])
        ax.bar(np.arange(len(stats)), stats["mean"], yerr=stats["std"].fillna(0), capsize=3)
        ax.set_xticks(np.arange(len(stats)), stats.index, rotation=35, ha="right", fontsize=8)
        ax.set_title(dataset + (" — SYNTHETIC" if config.get("smoke") else ""))
        ax.set_ylabel("Video AUC (mean ± sample SD across seeds)")
        ax.set_ylim(0, 1)
    figure.tight_layout()
    figure.savefig(folder / "video-auc.png", dpi=180)
    figure.savefig(folder / "video-auc.pdf")
    plt.close(figure)
    figure, ax = plt.subplots(figsize=(9, 4))
    for history_path in sorted((drive / "runs").glob("*/seed-*/history.json")):
        history = read_json(history_path)
        ax.plot([r["epoch"] for r in history], [r["val"]["accuracy"] for r in history],
                label=history_path.parent.parent.name + "/" + history_path.parent.name, alpha=.7)
    ax.set(xlabel="Epoch", ylabel="FF++ validation accuracy")
    ax.legend(fontsize=6, ncol=3)
    figure.tight_layout()
    figure.savefig(folder / "training-curves.png", dpi=180)
    plt.close(figure)
