from __future__ import annotations

from contextlib import nullcontext
import json
import math
from pathlib import Path
import random
import time

import cv2
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset

from .cache import dataset_hash, materialize
from .common import (ROOT, VARIANTS, atomic_json, atomic_torch_save, clean_json, code_hash, environment,
                     fingerprint, paths, public_config, read_json, require_space, save_environment, sha256, verified_copy)
from .models import build_experiment_model, encoder_hash, parameter_counts, seed_everything


class FrameDataset(Dataset):
    def __init__(self, rows, train=False, seed=42, epoch=0):
        self.rows, self.seed, self.epoch = rows, seed, epoch
        from training_model.datasets.deepfake_dataset import get_eval_transform, get_train_transform
        self.transform = get_train_transform(224) if train else get_eval_transform(224)

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        image = cv2.imread(row["local_path"])
        if image is None:
            raise IOError(f"Cannot read prepared crop {row['crop_path']}")
        sample_seed = int(fingerprint([self.seed, self.epoch, row["crop_path"]])[:8], 16)
        random.seed(sample_seed)
        np.random.seed(sample_seed)
        if hasattr(self.transform, "set_random_seed"):
            self.transform.set_random_seed(sample_seed)
        image = self.transform(image=cv2.cvtColor(image, cv2.COLOR_BGR2RGB))["image"]
        return image, torch.tensor(int(row["label"]), dtype=torch.float32), index


def loader_for(rows, config, train, seed=42, epoch=0, microbatch=None):
    if not rows:
        raise ValueError("The requested dataset split has no crops")
    generator = torch.Generator().manual_seed(seed * 1009 + epoch)
    return DataLoader(FrameDataset(rows, train, seed, epoch),
                      batch_size=int(microbatch or config["training"]["microbatch_size"]),
                      shuffle=train, num_workers=int(config["training"].get("num_workers", 2)),
                      pin_memory=torch.cuda.is_available(), persistent_workers=False,
                      generator=generator)


def precision_context(device, precision):
    if device.type != "cuda" or precision == "fp32":
        return nullcontext()
    return torch.autocast("cuda", dtype=torch.bfloat16 if precision == "bf16" else torch.float16)


def runtime_settings(config, require_calibration=True):
    drive, _ = paths(config)
    path = drive / "runtime.json"
    if not path.exists():
        if require_calibration and not config.get("smoke"):
            raise ValueError("Run doctor --calibrate first to freeze a common microbatch/precision for every model")
        return {"microbatch_size": int(config["training"]["microbatch_size"]), "precision": "fp32", "device": "cpu"}
    result = read_json(path)
    if result["code_hash"] != code_hash() or result["effective_batch_size"] != int(config["training"]["effective_batch_size"]):
        raise ValueError("Code or effective batch changed since calibration; use a new experiment root")
    return result


def calibrate(config):
    drive, local = paths(config)
    if not torch.cuda.is_available() and not config.get("smoke"):
        raise RuntimeError("No CUDA GPU. Select a GPU runtime in Colab; full training will not silently fall back to CPU")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    precision = config["training"].get("precision", "auto")
    if precision == "auto":
        precision = ("bf16" if torch.cuda.is_bf16_supported() else "fp16") if device.type == "cuda" else "fp32"
    if precision == "bf16" and (device.type != "cuda" or not torch.cuda.is_bf16_supported()):
        raise ValueError("This GPU does not support the requested BF16 precision")
    effective = int(config["training"]["effective_batch_size"])
    limit = min(effective, int(config["training"]["microbatch_size"]))
    candidates = [b for b in (16, 8, 4, 2, 1) if b <= limit and effective % b == 0]
    settings = None
    for batch in candidates:
        model, optimizer = None, None
        try:
            seed_everything(42)
            model = build_experiment_model("favit_cnn", config, 42, pretrained=False).to(device).train()
            optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=1e-4)
            with precision_context(device, precision):
                loss = model(torch.randn(batch, 3, 224, 224, device=device)).float().square().mean()
            loss.backward()
            optimizer.step()  # Include optimizer state memory in the probe.
            settings = {"device": str(device), "gpu": torch.cuda.get_device_name() if device.type == "cuda" else "CPU",
                        "precision": precision, "microbatch_size": batch, "effective_batch_size": effective,
                        "code_hash": code_hash(), "environment": environment()}
            break
        except torch.cuda.OutOfMemoryError:
            print(f"Microbatch {batch}: CUDA OOM; probing a smaller GLOBAL batch", flush=True)
        finally:
            del optimizer, model
            if device.type == "cuda":
                torch.cuda.empty_cache()
    if settings is None:
        raise RuntimeError("Even microbatch 1 failed calibration; select a larger-memory GPU")
    existing = drive / "runtime.json"
    if existing.exists() and any((drive / "runs").glob("*/seed-*/state.json")):
        old = read_json(existing)
        if any(old.get(k) != settings[k] for k in ("microbatch_size", "precision", "code_hash")):
            raise ValueError("Cannot change batch/precision/code for existing runs. Use a new experiment root")
    atomic_json(existing, settings)
    print(json.dumps(settings, indent=2))
    return settings


def rng_state():
    return {"python": random.getstate(), "numpy": np.random.get_state(), "torch": torch.get_rng_state(),
            "cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else []}


def restore_rng(state):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"].cpu())
    if torch.cuda.is_available() and state["cuda"]:
        torch.cuda.set_rng_state_all([v.cpu() for v in state["cuda"]])


def cpu_state(model):
    return {k: value.detach().cpu() for k, value in model.state_dict().items()}


def ensure_best(folder, expected):
    """Recover an interrupted best/last publication from the staged candidate."""
    best, staged = folder / "best.pt", folder / ".best-candidate.pt"
    if best.exists() and sha256(best) == expected:
        staged.unlink(missing_ok=True)
        return
    if staged.exists() and sha256(staged) == expected:
        verified_copy(staged, best)
        staged.unlink()
        return
    raise IOError("Cannot recover the best model referenced by the last committed epoch")


def one_epoch(model, loader, device, criterion, precision, optimizer=None, scaler=None, effective_batch=16):
    from training_model.utils.metrics import compute_binary_metrics
    training = optimizer is not None
    model.train(training)
    probabilities, labels_all = [], []
    total_loss, processed, window_count = 0., 0, 0
    if training:
        optimizer.zero_grad(set_to_none=True)
    started = time.monotonic()
    for step, (images, labels, _) in enumerate(loader):
        images, labels = images.to(device), labels.to(device)
        if training and window_count == 0:
            denominator = min(effective_batch, len(loader.dataset) - processed)
        with torch.set_grad_enabled(training), precision_context(device, precision):
            logits = model(images)
            targets = labels
            if training:
                smoothing = getattr(loader.dataset, "smoothing", .05)
                targets = labels * (1 - smoothing) + .5 * smoothing
            summed_loss = criterion(logits, targets)
        if not torch.isfinite(summed_loss):
            raise FloatingPointError("Non-finite loss; run stopped without marking completion")
        batch = labels.numel()
        if training:
            scaler.scale(summed_loss / denominator).backward()
            window_count += batch
            if window_count >= denominator:
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
                window_count = 0
        total_loss += float(summed_loss.detach())
        processed += batch
        labels_all.extend(labels.detach().cpu().tolist())
        probabilities.extend(torch.sigmoid(logits.detach().float()).cpu().tolist())
        if step % 100 == 0 or step + 1 == len(loader):
            print(f"{'train' if training else 'val'} {processed}/{len(loader.dataset)} "
                  f"loss={total_loss / processed:.5f} elapsed={time.monotonic()-started:.0f}s", flush=True)
    return compute_binary_metrics(labels_all, probabilities, loss=total_loss / processed)


def train_one(config, variant, seed, frames, index, model_factory=None, epochs_override=None):
    drive, local = paths(config)
    runtime = runtime_settings(config)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if device.type != "cuda" and not config.get("smoke"):
        raise RuntimeError("A CUDA GPU is required for production experiments")
    if runtime["precision"] == "bf16" and not torch.cuda.is_bf16_supported():
        raise ValueError("Resume requires BF16 support matching the calibrated protocol")
    training = config["training"]
    folder = drive / "runs" / variant / f"seed-{seed}"
    folder.mkdir(parents=True, exist_ok=True)
    signature = fingerprint({"training": training, "seed": seed, "variant": variant,
                             "dataset": dataset_hash(index), "runtime": {k: runtime[k] for k in ("precision", "microbatch_size")},
                             "code": code_hash(), "smoke": bool(config.get("smoke"))})
    state_path = folder / "state.json"
    previous = read_json(state_path) if state_path.exists() else {}
    if previous and previous["signature"] != signature:
        raise ValueError(f"Config/data/code mismatch for {variant}, seed {seed}; choose a new Drive root")
    if previous.get("status") == "completed":
        if not (folder / "best.pt").exists() or sha256(folder / "best.pt") != previous["best_sha256"]:
            raise ValueError("Completed run has missing/corrupt best weights")
        print(f"Skip completed run: {variant}, seed {seed}", flush=True)
        return
    train_rows = [r for r in frames if r["dataset"] == "ffpp" and r["split"] == "train"]
    val_rows = [r for r in frames if r["dataset"] == "ffpp" and r["split"] == "val"]
    if not train_rows or not val_rows or any({int(r["label"]) for r in rows} != {0, 1} for rows in (train_rows, val_rows)):
        raise ValueError("FF++ train and validation crops with both classes are required")
    require_space(drive, .5 if config.get("smoke") else 3)
    seed_everything(seed)
    model = model_factory() if model_factory else build_experiment_model(variant, config, seed)
    initial_encoder_hash = encoder_hash(model)
    if initial_encoder_hash is not None:
        initialization = drive / "initializations" / f"seed-{seed}.json"
        if initialization.exists() and read_json(initialization)["encoder_sha256"] != initial_encoder_hash:
            raise ValueError("Encoder initialization changed across variants/sessions; verify frozen pretrained weights and environment")
        if not initialization.exists():
            atomic_json(initialization, {"seed": seed, "encoder_sha256": initial_encoder_hash,
                                          "backbone": training["backbone"], "smoke": bool(config.get("smoke"))})
    model.to(device)
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                                 lr=float(training["lr"]), weight_decay=float(training["weight_decay"]))
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="max", factor=float(training["scheduler_factor"]),
        patience=max(0, int(training["scheduler_patience"]) - 1), min_lr=float(training["min_lr"]))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and runtime["precision"] == "fp16")
    positives = sum(int(r["label"]) for r in train_rows)
    weight = training.get("pos_weight")
    weight = (len(train_rows) - positives) / positives if weight is None else float(weight)
    if weight <= 0:
        raise ValueError("pos_weight must be positive")
    criterion = nn.BCEWithLogitsLoss(pos_weight=torch.tensor(weight, device=device), reduction="sum")
    start, best, bad_epochs, history = 1, -math.inf, 0, []
    best_hash = previous.get("best_sha256")
    last = folder / "last.pt"
    if last.exists():
        # Only load checkpoints generated by this project in the user's own Drive.
        checkpoint = torch.load(last, map_location="cpu", weights_only=False)
        if checkpoint["signature"] != signature:
            raise ValueError("Resume checkpoint does not match the frozen protocol")
        model.load_state_dict(checkpoint["model"], strict=True)
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        scaler.load_state_dict(checkpoint["scaler"])
        restore_rng(checkpoint["rng"])
        start, best, bad_epochs, history = checkpoint["epoch"] + 1, checkpoint["best"], checkpoint["bad_epochs"], checkpoint["history"]
        best_hash = checkpoint["best_sha256"]
        ensure_best(folder, best_hash)
        print(f"Resume {variant}, seed {seed}, from epoch {start}", flush=True)
    atomic_json(folder / "config.json", public_config(config))
    save_environment(folder)
    # Keep the original initialization hash on resume, before loading trained state.
    atomic_json(folder / "model-info.json", {**parameter_counts(model), "variant": variant, "seed": seed,
                                            "encoder_initial_sha256": initial_encoder_hash,
                                            "pos_weight": weight, "dataset_hash": dataset_hash(index),
                                            "runtime": runtime, "smoke": bool(config.get("smoke"))})
    total_epochs = int(training["epochs"])
    stop_epoch = min(total_epochs, start + epochs_override - 1) if epochs_override else total_epochs
    atomic_json(state_path, {"status": "running", "signature": signature, "best_sha256": best_hash})
    try:
        for epoch in range(start, stop_epoch + 1):
            if bad_epochs >= int(training["early_stopping_patience"]):
                break
            print(f"{variant} seed={seed}: epoch {epoch}/{total_epochs}", flush=True)
            train_loader = loader_for(train_rows, config, True, seed, epoch, runtime["microbatch_size"])
            train_loader.dataset.smoothing = float(training["label_smoothing"])
            val_loader = loader_for(val_rows, config, False, seed, epoch, runtime["microbatch_size"])
            train_metrics = one_epoch(model, train_loader, device, criterion, runtime["precision"], optimizer, scaler,
                                      int(training["effective_batch_size"]))
            val_metrics = one_epoch(model, val_loader, device, criterion, runtime["precision"])
            score = float(val_metrics["accuracy"])
            if score > best:
                best, bad_epochs = score, 0
                best_hash = atomic_torch_save({"model": cpu_state(model), "signature": signature,
                                              "variant": variant, "seed": seed, "epoch": epoch,
                                              "training": training, "smoke": bool(config.get("smoke"))}, folder / ".best-candidate.pt", local)
            else:
                bad_epochs += 1
            scheduler.step(score)
            history.append(clean_json({"epoch": epoch, "train": train_metrics, "val": val_metrics,
                                       "lr": optimizer.param_groups[0]["lr"], "bad_epochs": bad_epochs}))
            atomic_torch_save({"model": cpu_state(model), "optimizer": optimizer.state_dict(),
                               "scheduler": scheduler.state_dict(), "scaler": scaler.state_dict(),
                               "rng": rng_state(), "epoch": epoch, "best": best, "bad_epochs": bad_epochs,
                               "history": history, "signature": signature, "best_sha256": best_hash}, last, local)
            # Commit last.pt before replacing best.pt. A disconnect between these
            # steps is repaired from .best-candidate.pt on the next invocation.
            ensure_best(folder, best_hash)
            atomic_json(folder / "history.json", history)
            atomic_json(state_path, {"status": "running", "signature": signature, "epoch": epoch,
                                     "best_sha256": best_hash})
        finished = (bool(history) and (history[-1]["epoch"] >= total_epochs or bad_epochs >= int(training["early_stopping_patience"])))
        atomic_json(state_path, {"status": "completed" if finished else "interrupted", "signature": signature,
                                 "epoch": history[-1]["epoch"] if history else start - 1,
                                 "best_sha256": best_hash, "smoke": bool(config.get("smoke"))})
        if finished and not training.get("keep_completed_resume", False):
            # Remove only this runner's own verified resume file after best is persisted.
            if sha256(folder / "best.pt") != best_hash:
                raise IOError("Best checkpoint verification failed; retaining last.pt")
            last.unlink(missing_ok=True)
    except BaseException:
        atomic_json(state_path, {"status": "interrupted", "signature": signature, "best_sha256": best_hash,
                                 "resume_from": "last completed epoch"})
        raise


def train(config, variants=None, seeds=None):
    from .common import storage_estimate
    drive, _ = paths(config)
    if not config.get("smoke"):
        estimate = storage_estimate(config)
        print("Drive storage estimate:", estimate, flush=True)
        require_space(drive, estimate["required_free_drive_gib_estimate"])
    frames, _, index = materialize(config)
    if "ffpp" not in index["datasets"]:
        raise ValueError("FF++ cache is required for training")
    variants = variants or config["training"]["variants"]
    seeds = seeds or config["training"]["seeds"]
    for seed in seeds:
        for variant in variants:
            train_one(config, variant, int(seed), frames, index)
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
