from __future__ import annotations

import hashlib
from contextlib import contextmanager
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

import yaml

ROOT = Path(__file__).resolve().parents[1]
VARIANTS = ("favit_linear", "favit_matched", "favit_cnn", "cnn_only", "favit_capacity")
METHODS = ("original", "Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures", "FaceShifter")
DATASETS = ("ffpp", "celebdf", "uadfv")


def sha256(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def verified_copy(source, target):
    source, target = Path(source), Path(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(target.name + ".uploading")
    shutil.copyfile(source, temporary)
    expected = sha256(source)
    if sha256(temporary) != expected:
        raise IOError(f"Checksum mismatch while saving {target}")
    os.replace(temporary, target)
    return expected


def clean_json(value):
    """JSON has no NaN/Infinity. Represent unavailable measurements as null."""
    import math
    if isinstance(value, dict):
        return {str(k): clean_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean_json(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if hasattr(value, "item"):
        return clean_json(value.item())
    return value


def load_config(path):
    with Path(path).open(encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    for field in ("drive_root", "local_root", "data", "training"):
        if field not in config:
            raise ValueError(f"Missing configuration field: {field}")
    if any(not isinstance(config[field], str) or not config[field].strip() for field in ("drive_root", "local_root")):
        raise ValueError("Set explicit nonempty Drive and local scratch directories")
    config["drive_root"] = str(Path(config["drive_root"]).expanduser().resolve())
    config["local_root"] = str(Path(config["local_root"]).expanduser().resolve())
    if config["drive_root"] == config["local_root"]:
        raise ValueError("Drive and local scratch directories must differ")
    if config.get("smoke", False) and "smoke" not in Path(config["drive_root"]).name.lower():
        raise ValueError("Synthetic smoke output must use a separate directory containing 'smoke'")
    training = config["training"]
    data = config["data"]
    if int(data.get("image_size", 0)) != 224:
        raise ValueError("This ablation suite requires 224x224 crops and ViT-B/16")
    if any(int(data.get(key, 0)) <= 0 for key in ("train_frames", "eval_frames", "shard_videos")):
        raise ValueError("Frame and shard counts must be positive")
    if not 0 <= float(data.get("face_margin", .2)) <= 1 or not 1 <= int(data.get("jpeg_quality", 95)) <= 100:
        raise ValueError("Invalid crop margin or JPEG quality")
    variants, seeds = training.get("variants", []), training.get("seeds", [])
    if not variants or len(set(variants)) != len(variants) or not set(variants).issubset(VARIANTS):
        raise ValueError("Choose distinct supported training variants")
    if not seeds or len(set(seeds)) != len(seeds) or any(not isinstance(s, int) for s in seeds):
        raise ValueError("Choose distinct integer seeds")
    if int(training.get("effective_batch_size", 16)) <= 0:
        raise ValueError("effective_batch_size must be positive")
    if float(training.get("pos_weight", 1) or 1) <= 0:
        raise ValueError("Use pos_weight: null for automatic train-only weighting")
    return config


def public_config(config):
    # Download URLs can contain private bearer query parameters. Never log them.
    result = json.loads(json.dumps(config))
    result["sources"] = {name: {"configured": bool(value.get("source") or value.get("script") or value.get("handle"))}
                         for name, value in config.get("sources", {}).items()}
    return result


def code_hash():
    paths = list((ROOT / "experiments").glob("*.py"))
    paths += list((ROOT / "training_model" / "models").glob("*.py"))
    paths += list((ROOT / "training_model" / "datasets").glob("*.py"))
    return fingerprint({p.relative_to(ROOT).as_posix(): sha256(p) for p in sorted(paths)})


def environment():
    from importlib.metadata import PackageNotFoundError, version
    packages = {}
    for name in ("torch", "torchvision", "timm", "numpy", "pandas", "scipy", "scikit-learn",
                 "albumentations", "opencv-python-headless", "facenet-pytorch", "Pillow", "kagglehub"):
        try:
            packages[name] = version(name)
        except PackageNotFoundError:
            pass
    return {"python": sys.version, "packages": packages}


def storage_estimate(config):
    drive, _ = paths(config)
    remaining = []
    for variant in config["training"]["variants"]:
        for seed in config["training"]["seeds"]:
            state = drive / "runs" / variant / f"seed-{seed}" / "state.json"
            if not state.exists() or read_json(state).get("status") != "completed":
                remaining.append(variant)
    # Conservative inference-state allocation: ~117M FP32 parameters for a full
    # FA-ViT model, plus a reserve for active best/last staging and pretrained cache.
    weights = sum(.01 if variant == "cnn_only" else .5 for variant in remaining)
    return {"remaining_runs": len(remaining), "remaining_best_weights_gib_estimate": weights,
            "checkpoint_and_pretrained_reserve_gib": 3.5, "required_free_drive_gib_estimate": weights + 3.5,
            "note": "Estimate excludes crop cache not yet produced; Drive quota may differ from filesystem free space"}


def paths(config):
    drive, local = Path(config["drive_root"]), Path(config["local_root"])
    drive.mkdir(parents=True, exist_ok=True)
    local.mkdir(parents=True, exist_ok=True)
    return drive, local


def require_space(folder, gib):
    free = shutil.disk_usage(folder).free
    if free < float(gib) * 1024**3:
        raise RuntimeError(f"Insufficient disk space at {folder}: {free / 1024**3:.1f} GiB free; "
                           f"need at least {gib} GiB. Change storage or free space before continuing.")


@contextmanager
def scratch_directory(root, prefix):
    """Use inherited ACLs on Windows; remove only this freshly created child."""
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    child = root / (prefix + uuid.uuid4().hex)
    child.mkdir()
    try:
        yield child
    finally:
        resolved = child.resolve()
        if resolved.parent != root or not resolved.name.startswith(prefix):
            raise ValueError("Refusing scratch cleanup outside its expected parent")
        shutil.rmtree(resolved)


def atomic_torch_save(value, target, scratch):
    import torch
    Path(scratch).mkdir(parents=True, exist_ok=True)
    with scratch_directory(scratch, "save-") as folder:
        source = Path(folder) / "checkpoint.pt"
        torch.save(value, source)
        return verified_copy(source, target)


def save_environment(folder):
    folder = Path(folder)
    atomic_json(folder / "environment.json", environment())
    result = subprocess.run([sys.executable, "-m", "pip", "freeze"],
                            stdin=subprocess.DEVNULL, capture_output=True, text=True)
    if result.returncode == 0:
        (folder / "requirements-resolved.txt").write_text(result.stdout, encoding="utf-8")
