"""Approved acquisition and video manifests. Official FF++ splits are mandatory."""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
from urllib.request import Request, urlopen
import zipfile

from .common import DATASETS, METHODS, atomic_json, fingerprint, paths, read_json, require_space, sha256

VIDEO_SUFFIXES = {".mp4", ".avi", ".mov", ".mkv", ".m4v", ".webm"}
FFPP_SERVERS = {
    "EU2": "https://kaldir.vc.in.tum.de/faceforensics/v3/misc/filelist.json",
    "EU": "http://canis.vc.in.tum.de:8100/v3/misc/filelist.json",
    "CA": "http://falas.cmpt.sfu.ca:8100/v3/misc/filelist.json",
}


def choose_ffpp_server(source, rejected=()):
    """Probe only official mirror metadata; never substitute a different dataset."""
    preferred = source.get("server", "EU2")
    if preferred not in FFPP_SERVERS:
        raise ValueError("FF++ server must be EU2, EU or CA")
    failures = []
    for server in dict.fromkeys((preferred, "EU2", "EU", "CA")):
        if server in rejected:
            continue
        try:
            request = Request(FFPP_SERVERS[server], headers={"User-Agent": "FA-ViT-CNN/1.0"})
            with urlopen(request, timeout=12) as response:
                pairs = json.loads(response.read(65536))
            if not isinstance(pairs, list) or len(pairs) != 500 or any(not isinstance(p, list) or len(p) != 2 for p in pairs):
                raise ValueError("Official mirror returned an unexpected video file list")
            print(f"FF++ mirror ready: {server}", flush=True)
            return server
        except (OSError, ValueError) as error:
            failures.append(f"{server}: {error}")
            print(f"FF++ mirror unavailable: {server}: {error}", flush=True)
    raise RuntimeError("No reachable official FF++ mirror. Keep existing files and retry later. " + "; ".join(failures))


def download_ffpp(script, folder, source):
    server = choose_ffpp_server(source)
    for method in METHODS:
        rejected = []
        while True:
            print(f"Official FF++ download/resume: {method}, server={server}", flush=True)
            result = subprocess.run([sys.executable, str(script), str(folder), "-d", method,
                                     "-c", "c23", "-t", "videos", "--server", server],
                                    input="y\n", text=True)
            if result.returncode == 0:
                break
            rejected.append(server)
            # Existing files are retained by the official script. At most one
            # attempt per mirror for a method; never loop forever on one host.
            if len(rejected) == len(FFPP_SERVERS):
                raise RuntimeError(f"FF++ {method} failed on all official mirrors; see the script traceback in the stage log")
            print(f"FF++ {server} failed for {method}; checking another official mirror", flush=True)
            server = choose_ffpp_server(source, rejected)


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f"Cannot write empty manifest: {path}")
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def fetch(source, destination, expected=""):
    """Download without logging private URLs; Range resume only when server agrees."""
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    marker = target.with_name(target.name + ".download.json")
    source_id = fingerprint(str(source))
    if target.exists() and marker.exists():
        record = read_json(marker)
        if record.get("source_id") == source_id and sha256(target) == record.get("sha256"):
            if not expected or record["sha256"] == expected:
                return target
    if Path(str(source)).is_file():
        if Path(source).resolve() != target.resolve():
            shutil.copyfile(source, target)
    elif str(source).startswith(("https://drive.google.com/", "https://docs.google.com/")):
        import gdown
        result = gdown.download(str(source), str(target), quiet=True, fuzzy=True, resume=True)
        if not result:
            raise RuntimeError("Drive download failed; check the granted link or use a mounted Drive archive")
    elif str(source).startswith(("https://", "http://")):
        partial = target.with_name(target.name + ".part")
        partial_marker = target.with_name(target.name + ".part-source")
        if not partial_marker.exists() or partial_marker.read_text() != source_id:
            partial.unlink(missing_ok=True)
            partial_marker.write_text(source_id)
        offset = partial.stat().st_size if partial.exists() else 0
        headers = {"User-Agent": "FA-ViT-CNN research acquisition"}
        if offset:
            headers["Range"] = f"bytes={offset}-"
        try:
            with urlopen(Request(str(source), headers=headers), timeout=120) as response:
                resume = offset and response.status == 206
                if resume and not response.headers.get("Content-Range", "").startswith(f"bytes {offset}-"):
                    raise RuntimeError("Invalid Content-Range; retry from a clean partial download")
                with partial.open("ab" if resume else "wb") as stream:
                    shutil.copyfileobj(response, stream, length=1024 * 1024)
            partial.replace(target)
        except Exception:
            raise RuntimeError("Download failed; partial data retained. Check authorization/network and rerun.") from None
    else:
        raise FileNotFoundError("Set an approved HTTP/Drive source or an existing mounted archive path")
    actual = sha256(target)
    if expected and actual != expected:
        raise ValueError(f"Archive checksum mismatch: {target.name}")
    atomic_json(marker, {"source_id": source_id, "sha256": actual})
    return target


def safe_member(name, destination):
    normalized = PurePosixPath(name.replace("\\", "/"))
    if normalized.is_absolute() or ".." in normalized.parts or (normalized.parts and ":" in normalized.parts[0]):
        raise ValueError("Archive contains an unsafe path")
    target = (Path(destination) / str(normalized)).resolve()
    if not target.is_relative_to(Path(destination).resolve()):
        raise ValueError("Archive member escapes destination")
    return target


def extract_archive(archive, destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as zipped:
            for item in zipped.infolist():
                safe_member(item.filename, destination)
                if (item.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ValueError("Archive symlinks are unsupported")
            zipped.extractall(destination)
    elif tarfile.is_tarfile(archive):
        with tarfile.open(archive) as packed:
            for item in packed.getmembers():
                safe_member(item.name, destination)
                if not (item.isfile() or item.isdir()):
                    raise ValueError("Archive links/devices are unsupported")
            packed.extractall(destination, filter="data")
    else:
        raise ValueError("Expected a ZIP/TAR/TAR.GZ archive, not an HTML login page or unsupported archive")


def videos(folder):
    return sorted(p for p in Path(folder).rglob("*") if p.is_file() and p.suffix.lower() in VIDEO_SUFFIXES)


def ffpp_splits(folder):
    assignments, groups = {}, {}
    for split in ("train", "val", "test"):
        pairs = read_json(Path(folder) / f"{split}.json")
        for pair in pairs:
            if len(pair) != 2 or pair[0] == pair[1]:
                raise ValueError("Expected official two-source FF++ split pairs")
            pair = tuple(str(v).zfill(3) for v in pair)
            group = "ffpp:" + "-".join(sorted(pair))
            for source in pair:
                if source in assignments and (assignments[source] != split or groups[source] != group):
                    raise ValueError(f"FF++ source {source} occurs in overlapping split pairs")
                assignments[source], groups[source] = split, group
    return assignments, groups


def row_for(path, root, dataset, method, label, split, sources, group, verified, digest=None):
    return {"dataset": dataset, "split": split, "method": method,
            "video_id": f"{dataset}/{method}/{path.stem}", "label": int(label),
            "source_ids": json.dumps(sources), "group_id": group,
            "grouping_verified": int(verified), "raw_path": str(path.resolve()),
            "raw_relative_path": path.relative_to(root).as_posix(), "raw_sha256": (digest or sha256)(path)}


def build_ffpp_manifest(root, splits, smoke=False, *, digest=None, discovered=None):
    root = Path(root)
    assignments, groups = ffpp_splits(splits)
    inventory = videos(root) if discovered is None else discovered
    rows = []
    for method in METHODS:
        candidates = [p for p in inventory if method.lower() in [v.lower() for v in p.relative_to(root).parts]]
        if method == "original" and not candidates:
            candidates = [p for p in inventory if "original_sequences" in p.parts and "youtube" in p.parts]
        # Use c23 only if official hierarchy also contains other compression versions.
        c23 = [p for p in candidates if "c23" in p.parts]
        if c23:
            candidates = c23
        if not candidates or (not smoke and len(candidates) != 1000):
            raise ValueError(f"FF++ {method}: expected {'some' if smoke else '1000'} videos; found {len(candidates)}")
        if len({p.stem for p in candidates}) != len(candidates):
            raise ValueError(f"Duplicate video IDs in FF++ {method}")
        for path in candidates:
            source_ids = path.stem.split("_")
            if len(source_ids) != (1 if method == "original" else 2) or any(not s.isdigit() for s in source_ids):
                raise ValueError(f"Unrecognized official FF++ video filename: {path.name}")
            source_ids = [s.zfill(3) for s in source_ids]
            if any(s not in assignments for s in source_ids):
                raise ValueError(f"Video source absent from official splits: {path.name}")
            if len({assignments[s] for s in source_ids}) != 1 or len({groups[s] for s in source_ids}) != 1:
                raise ValueError(f"Cross-split/source-pair manipulation detected: {path.name}")
            rows.append(row_for(path, root, "ffpp", method, method != "original", assignments[source_ids[0]],
                                source_ids, groups[source_ids[0]], True, digest))
    audit_manifest(rows)
    return rows


def build_celebdf_manifest(root, smoke=False, *, digest=None):
    root = Path(root)
    lists = list(root.rglob("List_of_testing_videos.txt"))
    if len(lists) != 1:
        raise ValueError("Celeb-DF archive must contain exactly one List_of_testing_videos.txt")
    base, rows = lists[0].parent, []
    for line in lists[0].read_text(encoding="utf-8-sig").splitlines():
        if not line.strip():
            continue
        label, relative = line.strip().split(maxsplit=1)
        if label not in ("0", "1"):
            raise ValueError("Celeb-DF official labels must be 1=real, 0=fake")
        path = safe_member(relative, base)
        if not path.is_file() or path.suffix.lower() not in VIDEO_SUFFIXES:
            raise FileNotFoundError(f"Missing official Celeb-DF test video: {relative}")
        method = PurePosixPath(relative.replace("\\", "/")).parts[0]
        if method not in ("Celeb-real", "YouTube-real", "Celeb-synthesis") or (label == "0") != (method == "Celeb-synthesis"):
            raise ValueError("Celeb-DF path category and official label disagree")
        video_id = f"celebdf/{method}/{path.stem}"
        rows.append(row_for(path, root, "celebdf", method, label == "0", "test", [], video_id, False, digest))
    if not smoke and len(rows) != 518:
        raise ValueError(f"Expected 518 official Celeb-DF-v2 test videos, found {len(rows)}")
    audit_manifest(rows)
    return rows


def build_uadfv_manifest(root, smoke=False, *, digest=None):
    root, rows = Path(root), []
    by_class = {}
    for label, name in enumerate(("real", "fake")):
        matches = [p for p in root.rglob("*") if p.is_dir() and p.name.lower() == name and videos(p)]
        if len(matches) != 1:
            raise ValueError(f"UADFV needs one unambiguous {name}/ video directory")
        found = videos(matches[0])
        if not smoke and len(found) != 49:
            raise ValueError(f"Expected 49 UADFV {name} videos, found {len(found)}")
        by_class[name] = found
    normalize = lambda p: re.sub(r"[_-](fake|real)$", "", p.stem, flags=re.I)
    real_ids = [normalize(p) for p in by_class["real"]]
    fake_ids = [normalize(p) for p in by_class["fake"]]
    paired = len(set(real_ids)) == len(real_ids) and set(real_ids) == set(fake_ids) and len(set(fake_ids)) == len(fake_ids)
    for label, name in enumerate(("real", "fake")):
        for path in by_class[name]:
            group = "uadfv:" + normalize(path) if paired else f"uadfv/{name}/{path.stem}"
            rows.append(row_for(path, root, "uadfv", name, label, "test", [normalize(path)] if paired else [], group, paired, digest))
    audit_manifest(rows)
    return rows


def audit_manifest(rows):
    seen, sources = set(), {}
    for row in rows:
        if row["video_id"] in seen:
            raise ValueError(f"Duplicate video ID: {row['video_id']}")
        seen.add(row["video_id"])
        if int(row["label"]) not in (0, 1):
            raise ValueError("Invalid binary label")
        for source in json.loads(row["source_ids"]):
            key = (row["dataset"], source)
            if key in sources and sources[key] != row["split"]:
                raise ValueError(f"Source crosses split boundaries: {source}")
            sources[key] = row["split"]


def apply_groups(rows, filename):
    if not filename:
        return rows
    supplied = read_csv(filename)
    mapping = {(r["dataset"], r["video_id"]): r["group_id"] for r in supplied}
    if len(mapping) != len(supplied) or any(not v.strip() for v in mapping.values()):
        raise ValueError("Duplicate or blank author group mapping")
    datasets = {key[0] for key in mapping}
    for row in rows:
        if row["dataset"] in datasets:
            key = row["dataset"], row["video_id"]
            if key not in mapping:
                raise ValueError("Author group map must cover every video in each included dataset")
            row["group_id"] = row["dataset"] + ":author:" + mapping[key]
            row["grouping_verified"] = 1
    return rows


def download_kaggle_dataset(source, dataset, drive, local):
    """Use the user-selected KaggleHub provider; freeze its first observed version."""
    handle = str(source.get("handle", "")).strip()
    if not re.fullmatch(r"[\w.-]+/[\w.-]+(?:/versions/[1-9]\d*)?", handle):
        raise ValueError("Kaggle handle must be owner/dataset or owner/dataset/versions/N")
    marker = Path(drive) / "manifests" / f"{dataset}-kaggle-source.json"
    requested = handle
    if marker.exists():
        previous = read_json(marker)
        if previous["requested_handle"] != handle:
            raise ValueError("Kaggle source changed. Use a fresh Drive root for a different dataset release")
        requested = previous["resolved_handle"]
    # Keep raw Kaggle videos in Colab scratch, not the user's home or Drive cache.
    os.environ["KAGGLEHUB_CACHE"] = str(Path(local) / "kagglehub-cache")
    try:
        import kagglehub
    except ImportError:
        raise RuntimeError("Install the updated preprocessing requirements (kagglehub==1.0.3) and rerun setup") from None
    try:
        root = Path(kagglehub.dataset_download(requested)).resolve()
    except Exception:
        raise RuntimeError("Kaggle download failed. Check access/network; if authentication is required, add "
                           "Colab secret KAGGLE_API_TOKEN and enable USE_KAGGLE_SECRET, then rerun. "
                           "Alternatively set sources.uadfv.source to a mounted archive.") from None
    if not root.is_dir() or not videos(root):
        raise ValueError("Kaggle download contains no raw videos; expected UADFV real/ and fake/ directories")
    resolved = requested
    for i, part in enumerate(root.parts[:-1]):
        if part == "versions" and root.parts[i + 1].isdigit():
            resolved = "/".join(handle.split("/")[:2]) + "/versions/" + root.parts[i + 1]
    import importlib.metadata
    provenance = {"provider": "kagglehub", "requested_handle": handle, "resolved_handle": resolved,
                  "kagglehub_version": importlib.metadata.version("kagglehub"),
                  "version_pinned": "/versions/" in resolved,
                  "source_status": "user_selected_kaggle_mirror_not_original_dataset_host"}
    return root, marker, provenance


def prepare(config, selected=DATASETS):
    drive, local = paths(config)
    raw = Path(config["data"].get("raw_root") or local / "raw")
    raw.mkdir(parents=True, exist_ok=True)
    require_space(local, config["data"].get("min_local_free_gib", 20))
    splits = Path(config["data"].get("ffpp_splits_dir") or drive / "manifests" / "official-splits")
    failures = {}
    for dataset in selected:
        try:
            source = config.get("sources", {}).get(dataset, {})
            folder = raw / dataset
            folder.mkdir(parents=True, exist_ok=True)
            if dataset == "ffpp":
                if not config["data"].get("ffpp_splits_dir"):
                    for split in ("train", "val", "test"):
                        target = splits / f"{split}.json"
                        # Freeze first successful snapshot instead of updating between runs.
                        if not target.exists():
                            ref = config["data"].get("ffpp_revision", "master")
                            fetch(f"https://raw.githubusercontent.com/ondyari/FaceForensics/{ref}/dataset/splits/{split}.json", target)
                if not videos(folder):
                    if not source.get("script") or not source.get("accepted_terms"):
                        raise ValueError("FF++: request official access, set sources.ffpp.script and accepted_terms after reading the terms")
                if source.get("script"):
                    if not source.get("accepted_terms"):
                        raise ValueError("Confirm the official FF++ terms before invoking its script")
                    script = fetch(source["script"], local / "downloads" / "download-FaceForensics.py")
                    help_result = subprocess.run([sys.executable, str(script), "--help"],
                                                 stdin=subprocess.DEVNULL, capture_output=True, text=True)
                    if help_result.returncode != 0 or "FaceShifter" not in help_result.stdout:
                        raise ValueError("The granted official script must support FaceShifter; obtain its updated version")
                    download_ffpp(script, folder, source)
                rows = build_ffpp_manifest(folder, splits, config.get("smoke", False))
                atomic_json(drive / "manifests" / "ffpp-split-provenance.json",
                            {"revision_requested": config["data"].get("ffpp_revision"),
                             "sha256": {s: sha256(splits / f"{s}.json") for s in ("train", "val", "test")},
                             "identity_disjointness": "NOT_ESTABLISHED_BY_SOURCE_ID_SPLITS"})
            else:
                kaggle_provenance = None
                if source.get("provider") == "kagglehub" and not source.get("source"):
                    folder, kaggle_marker, kaggle_provenance = download_kaggle_dataset(source, dataset, drive, local)
                elif source.get("source"):
                    archive = fetch(source["source"], local / "downloads" / f"{dataset}.archive", source.get("sha256", ""))
                    marker = folder / ".extracted.json"
                    in_progress = folder / ".extracting.json"
                    checksum = sha256(archive)
                    if not marker.exists() or read_json(marker).get("sha256") != checksum:
                        resuming = in_progress.exists() and read_json(in_progress).get("sha256") == checksum
                        if marker.exists() or (videos(folder) and not resuming):
                            raise ValueError("Raw folder contains a different dataset archive; choose a fresh local_root")
                        atomic_json(in_progress, {"sha256": checksum})
                        extract_archive(archive, folder)
                        atomic_json(marker, {"sha256": checksum})
                        in_progress.unlink(missing_ok=True)
                elif not videos(folder):
                    raise ValueError(f"{dataset}: supply an authorized archive URL or mounted Drive path in sources.{dataset}.source")
                builder = build_celebdf_manifest if dataset == "celebdf" else build_uadfv_manifest
                rows = builder(folder, config.get("smoke", False))
                if kaggle_provenance is not None:
                    atomic_json(kaggle_marker, {**kaggle_provenance, "validated_videos": len(rows)})
            rows = apply_groups(rows, config["data"].get("groups_csv"))
            write_csv(local / "manifests" / f"videos-{dataset}.csv", rows)
            # Persist portable provenance, not transient raw paths or credential links.
            portable = [{k: v for k, v in r.items() if k != "raw_path"} for r in rows]
            write_csv(drive / "manifests" / f"videos-{dataset}.csv", portable)
            print(f"{dataset}: manifest ready, {len(rows)} videos", flush=True)
        except Exception as error:
            failures[dataset] = str(error)
            print(f"{dataset}: NOT READY: {error}", flush=True)
    atomic_json(drive / "manifests" / "preparation-status.json", {"failures": failures, "selected": list(selected)})
    if failures:
        raise RuntimeError("Some datasets are not ready. Fix the listed source/access issues and rerun prepare.")
