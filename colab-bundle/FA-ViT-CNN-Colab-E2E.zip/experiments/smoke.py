"""Explicit synthetic end-to-end test, isolated from all scientific results."""
from pathlib import Path

import cv2
import numpy as np
import torch
from torch import nn

from .cache import materialize, preprocess
from .common import atomic_json, load_config
from .data import prepare
from .evaluation import evaluate_one, summarize
from .models import build_experiment_model
from .training import train_one


class TinyEncoder(nn.Module):
    """Cheap synthetic encoder preserving the 768-d feature contract; NOT FA-ViT."""
    def __init__(self):
        super().__init__()
        self.vit = nn.Linear(3, 768)
        for p in self.vit.parameters():
            p.requires_grad = False
        self.adapter = nn.Linear(768, 768)
        self.classifier = nn.Identity()

    def forward(self, images):
        features = self.adapter(self.vit(images.mean(dim=(2, 3))))
        return self.classifier(features), features


def make_video(path, fake=False, frames=2):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"mp4v"), 4, (64, 64))
    if not writer.isOpened():
        raise RuntimeError("OpenCV MP4 fixture writer unavailable")
    for i in range(frames):
        image = np.full((64, 64, 3), 180 if fake else 65, dtype=np.uint8)
        cv2.circle(image, (32, 32), 18, (70 + i * 5, 150, 220), -1)
        writer.write(image)
    writer.release()


def create_fixture(folder):
    import yaml
    folder = Path(folder).resolve()
    if folder.exists() and any(folder.iterdir()):
        raise ValueError("Choose an empty smoke output directory; existing results will not be overwritten")
    folder.mkdir(parents=True, exist_ok=True)
    raw = folder / "local" / "raw"
    splits = folder / "splits"
    for i, split in enumerate(("train", "val", "test")):
        a, b = f"{2*i:03d}", f"{2*i+1:03d}"
        atomic_json(splits / f"{split}.json", [[a, b]])
        for video_id in (a, b):
            make_video(raw / "ffpp" / "original" / f"{video_id}.mp4")
        for method in ("Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures", "FaceShifter"):
            for name in (f"{a}_{b}", f"{b}_{a}"):
                make_video(raw / "ffpp" / method / f"{name}.mp4", True)
    lines = []
    for label, name in ((1, "Celeb-real"), (0, "Celeb-synthesis")):
        for i in range(2):
            relative = f"{name}/id{i}.mp4"
            make_video(raw / "celebdf" / relative, label == 0)
            lines.append(f"{label} {relative}")
    (raw / "celebdf" / "List_of_testing_videos.txt").write_text("\n".join(lines))
    for name in ("real", "fake"):
        for i in range(2):
            make_video(raw / "uadfv" / name / f"{i:04d}.mp4", name == "fake")
    template = Path(__file__).resolve().parents[1] / "colab" / "experiment_config.yaml"
    config = yaml.safe_load(template.read_text(encoding="utf-8"))
    config.update(drive_root=str(folder / "smoke-drive"), local_root=str(folder / "local"), smoke=True)
    config["sources"] = {}  # Synthetic fixtures must never invoke configured real downloads.
    config["data"].update(ffpp_splits_dir=str(splits), raw_root=str(raw), train_frames=2, eval_frames=2,
                          shard_videos=12, min_local_free_gib=.01, min_drive_free_gib=.01)
    # Exercise every supported architecture even when production selects two controls.
    from .common import VARIANTS
    config["training"].update(variants=list(VARIANTS), seeds=[42], epochs=2, num_workers=0, effective_batch_size=4,
                              microbatch_size=2, pretrained=False, precision="fp32", keep_completed_resume=True)
    config["evaluation"].update(bootstrap_reps=40)
    path = folder / "smoke-config.yaml"
    path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    return path


def run_smoke(folder):
    torch.set_num_threads(2)
    config = load_config(create_fixture(folder))
    prepare(config)
    preprocess(config)
    preprocess(config)  # Verify valid shards are skipped.
    frames, coverage, index = materialize(config)
    for variant in config["training"]["variants"]:
        factory = lambda v=variant: build_experiment_model(v, config, 42, pretrained=False, encoder_factory=TinyEncoder)
        # Exercise a real interruption boundary, then resume at the next epoch.
        train_one(config, variant, 42, frames, index, model_factory=factory, epochs_override=1)
        train_one(config, variant, 42, frames, index, model_factory=factory)
        evaluate_one(config, variant, 42, frames, coverage, index, model_factory=factory)
    summarize(config)
    print("SYNTHETIC smoke passed. These are NOT scientific FA-ViT results.", flush=True)
    return config
