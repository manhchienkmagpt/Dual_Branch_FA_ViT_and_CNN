"""Resumable crop shards and local materialization. No training directly from Drive."""
from __future__ import annotations

from collections import Counter
import importlib.metadata
import json
from pathlib import Path
import shutil
import tarfile

import cv2
import numpy as np

from .common import DATASETS, atomic_json, fingerprint, paths, read_json, require_space, scratch_directory, sha256, verified_copy
from .data import extract_archive, read_csv, safe_member, write_csv


class SyntheticDetector:
    """Only for explicit smoke fixtures. Never a replacement for MTCNN in experiments."""
    def largest_face(self, image):
        height, width = image.shape[:2]
        return np.array([width * .1, height * .1, width * .9, height * .9, 1.])


def process_video(row, output, settings, detector):
    """Return frame records and auditable coverage, including zero-crop videos."""
    cap = cv2.VideoCapture(str(row["raw_path"]))
    n_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) if cap.isOpened() else 0
    requested = int(settings["train_frames"] if row["split"] == "train" else settings["eval_frames"])
    indices = np.unique(np.linspace(0, n_frames - 1, min(requested, n_frames), dtype=int)) if n_frames > 0 else []
    records, failed_read, no_face = [], 0, 0
    size, margin = int(settings["image_size"]), float(settings["face_margin"])
    video_key = fingerprint(row["video_id"])[:24]
    try:
        for index in indices:
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(index))
            ok, image = cap.read()
            if not ok:
                failed_read += 1
                continue
            bbox = detector.largest_face(image)
            if bbox is None:
                no_face += 1
                continue
            x1, y1, x2, y2 = map(float, bbox[:4])
            height, width = image.shape[:2]
            pad_x, pad_y = (x2 - x1) * margin, (y2 - y1) * margin
            x1, y1 = max(0, round(x1 - pad_x)), max(0, round(y1 - pad_y))
            x2, y2 = min(width, round(x2 + pad_x)), min(height, round(y2 + pad_y))
            if x2 <= x1 or y2 <= y1:
                no_face += 1
                continue
            relative = f"crops/{row['dataset']}/{row['split']}/{row['method']}/{video_key}/{int(index):06d}.jpg"
            target = Path(output) / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            crop = cv2.resize(image[y1:y2, x1:x2], (size, size), interpolation=cv2.INTER_AREA)
            if not cv2.imwrite(str(target), crop, [cv2.IMWRITE_JPEG_QUALITY, int(settings["jpeg_quality"])]):
                raise IOError(f"Failed to write crop: {target}")
            record = {k: v for k, v in row.items() if k not in ("raw_path", "raw_relative_path", "raw_sha256")}
            record.update(frame_index=int(index), crop_path=relative)
            records.append(record)
    finally:
        cap.release()
    coverage = {k: v for k, v in row.items() if k != "raw_path"}
    coverage.update(requested_frames=requested, unique_sampled_frames=len(indices), saved_frames=len(records),
                    failed_reads=failed_read, no_face=no_face, status="ok" if records else "NO_CROPS")
    return records, coverage


def preprocessing_signature(config):
    settings = {k: config["data"][k] for k in
                ("image_size", "train_frames", "eval_frames", "face_margin", "jpeg_quality", "detector", "shard_videos")}
    settings["preprocess_code_sha256"] = sha256(Path(__file__))
    if config.get("smoke"):
        settings["detector_implementation"] = "synthetic_smoke_only"
    else:
        settings["facenet_pytorch"] = importlib.metadata.version("facenet-pytorch")
        # Include shipped MTCNN weights in the cache identity, not only package name.
        import facenet_pytorch
        weights = Path(facenet_pytorch.__file__).parent / "data"
        settings["mtcnn_weights"] = {p.name: sha256(p) for p in sorted(weights.glob("*net.pt"))}
        if len(settings["mtcnn_weights"]) != 3:
            raise RuntimeError("Cannot establish MTCNN weight provenance")
    return fingerprint(settings), settings


def preprocess(config, selected=DATASETS, detector=None):
    drive, local = paths(config)
    require_space(drive, config["data"].get("min_drive_free_gib", 3))
    signature, settings = preprocessing_signature(config)
    cache = drive / "cache" / signature[:16]
    cache.mkdir(parents=True, exist_ok=True)
    index_path = cache / "index.json"
    index = read_json(index_path) if index_path.exists() else {
        "schema": 1, "preprocessing_signature": signature, "settings": settings,
        "smoke": bool(config.get("smoke")), "datasets": {}}
    if detector is None:
        if config.get("smoke"):
            detector = SyntheticDetector()
        else:
            if config["data"].get("detector") != "mtcnn":
                raise ValueError("Production protocol requires MTCNN")
            from preprocess_deepfake.utils import MTCNNDetector
            detector = MTCNNDetector()
    failures = []
    for dataset in selected:
        manifest_path = local / "manifests" / f"videos-{dataset}.csv"
        if not manifest_path.exists():
            failures.append(dataset)
            continue
        rows = read_csv(manifest_path)
        portable = [{k: v for k, v in r.items() if k != "raw_path"} for r in rows]
        video_hash = fingerprint(portable)
        previous = index["datasets"].get(dataset)
        if previous and previous["video_manifest_hash"] != video_hash:
            raise ValueError("Video manifest changed within a cache. Use a new Drive root for a different dataset release.")
        chunk_size = int(config["data"]["shard_videos"])
        shards = []
        for offset in range(0, len(rows), chunk_size):
            batch = rows[offset:offset + chunk_size]
            batch_id = fingerprint({"rows": portable[offset:offset + chunk_size], "settings": signature})[:24]
            relative = f"{dataset}/{offset // chunk_size:05d}-{batch_id}.tar"
            destination = cache / relative
            metadata = destination.with_suffix(".json")
            if destination.exists() and metadata.exists() and sha256(destination) == read_json(metadata).get("sha256"):
                print(f"Cache valid; skip {dataset} shard {offset // chunk_size}", flush=True)
                shards.append({"path": relative, **read_json(metadata)})
                continue
            with scratch_directory(local, "crop-shard-") as temporary:
                work = Path(temporary)
                frames, coverage = [], []
                for row in batch:
                    source = Path(row["raw_path"])
                    if not source.is_file() or sha256(source) != row["raw_sha256"]:
                        raise ValueError(f"Video missing or changed after preparation: {row['video_id']}")
                    new_frames, status = process_video(row, work, config["data"], detector)
                    frames.extend(new_frames)
                    coverage.append(status)
                write_csv(work / "videos.csv", coverage)
                if frames:
                    write_csv(work / "frames.csv", frames)
                else:
                    (work / "frames.csv").write_text("crop_path\n", encoding="utf-8")
                archive = work / "shard.tar"
                with tarfile.open(archive, "w") as packed:
                    for path in sorted(work.rglob("*")):
                        if path.is_file() and path != archive:
                            packed.add(path, arcname=path.relative_to(work).as_posix(), recursive=False)
                checksum = verified_copy(archive, destination)
                record = {"sha256": checksum, "bytes": destination.stat().st_size,
                          "videos": len(coverage), "frames": len(frames),
                          "no_crop_video_ids": [r["video_id"] for r in coverage if not r["saved_frames"]]}
                atomic_json(metadata, record)
                shards.append({"path": relative, **record})
                # Persist progress after EACH complete shard; interrupted shards are recomputed.
                index["datasets"][dataset] = {"video_manifest_hash": video_hash, "complete": False, "shards": shards}
                atomic_json(index_path, index)
                preview = next(iter(sorted((work / "crops").rglob("*.jpg"))), None) if frames else None
                if preview and not (cache / "previews" / f"{dataset}.jpg").exists():
                    verified_copy(preview, cache / "previews" / f"{dataset}.jpg")
                print(f"Saved {dataset} shard {len(shards)}: {len(frames)} crops", flush=True)
        index["datasets"][dataset] = {"video_manifest_hash": video_hash, "complete": True, "shards": shards}
        atomic_json(index_path, index)
    atomic_json(drive / "cache" / "active.json", {"index": index_path.relative_to(drive).as_posix()})
    if failures:
        raise RuntimeError("Prepare video manifests first for: " + ", ".join(failures))
    print("Crop cache saved to Drive. Raw video files remain LOCAL and can be removed after checking coverage.", flush=True)
    return index


def cache_info(config):
    drive, _ = paths(config)
    pointer = read_json(drive / "cache" / "active.json")
    path = (drive / pointer["index"]).resolve()
    if not path.is_relative_to((drive / "cache").resolve()):
        raise ValueError("Unsafe cache pointer")
    index = read_json(path)
    if bool(index["smoke"]) != bool(config.get("smoke")):
        raise ValueError("Synthetic and scientific data caches cannot be mixed")
    return path.parent, index


def dataset_hash(index):
    return fingerprint({k: v for k, v in index.items() if k != "settings"})


def materialize(config):
    """Verify a cached archive before extracting; per-shard markers permit resumed restore."""
    _, local = paths(config)
    cache, index = cache_info(config)
    identity = dataset_hash(index)
    destination = local / "materialized" / identity[:16]
    destination.mkdir(parents=True, exist_ok=True)
    total = sum(s["bytes"] for d in index["datasets"].values() for s in d["shards"])
    if not (destination / "ready.json").exists():
        # TAR holds JPEGs, so its size is a practical estimate of restored crop size.
        require_space(local, max(1, total * 1.2 / 1024**3))
    frames, coverage = [], []
    for dataset, entry in index["datasets"].items():
        if not entry["complete"]:
            raise ValueError(f"Cache for {dataset} is incomplete; rerun preprocessing")
        for record in entry["shards"]:
            shard = safe_member(record["path"], cache)
            restored = safe_member(Path(record["path"]).with_suffix("").as_posix(), destination / "shards")
            marker = restored / "restored.json"
            valid = marker.exists() and read_json(marker).get("sha256") == record["sha256"]
            if valid:
                old_frames = read_csv(restored / "frames.csv")
                valid = all(safe_member(r["crop_path"], restored).is_file() for r in old_frames)
            if not valid:
                if sha256(shard) != record["sha256"]:
                    raise ValueError(f"Drive shard checksum mismatch: {record['path']}; rerun preprocessing")
                with scratch_directory(local, "restore-") as temporary:
                    packed = Path(temporary) / "shard.tar"
                    shutil.copyfile(shard, packed)
                    if sha256(packed) != record["sha256"]:
                        raise IOError("Local cache copy checksum mismatch")
                    extract_archive(packed, restored)
                atomic_json(marker, {"sha256": record["sha256"]})
            for row in read_csv(restored / "frames.csv"):
                row["local_path"] = str(safe_member(row["crop_path"], restored))
                frames.append(row)
            coverage.extend(read_csv(restored / "videos.csv"))
    if frames:
        write_csv(destination / "frames.csv", frames)
    write_csv(destination / "videos.csv", coverage)
    if len({r["crop_path"] for r in frames}) != len(frames):
        raise ValueError("Duplicate crop IDs across shards")
    counts = dict(Counter((r["dataset"] + "/" + r["split"]) for r in frames))
    atomic_json(destination / "ready.json", {"dataset_hash": identity, "counts": counts,
                                             "zero_crop_videos": [r["video_id"] for r in coverage if int(r["saved_frames"]) == 0]})
    return frames, coverage, index
