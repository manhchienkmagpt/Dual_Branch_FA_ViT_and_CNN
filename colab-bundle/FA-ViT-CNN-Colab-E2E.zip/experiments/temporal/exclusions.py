"""Explicit, manifest-bound exclusions; raw videos and fold assignments stay frozen."""
from datetime import datetime, timezone
from pathlib import Path

from ..common import atomic_json, fingerprint, read_json


def exclusion_path(config, dataset):
    return Path(config.get("cache_root") or config["drive_root"]) / "temporal-manifests" / f"exclusions-{dataset}.json"


def load_exclusions(config, dataset, manifest):
    path = exclusion_path(config, dataset)
    if not path.exists():
        return []
    record = read_json(path)
    if (record.get("schema") != 1 or record.get("dataset") != dataset
            or record.get("source_manifest_sha256") != manifest["sha256"]):
        raise ValueError(f"Exclusions do not match the frozen {dataset} manifest")
    entries = record.get("excluded_videos")
    if not isinstance(entries, list):
        raise ValueError("Excluded videos must be an explicit list")
    known = {row["video_id"] for row in manifest["videos"]}
    ids = []
    for entry in entries:
        if (not isinstance(entry, dict) or entry.get("video_id") not in known
                or not isinstance(entry.get("reason"), str) or not entry["reason"].strip()):
            raise ValueError("Every exclusion needs a known video ID and a reason")
        ids.append(entry["video_id"])
    if len(set(ids)) != len(ids) or known and set(ids) == known:
        raise ValueError("Duplicate exclusions or exclusion of the entire dataset")
    return sorted(entries, key=lambda entry: entry["video_id"])


def register_exclusion(config, dataset, video_id, reason):
    if config.get("cache_root"):
        raise ValueError("Shared source exclusions are read-only; use the original notebook")
    from .data import load_manifest
    _, manifest = load_manifest(config, dataset)
    if video_id not in {row["video_id"] for row in manifest["videos"]} or not reason.strip():
        raise ValueError("Specify a video from the frozen manifest and a nonempty reason")
    entries = load_exclusions(config, dataset, manifest)
    if video_id not in {entry["video_id"] for entry in entries}:
        entries.append({"video_id": video_id, "reason": reason.strip(),
                        "approved_at": datetime.now(timezone.utc).isoformat()})
    record = {"schema": 1, "dataset": dataset, "source_manifest_sha256": manifest["sha256"],
              "excluded_videos": sorted(entries, key=lambda entry: entry["video_id"])}
    # Validate before committing, including the all-videos-excluded guard.
    if len(record["excluded_videos"]) >= len(manifest["videos"]):
        raise ValueError("Cannot exclude the entire dataset")
    atomic_json(exclusion_path(config, dataset), record)
    print(f"{dataset}: registered exclusion {video_id}; raw video and original folds retained", flush=True)
    return record


def effective_rows(config, dataset, manifest):
    entries = load_exclusions(config, dataset, manifest)
    excluded = {entry["video_id"] for entry in entries}
    return [row for row in manifest["videos"] if row["video_id"] not in excluded], entries


def coverage_policy(entries):
    return {"excluded_videos": entries, "exclusions_sha256": fingerprint(entries)}
