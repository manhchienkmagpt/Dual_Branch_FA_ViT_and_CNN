"""MTCNN clip preparation, verified Drive shards, and local restore."""
from pathlib import Path
import importlib.metadata
import json
import shutil
import tarfile

import cv2
import numpy as np

from ..common import atomic_json, fingerprint, paths, read_json, require_space, scratch_directory, sha256, verified_copy
from ..data import extract_archive, safe_member
from .data import load_manifest
from .exclusions import coverage_policy, effective_rows, load_exclusions


# This exact implementation uses the same crop algorithm and shard layout.
# Only coverage/exclusion handling changed; never accept arbitrary old code hashes.
COMPATIBLE_IMPLEMENTATIONS = {"93aad20997972033c2e03876348a41dfa3a05cd63e93a593c4d1a5377a54fb58"}


def cache_location(config, dataset, manifest, signature, settings):
    base = Path(config["drive_root"]) / "temporal-cache" / dataset
    pointer = base / "active.json"
    if pointer.exists():
        prior_path = safe_member(read_json(pointer)["index"], base)
        prior = read_json(prior_path)
        old = prior["preprocessing"]
        same_settings = {k: v for k, v in old.items() if k != "implementation"} == {
            k: v for k, v in settings.items() if k != "implementation"}
        expected = fingerprint({"manifest": manifest["sha256"], "preprocessing": fingerprint(old)})
        if (prior["manifest_sha256"] == manifest["sha256"] and same_settings
                and bool(prior["smoke"]) == bool(config.get("smoke"))
                and old["implementation"] in COMPATIBLE_IMPLEMENTATIONS | {settings["implementation"]}
                and prior["identity"] == expected and prior_path.parent.name == expected[:20]):
            return prior_path.parent, expected, old
    identity = fingerprint({"manifest": manifest["sha256"], "preprocessing": signature})
    return base / identity[:20], identity, settings


class FaceDetector:
    def __init__(self, device="auto"):
        import torch
        from facenet_pytorch import MTCNN
        if device == "cuda" and not torch.cuda.is_available():
            raise RuntimeError("CUDA requested for MTCNN; enable a GPU or select device=cpu/auto")
        self.device = "cuda" if device != "cpu" and torch.cuda.is_available() else "cpu"
        self.model = MTCNN(keep_all=True, min_face_size=20, thresholds=(.6, .7, .7), device=self.device)

    def detect(self, bgr):
        boxes, probabilities, landmarks = self.model.detect(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB), landmarks=True)
        if boxes is None:
            return []
        detections = []
        for b, p, l in zip(boxes, probabilities, landmarks):
            # MTCNN can return object arrays; coerce before NumPy's numeric checks.
            b = np.asarray(b, dtype=np.float32)
            p = float(p)
            l = np.asarray(l, dtype=np.float32)
            if np.isfinite(b).all() and np.isfinite(p) and np.isfinite(l).all():
                detections.append((b, p, l))
        return detections


class SyntheticFaceDetector:
    """Fixture detector, available only when the entire protocol is marked smoke."""
    device = "synthetic-cpu"

    def detect(self, bgr):
        h, w = bgr.shape[:2]
        points = np.array([[.32, .38], [.68, .38], [.5, .56], [.37, .74], [.63, .74]]) * [w, h]
        return [(np.array([.1*w, .1*h, .9*w, .9*h]), .999, points)]


def iou(left, right):
    a = np.maximum(left[:2], right[:2]); b = np.minimum(left[2:4], right[2:4])
    intersection = float(np.maximum(0, b-a).prod())
    denominator = float(np.maximum(0, left[2:4]-left[:2]).prod() + np.maximum(0, right[2:4]-right[:2]).prod() - intersection)
    return intersection / denominator if denominator > 0 else 0.


def align_face(image, landmarks, size=224, margin=.2):
    # A fixed symmetric template, contracted around the centre to retain context.
    normalized = np.array([[.32, .38], [.68, .38], [.5, .56], [.37, .74], [.63, .74]], np.float32)
    reference = (.5 + (normalized - .5) / (1 + 2*margin)) * size
    cv2.setRNGSeed(0)
    matrix, _ = cv2.estimateAffinePartial2D(np.asarray(landmarks, np.float32), reference, method=cv2.LMEDS)
    if matrix is None or not np.isfinite(matrix).all():
        raise ValueError("Invalid five-point similarity transform")
    return cv2.warpAffine(image, matrix, (size, size), flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_REFLECT_101), matrix


def clip_starts(frame_count, length, number):
    if frame_count < length:
        return []
    return np.unique(np.linspace(0, frame_count-length, min(number, frame_count-length+1), dtype=int)).tolist()


def process_video(row, output, settings, detector):
    cap = cv2.VideoCapture(row["raw_path"])
    length = int(settings["clip_length"])
    count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) if cap.isOpened() else 0
    fps = float(cap.get(cv2.CAP_PROP_FPS)) if cap.isOpened() else 0.
    starts = clip_starts(count, length, int(settings["clips_per_video"]))
    clips, rejected = [], []
    video_key = fingerprint(row["video_id"])[:20]
    try:
        for start in starts:
            cap.set(cv2.CAP_PROP_POS_FRAMES, start)
            previous, images, metadata = None, [], []
            reason = None
            for offset in range(length):
                ok, image = cap.read()
                if not ok:
                    reason = "unreadable_frame"; break
                candidates = [d for d in detector.detect(image) if d[1] >= float(settings["detection_probability"])]
                if not candidates:
                    reason = "no_valid_landmarks"; break
                if previous is None:
                    chosen = max(candidates, key=lambda d: float(np.maximum(0, d[0][2:]-d[0][:2]).prod()))
                else:
                    chosen = max(candidates, key=lambda d: iou(previous, d[0]))
                    if iou(previous, chosen[0]) < float(settings["track_min_iou"]):
                        reason = "track_discontinuity"; break
                previous = chosen[0]
                try:
                    aligned, matrix = align_face(image, chosen[2], int(settings["image_size"]), float(settings["face_margin"]))
                except ValueError:
                    reason = "alignment_failed"; break
                relative = f"frames/{video_key}/{start:06d}/{start+offset:06d}.jpg"
                images.append((relative, aligned))
                metadata.append({"frame_index": start+offset, "timestamp_seconds": (start+offset)/fps if fps else None,
                                 "path": relative, "box": chosen[0].tolist(), "landmarks": chosen[2].tolist(),
                                 "affine": matrix.tolist(), "detection_probability": chosen[1]})
            if reason:
                rejected.append({"start": start, "reason": reason}); continue
            for relative, aligned in images:
                target = Path(output) / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                if not cv2.imwrite(str(target), aligned, [cv2.IMWRITE_JPEG_QUALITY, int(settings["jpeg_quality"])]):
                    raise IOError(f"Cannot save crop {target}")
            clip = {k: row[k] for k in ("dataset", "video_id", "method", "label", "group_id", "grouping_verified", "partition")}
            clip.update(clip_id=f"{row['video_id']}@{start:06d}", start_frame=start, fps=fps, frames=metadata)
            clips.append(clip)
    finally:
        cap.release()
    return clips, {"video_id": row["video_id"], "frame_count": count, "requested_clips": len(starts),
                   "valid_clips": len(clips), "rejected": rejected,
                   "status": "ok" if clips else "NO_VALID_CLIP"}


def preprocessing_identity(config):
    settings = {k: v for k, v in config["data"].items()
                if k not in ("device", "ffpp_splits_dir", "ffpp_revision", "min_drive_free_gib", "min_local_free_gib")}
    settings["implementation"] = sha256(Path(__file__))
    if config.get("smoke"):
        settings["detector_weights"] = "synthetic_fixture_only"
    else:
        import facenet_pytorch
        weights = Path(facenet_pytorch.__file__).parent / "data"
        settings["facenet_pytorch"] = importlib.metadata.version("facenet-pytorch")
        settings["detector_weights"] = {p.name: sha256(p) for p in sorted(weights.glob("*net.pt"))}
        if len(settings["detector_weights"]) != 3:
            raise RuntimeError("Cannot fingerprint the MTCNN weights")
    return fingerprint(settings), settings


def preprocess(config, selected=("ffpp", "uadfv"), detector=None):
    if config.get("cache_root"):
        raise ValueError("Shared source cache is read-only; preprocess using the original notebook")
    drive, local = paths(config)
    require_space(drive, config["data"]["min_drive_free_gib"])
    signature, settings = preprocessing_identity(config)
    if detector is None:
        detector = SyntheticFaceDetector() if config.get("smoke") else FaceDetector(config["data"]["device"])
    if isinstance(detector, SyntheticFaceDetector) and not config.get("smoke"):
        raise ValueError("Synthetic detector cannot be used in scientific experiments")
    for dataset in selected:
        rows, manifest = load_manifest(config, dataset)
        exclusions = load_exclusions(config, dataset, manifest)
        excluded = {entry["video_id"] for entry in exclusions}
        cache, identity, cache_settings = cache_location(config, dataset, manifest, signature, settings)
        cache.mkdir(parents=True, exist_ok=True)
        index = {"schema": 1, "dataset": dataset, "identity": identity, "manifest_sha256": manifest["sha256"],
                 "preprocessing": cache_settings, "smoke": bool(config.get("smoke")), "complete": False, "shards": []}
        if exclusions:
            index.update(coverage_policy(exclusions))
            print(f"{dataset}: explicitly excluding {len(exclusions)} videos: {sorted(excluded)}", flush=True)
        chunk = int(config["data"]["shard_videos"])
        for offset in range(0, len(rows), chunk):
            target = cache / f"{offset//chunk:05d}.tar"
            meta = target.with_suffix(".json")
            record = read_json(meta) if meta.exists() else {}
            if (target.exists() and record.get("sha256") == sha256(target)
                    and record.get("identity") == identity
                    and not (set(record.get("invalid_videos", [])) - excluded)
                    and set(record.get("excluded_videos", [])) <= excluded):
                print(f"{dataset}: reuse verified clip shard {offset//chunk}", flush=True)
            else:
                with scratch_directory(local, "temporal-shard-") as work:
                    clips, coverage = [], []
                    for row in rows[offset:offset+chunk]:
                        if row["video_id"] in excluded:
                            coverage.append({"video_id": row["video_id"], "valid_clips": 0,
                                             "status": "EXCLUDED", "rejected": []})
                            continue
                        raw = Path(row["raw_path"])
                        if not raw.is_file() or sha256(raw) != row["raw_sha256"]:
                            raise ValueError(f"Raw video changed: {row['video_id']}")
                        new, status = process_video(row, work, config["data"], detector)
                        clips.extend(new); coverage.append(status)
                    atomic_json(work / "clips.json", clips)
                    atomic_json(work / "coverage.json", coverage)
                    packed = work / "shard.tar"
                    with tarfile.open(packed, "w") as archive:
                        for path in sorted(work.rglob("*")):
                            if path.is_file() and path != packed:
                                archive.add(path, arcname=path.relative_to(work).as_posix(), recursive=False)
                    checksum = verified_copy(packed, target)
                    record = {"path": target.name, "sha256": checksum, "identity": identity,
                              "bytes": target.stat().st_size, "videos": len(coverage), "clips": len(clips),
                              "frames": sum(len(c["frames"]) for c in clips), "device": detector.device,
                              "invalid_videos": [c["video_id"] for c in coverage
                                                 if not c["valid_clips"] and c["video_id"] not in excluded],
                              "excluded_videos": [c["video_id"] for c in coverage if c["video_id"] in excluded]}
                    atomic_json(meta, record)
            index["shards"].append(record)
            atomic_json(cache / "index.json", index)
            atomic_json(cache.parent / "active.json", {"index": f"{cache.name}/index.json"})
            processed = sum(s["videos"] for s in index["shards"])
            saved_bytes = sum(s["bytes"] for s in index["shards"])
            remaining_gib = saved_bytes/max(1, processed)*max(0, len(rows)-processed)/1024**3
            print(f"{dataset}: persisted shard {offset//chunk}, {record['clips']} clips; "
                  f"estimated remaining frame cache {remaining_gib:.2f} GiB", flush=True)
            if not config.get("smoke"):
                require_space(drive, remaining_gib + .5*10*len(config["training"]["variants"]) + 4)
        invalid = [v for s in index["shards"] for v in s["invalid_videos"] if v not in excluded]
        if exclusions:
            index["source_videos"] = len(rows)
            index["included_videos"] = len(rows) - len(excluded)
        index["complete"] = not invalid
        atomic_json(cache / "index.json", index)
        if invalid:
            raise ValueError(f"{dataset}: {len(invalid)} videos have no valid consecutive clip; inspect coverage and rerun preprocessing")
        count = sum(s["videos"] for s in index["shards"])
        estimated = sum(s["bytes"] for s in index["shards"]) / max(1, count)
        print(f"{dataset}: cache complete; average {estimated/1024**2:.2f} MiB/video; video and frame archives are on Drive", flush=True)
    return selected


def materialize(config, dataset):
    drive, local = paths(config)
    base = Path(config.get("cache_root") or drive) / "temporal-cache" / dataset
    pointer = read_json(base / "active.json")
    index_path = safe_member(pointer["index"], base)
    index = read_json(index_path)
    if not index["complete"] or bool(index["smoke"]) != bool(config.get("smoke")):
        raise ValueError(f"{dataset}: cache incomplete or synthetic/production mismatch")
    for key in ("image_size", "clip_length", "frame_stride", "face_margin", "detector"):
        if index["preprocessing"][key] != config["data"][key]:
            raise ValueError(f"Source cache preprocessing differs: {key}")
    _, manifest = load_manifest(config, dataset)
    if index["manifest_sha256"] != manifest["sha256"]:
        raise ValueError("Cache and frozen manifest disagree")
    included, exclusions = effective_rows(config, dataset, manifest)
    if index.get("excluded_videos", []) != exclusions:
        raise ValueError("Exclusions changed; rerun preprocessing to finalize coverage")
    excluded = {entry["video_id"] for entry in exclusions}
    identity = fingerprint(index)
    restore = local / "temporal-materialized" / dataset / identity[:20]
    size = sum(s["bytes"] for s in index["shards"])
    clips = []
    print(f"{dataset}: restoring {len(index['shards'])} shards ({size/1024**3:.2f} GiB) to {restore}", flush=True)
    for shard_number, shard in enumerate(index["shards"]):
        target = restore / Path(shard["path"]).stem
        marker = target / "restored.json"
        valid = marker.exists() and read_json(marker).get("sha256") == shard["sha256"]
        existing = read_json(target / "clips.json") if valid else []
        valid = valid and all(safe_member(f["path"], target).is_file() for c in existing for f in c["frames"])
        if not valid:
            print(f"{dataset}: shard {shard_number+1}/{len(index['shards'])}: verify -> copy -> extract", flush=True)
            require_space(local, max(float(config["data"]["min_local_free_gib"]), shard["bytes"]*2.1/1024**3))
            source = safe_member(shard["path"], index_path.parent)
            if sha256(source) != shard["sha256"]:
                raise ValueError(f"Corrupt Drive cache shard: {source}")
            with scratch_directory(local, "restore-temporal-") as temp:
                packed = temp / "shard.tar"
                shutil.copyfile(source, packed)
                if sha256(packed) != shard["sha256"]:
                    raise IOError("Cache changed during local copy")
                extract_archive(packed, target)
            atomic_json(marker, {"sha256": shard["sha256"]})
            existing = read_json(target / "clips.json")
        print(f"{dataset}: shard {shard_number+1}/{len(index['shards'])} ready ({'restored' if not valid else 'reused'})", flush=True)
        for c in existing:
            if c["video_id"] in excluded:
                continue
            indices = [f["frame_index"] for f in c["frames"]]
            if (len(indices) != int(config["data"]["clip_length"])
                    or indices != list(range(indices[0], indices[0]+len(indices)))):
                raise ValueError("Cache contains a nonconsecutive or wrong-length clip")
            clips.append({**c, "paths": [str(safe_member(f["path"], target)) for f in c["frames"]]})
    if len({c["clip_id"] for c in clips}) != len(clips):
        raise ValueError("Duplicate clip IDs")
    expected = {r["video_id"] for r in included}
    if {c["video_id"] for c in clips} != expected:
        raise ValueError("Video coverage differs from frozen manifest")
    return clips, identity
