"""Incremental raw-video verification; decode locally and reuse unchanged files."""
import hashlib
from pathlib import Path
import re
import time

from ..common import atomic_json, paths, read_json, require_space, scratch_directory

CHECKER = "opencv-first-last-local-v1"


def copy_and_hash(source, target, label):
    digest = hashlib.sha256()
    copied = 0
    last_update = time.monotonic()
    with source.open("rb") as incoming, target.open("wb") as outgoing:
        for chunk in iter(lambda: incoming.read(1024*1024), b""):
            outgoing.write(chunk); digest.update(chunk); copied += len(chunk)
            now = time.monotonic()
            if now-last_update >= 5:
                print(f"  {label}: copied {copied/1024**2:.1f} MiB from Drive for local verification", flush=True)
                last_update = now
    return digest.hexdigest()


def verify_videos(config, dataset, rows, checker):
    """Return hashed rows and invalid rows. Never publish a partial manifest.

    The ledger is a resume optimization, keyed by size/mtime and checker version.
    Preprocessing still rehashes every raw video against the frozen manifest.
    """
    drive, local = paths(config)
    path = drive / "temporal-manifests" / f"verification-{dataset}.json"
    old = read_json(path) if path.exists() else {}
    ledger = old.get("files", {}) if old.get("schema") == 1 and old.get("checker") == CHECKER else {}
    verified, invalid, reused = [], [], 0
    started = time.monotonic()
    print(f"{dataset}: verifying {len(rows)} videos; unchanged verified files are reused. "
          "New/changed files are copied once and decoded locally (CPU).", flush=True)

    def persist():
        atomic_json(path, {"schema": 1, "checker": CHECKER, "files": ledger})

    with scratch_directory(local, "verify-video-") as work:
        try:
            for number, row in enumerate(rows, 1):
                source = Path(row["raw_path"])
                key = row["raw_relative_path"]
                if number == 1 or number % 25 == 0:
                    print(f"{dataset}: check {number}/{len(rows)} {key} "
                          f"(reused={reused}, elapsed={time.monotonic()-started:.0f}s)", flush=True)
                info = source.stat()
                stamp = {"bytes": info.st_size, "mtime_ns": info.st_mtime_ns}
                previous = ledger.get(key, {})
                unchanged = (all(previous.get(k) == v for k, v in stamp.items())
                             and re.fullmatch(r"[0-9a-f]{64}", str(previous.get("sha256", ""))))
                if unchanged:
                    digest = previous["sha256"]; reused += 1
                else:
                    print(f"{dataset}: reading {number}/{len(rows)} {key}", flush=True)
                    require_space(local, max(.001, info.st_size*1.1/1024**3))
                    temporary = work / ("video"+source.suffix)
                    digest = copy_and_hash(source, temporary, key)
                    after = source.stat()
                    if (after.st_size, after.st_mtime_ns) != (info.st_size, info.st_mtime_ns):
                        raise IOError(f"Raw video changed during verification: {key}; stop concurrent writers and retry")
                    try:
                        details = checker(temporary)
                    except ValueError as error:
                        print(f"{dataset}: INVALID {key}: {error}", flush=True)
                        ledger.pop(key, None); invalid.append(row)
                        if number == 1 or number % 25 == 0:
                            persist()
                        continue
                    ledger[key] = {**stamp, "sha256": digest, **details}
                verified.append({**row, "raw_sha256": digest})
                if number == 1 or number % 25 == 0:
                    persist()
        finally:
            persist()
    print(f"{dataset}: verification finished: {len(verified)} valid, {len(invalid)} invalid, "
          f"{reused} reused; elapsed={time.monotonic()-started:.0f}s", flush=True)
    return verified, invalid
