"""Synthetic fixtures exercise all 50 jobs, without downloading data or weights."""
from pathlib import Path
import zipfile

import torch
from torch import nn
from torch.nn import functional as F

from ..common import atomic_json, read_json, sha256
from ..smoke import make_video
from . import VARIANTS
from .config import load_config, run_folder
from .data import prepare
from .models import build_model
from .preprocess import materialize, preprocess
from .reporting import summarize
from .training import calibration, evaluate, evaluate_one, train_one


class TinyTokenEncoder(nn.Module):
    """Shape-compatible fixture, explicitly not an FA-ViT model."""
    def __init__(self):
        super().__init__()
        self.vit = nn.Linear(3, 768)
        for p in self.vit.parameters():
            p.requires_grad = False
        self.adapter = nn.LayerNorm(768)
        self.classifier = nn.Identity()

    def forward_tokens(self, images):
        feature = self.adapter(self.vit(images.mean(dim=(2, 3))))
        return feature.unsqueeze(1).expand(-1, 5, -1)


class TinySpatialCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.features = nn.Sequential(nn.Conv2d(3, 8, 3, stride=4, padding=1), nn.GELU(),
                                      nn.AvgPool2d(4), nn.Conv2d(8, 128, 1))
        self.proj = nn.Sequential(nn.Linear(128, 128), nn.LayerNorm(128))

    def forward_spatial_features(self, images):
        return self.features(images)

    def forward(self, images):
        return self.proj(self.features(images).mean(dim=(2, 3)))


def factory_for(config):
    return lambda variant: build_model(config, variant, TinyTokenEncoder, TinySpatialCNN, pretrained=False)


def create_fixture(folder):
    import yaml
    folder = Path(folder).resolve()
    if folder.exists() and any(folder.iterdir()):
        raise ValueError("Choose an empty smoke folder; existing results will be preserved")
    folder.mkdir(parents=True, exist_ok=True)
    config = yaml.safe_load((Path(__file__).resolve().parents[2]/"colab"/"experiment_config.temporal.yaml").read_text())
    drive = folder / "smoke-drive"
    splits = folder / "official-splits"
    pairs = [[f"{i*2:03d}", f"{i*2+1:03d}"] for i in range(10)]
    for name, entries in (("train", pairs[:8]), ("val", pairs[8:9]), ("test", pairs[9:])):
        atomic_json(splits / f"{name}.json", entries)
    for a, b in pairs:
        for name in (a, b):
            make_video(drive / "raw/ffpp/original" / f"{name}.mp4", frames=3)
        for method in ("Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures", "FaceShifter"):
            make_video(drive / "raw/ffpp" / method / f"{a}_{b}.mp4", fake=True, frames=3)
    for name in ("real", "fake"):
        for i in range(2):
            make_video(drive / "raw/uadfv" / name / f"{i:04d}.mp4", name == "fake", frames=3)
    config.update(drive_root=str(drive), local_root=str(folder/"local"), smoke=True, sources={})
    config["data"].update(clip_length=2, clips_per_video=2, eval_clips=1, shard_videos=14,
                          min_local_free_gib=.001, min_drive_free_gib=.001, ffpp_splits_dir=str(splits), device="cpu")
    config["training"].update(epochs=2, effective_batch_size=4, microbatch_size=2, num_workers=0,
                              pretrained=False, precision="fp32", keep_completed_resume=True)
    path = folder / "config.yaml"
    path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    return path


def run_smoke(folder):
    torch.set_num_threads(2)
    config = load_config(create_fixture(folder)); factory = factory_for(config)
    prepare(config); preprocess(config); preprocess(config)
    clips, identity = materialize(config, "ffpp")
    calibration(config, factory)
    external, ext_identity = materialize(config, "uadfv")
    for fold in range(1, 11):
        for variant in VARIANTS:
            train_one(config, variant, fold, clips, identity, factory, epoch_limit=1)
            train_one(config, variant, fold, clips, identity, factory)
            train_one(config, variant, fold, clips, identity, factory)  # Verify completed-run reuse.
            evaluate_one(config, variant, fold, "ffpp", clips, identity, factory)
            evaluate_one(config, variant, fold, "uadfv", external, ext_identity, factory)
    original_hashes = {f"{v}/{f}": sha256(run_folder(config, v, f)/"best.pt") for v in VARIANTS for f in range(1, 11)}
    # Celeb-DF arrives only AFTER all FF++ jobs. The ZIP has a wrapper directory.
    late = Path(folder) / "late-upload" / "wrapper"
    lines = []
    for label, name in ((1, "Celeb-real"), (0, "Celeb-synthesis")):
        for i in range(2):
            make_video(late / name / f"{i}.mp4", label == 0, frames=3)
            lines.append(f"{label} {name}/{i}.mp4")
    (late/"List_of_testing_videos.txt").write_text("\n".join(lines))
    archive = Path(folder)/"late-celebdf.zip"
    with zipfile.ZipFile(archive, "w") as packed:
        for p in late.rglob("*"):
            if p.is_file():
                packed.write(p, p.relative_to(late.parent))
    config["sources"]["celebdf"] = {"archive": str(archive)}
    prepare(config, ["celebdf"]); preprocess(config, ["celebdf"])
    assert materialize(config, "ffpp")[1] == identity
    evaluate(config, ["celebdf"], factory=factory)
    assert all(sha256(run_folder(config, v, f)/"best.pt") == original_hashes[f"{v}/{f}"] for v in VARIANTS for f in range(1, 11))
    summaries = summarize(config)
    assert len(summaries) == 15 and all(s["completed_folds"] == 10 for s in summaries)
    atomic_json(Path(folder)/"smoke-validation.json", {"provenance": "SYNTHETIC ONLY; not scientific results",
                "completed_runs": 50, "datasets": ["ffpp", "uadfv", "celebdf"], "late_upload_preserved_ffpp": True})
    print("SYNTHETIC temporal smoke passed: 50 resumed runs; these are NOT FA-ViT benchmark results.", flush=True)
    return config
