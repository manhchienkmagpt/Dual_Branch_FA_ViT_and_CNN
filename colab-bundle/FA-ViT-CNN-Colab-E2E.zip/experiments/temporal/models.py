"""Frame-matched spatial and temporal variants with one logit per clip."""
import torch
from torch import nn
from torch.nn import functional as F

from ..models import seed_everything
from . import VARIANTS


class TemporalBlock(nn.Module):
    def __init__(self, channels=128):
        super().__init__()
        self.depthwise = nn.Conv3d(channels*2, channels*2, (3, 1, 1), padding=(1, 0, 0), groups=channels*2)
        self.project = nn.Conv3d(channels*2, channels, 1)
        self.norm = nn.GroupNorm(8, channels)
        # Start from spatial features while letting the temporal weights learn.
        self.scale = nn.Parameter(torch.tensor(.01))

    def forward(self, features):
        # B,T,C,H,W -> B,C,T,H,W. No synthetic motion at the first frame.
        difference = torch.cat((torch.zeros_like(features[:, :1]), features[:, 1:]-features[:, :-1]), dim=1)
        value = torch.cat((features, difference), dim=2).transpose(1, 2)
        delta = self.norm(self.project(F.gelu(self.depthwise(value))))
        return features + self.scale * delta.transpose(1, 2)


class PatchFusion(nn.Module):
    def __init__(self, encoder_dim=768, channels=128):
        super().__init__()
        self.query = nn.Linear(encoder_dim, channels)
        self.query_norm = nn.LayerNorm(channels)
        self.local_norm = nn.LayerNorm(channels)
        self.attention = nn.MultiheadAttention(channels, 4, batch_first=True, dropout=0.)
        self.pool_score = nn.Linear(channels, 1)

    def forward(self, tokens, maps):
        local = maps.flatten(2).transpose(1, 2)
        query = self.query_norm(self.query(tokens))
        keys = self.local_norm(local)
        mixed, _ = self.attention(query, keys, local, need_weights=False)
        weights = self.pool_score(mixed).softmax(dim=1)
        return (weights*mixed).sum(dim=1) + local.mean(dim=1)


class ClipModel(nn.Module):
    def __init__(self, variant, config, encoder_factory=None, cnn_factory=None, pretrained=None):
        super().__init__()
        if variant not in VARIANTS:
            raise ValueError(f"Unsupported variant: {variant}")
        from training_model.models.redesigned_favit import RedesignedFAViT
        from training_model.models.favit_cnn import CNN_feature_extractor_branch
        self.variant = variant
        self.grid = 2 if config.get("smoke") else 14
        self.length = int(config["data"]["clip_length"])
        self.seed = int(config["training"]["seed"])
        training = config["training"]
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.seed)
            self.encoder = encoder_factory() if encoder_factory else RedesignedFAViT(
                training["backbone"], pretrained=training["pretrained"] if pretrained is None else pretrained)
            self.encoder.classifier = nn.Identity()
        self.has_cnn = variant != "favit_clip"
        self.has_temporal = variant in ("favit_cnn_temporal", "favit_cnn_no_patch")
        self.has_patch = variant in ("favit_cnn_temporal", "favit_cnn_no_temporal")
        if self.has_cnn:
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(self.seed+100_000)
                self.cnn = cnn_factory() if cnn_factory else CNN_feature_extractor_branch(3, 128)
        if self.has_temporal:
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(self.seed+300_000)
                self.temporal = TemporalBlock()
        if self.has_patch:
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(self.seed+400_000)
                self.fusion = PatchFusion()
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(self.seed+200_000)
            self.classifier = nn.Sequential(nn.LayerNorm(896 if self.has_cnn else 768),
                                            nn.Dropout(float(training["head_dropout"])),
                                            nn.Linear(896 if self.has_cnn else 768, 1))
        if training.get("strategy") == "balanced_v2":
            # Keep the same FA-ViT graph; allow the final pretrained blocks to adapt.
            blocks = getattr(self.encoder.vit, "blocks", [])
            count = min(len(blocks), int(training.get("finetune_blocks", 2)))
            if count:
                for block in blocks[-count:]:
                    block.requires_grad_(True)
                self.encoder.vit.norm.requires_grad_(True)
            # Running BN statistics are unreliable with two short clips per microbatch.
            self._replace_batch_norm(self)

    @staticmethod
    def _replace_batch_norm(module):
        for name, child in list(module.named_children()):
            if isinstance(child, nn.BatchNorm2d):
                channels = child.num_features
                groups = next(g for g in (8, 4, 2, 1) if channels % g == 0)
                replacement = nn.GroupNorm(groups, channels, eps=child.eps, affine=child.affine)
                if child.affine:
                    with torch.no_grad():
                        replacement.weight.copy_(child.weight); replacement.bias.copy_(child.bias)
                setattr(module, name, replacement)
            else:
                ClipModel._replace_batch_norm(child)

    def train(self, mode=True):
        super().train(mode)
        self.encoder.vit.eval()
        return self

    def forward(self, clips):
        if clips.ndim != 5 or clips.shape[2] != 3 or clips.shape[1] != self.length:
            raise ValueError(f"Expected [B,{self.length},3,H,W] clips")
        batch, time, channels, height, width = clips.shape
        frames = clips.reshape(batch*time, channels, height, width)
        tokens = self.encoder.forward_tokens(frames)
        global_features = tokens[:, 0]
        if self.has_cnn:
            if self.variant == "favit_cnn_clip":
                local = self.cnn(frames)
            else:
                maps = F.adaptive_avg_pool2d(self.cnn.forward_spatial_features(frames), (self.grid, self.grid))
                maps = maps.reshape(batch, time, 128, self.grid, self.grid)
                if self.has_temporal:
                    maps = self.temporal(maps)
                maps = maps.reshape(batch*time, 128, self.grid, self.grid)
                local = self.fusion(tokens[:, 1:], maps) if self.has_patch else maps.mean(dim=(2, 3))
                local = self.cnn.proj(local)
            global_features = torch.cat((global_features, local), dim=1)
        frame_logits = self.classifier(global_features).reshape(batch, time)
        return frame_logits.mean(dim=1)


def build_model(config, variant, encoder_factory=None, cnn_factory=None, pretrained=None):
    seed_everything(int(config["training"]["seed"]))
    return ClipModel(variant, config, encoder_factory, cnn_factory, pretrained)
