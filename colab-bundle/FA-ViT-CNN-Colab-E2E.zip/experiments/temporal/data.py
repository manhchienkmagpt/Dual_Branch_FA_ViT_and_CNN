"""CPU-only acquisition. No import of Torch, MTCNN, or training modules."""
from pathlib import Path
import shutil
import uuid
import math

from ..common import atomic_json, fingerprint, paths, read_json, require_space, sha256, verified_copy
from ..data import (build_celebdf_manifest, build_ffpp_manifest, build_uadfv_manifest,
                    download_ffpp, download_kaggle_dataset, extract_archive, fetch, videos)
from .config import freeze_protocol
from .folds import assign_folds
from .verification import verify_videos


def manifest_path(config, dataset):
    return Path(config.get("cache_root") or config["drive_root"]) / "temporal-manifests" / f"{dataset}.json"


def load_manifest(config, dataset):
    record = read_json(manifest_path(config, dataset))
    if record["sha256"] != fingerprint(record["videos"]):
        raise ValueError(f"Manifest checksum mismatch: {dataset}")
    raw = Path(config.get("cache_root") or config["drive_root"]) / "raw" / dataset
    return [{**r, "raw_path": str(raw / r["raw_relative_path"])} for r in record["videos"]], record


def check_video(path):
    import cv2
    cap = cv2.VideoCapture(str(path))
    try:
        count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        first, _ = cap.read()
        cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, count - 1))
        last, _ = cap.read()
        if count <= 0 or not math.isfinite(fps) or fps <= 0 or not first or not last:
            raise ValueError(f"Unreadable or incomplete raw video: {path}")
        return {"frames": count, "fps": fps}
    finally:
        cap.release()


def quarantine_incomplete(folder):
    """Retain damaged downloads, with a suffix the official downloader won't skip."""
    count = 0
    for path in videos(folder):
        try:
            check_video(path)
        except ValueError:
            path.rename(path.with_name(path.name + ".incomplete-" + uuid.uuid4().hex[:8]))
            count += 1
    return count


def archive_into_drive(config, dataset, source):
    drive, _ = paths(config)
    destination = drive / "raw" / dataset
    archive = fetch(source, drive / "downloads" / f"{dataset}.archive")
    checksum = sha256(archive)
    marker = destination / ".archive.json"
    if marker.exists() and read_json(marker)["sha256"] != checksum:
        raise ValueError("Archive differs from the frozen dataset; use a new Drive root")
    if not marker.exists():
        extract_archive(archive, destination)
        atomic_json(marker, {"sha256": checksum})
    return destination


def save_manifest(config, dataset, rows):
    portable = [{k: v for k, v in r.items() if k != "raw_path"} for r in rows]
    record = {"dataset": dataset, "videos": portable, "sha256": fingerprint(portable),
              "smoke": bool(config.get("smoke"))}
    target = manifest_path(config, dataset)
    if target.exists() and read_json(target)["sha256"] != record["sha256"]:
        raise ValueError(f"Frozen {dataset} videos changed; use a new Drive root")
    atomic_json(target, record)
    return record


def prepare(config, selected=("ffpp", "uadfv")):
    if config.get("cache_root"):
        raise ValueError("Shared source cache is read-only; prepare using the original notebook")
    print("Prepare started (CPU): inventory -> resume missing downloads -> incremental video verification.", flush=True)
    freeze_protocol(config)
    drive, _ = paths(config)
    require_space(drive, config["data"]["min_drive_free_gib"])
    for dataset in selected:
        if dataset not in ("ffpp", "uadfv", "celebdf"):
            raise ValueError("Unsupported dataset")
        folder = drive / "raw" / dataset
        folder.mkdir(parents=True, exist_ok=True)
        source = config.get("sources", {}).get(dataset, {})
        smoke = bool(config.get("smoke"))
        print(f"{dataset}: reading saved source configuration; raw folder: {folder}", flush=True)
        if dataset == "ffpp":
            splits = Path(config["data"].get("ffpp_splits_dir") or drive / "temporal-manifests" / "official-splits")
            for name in ("train", "val", "test"):
                target = splits / f"{name}.json"
                if not target.exists():
                    revision = config["data"]["ffpp_revision"]
                    print(f"ffpp: downloading source-pair metadata {name}.json", flush=True)
                    fetch(f"https://raw.githubusercontent.com/ondyari/FaceForensics/{revision}/dataset/splits/{name}.json", target)

            def inventory():
                print("ffpp: listing existing video filenames (no decoding or full-file hashing)", flush=True)
                found = videos(folder)
                print(f"ffpp: found {len(found)} video files; checking expected source IDs/counts", flush=True)
                return build_ffpp_manifest(folder, splits, smoke, digest=lambda path: "", discovered=found)

            def resume_download():
                if smoke or not source.get("accepted_terms") or not source.get("script"):
                    raise ValueError("FF++ incomplete: approve official terms and configure the approved downloader")
                print("ffpp: resuming missing downloads before deep verification", flush=True)
                script = fetch(source["script"], drive / "downloads" / "faceforensics_download_v4.py")
                download_ffpp(script, folder, source)

            try:
                rows = inventory()
            except ValueError as error:
                print(f"ffpp: inventory is not complete: {error}", flush=True)
                resume_download()
                rows = inventory()
            rows, invalid = verify_videos(config, dataset, rows, check_video)
            if invalid:
                for row in invalid:
                    path = Path(row["raw_path"])
                    path.rename(path.with_name(path.name+".incomplete-"+uuid.uuid4().hex[:8]))
                resume_download()
                rows, invalid = verify_videos(config, dataset, inventory(), check_video)
                if invalid:
                    raise ValueError("FF++ still has unreadable videos after one repair attempt; inspect the named files")
            rows, folds = assign_folds(rows, int(config["folds"]["seed"]))
            folds["official_split_checksums"] = {name: sha256(splits / f"{name}.json") for name in ("train", "val", "test")}
            frozen = drive / "temporal-manifests" / "folds.json"
            if frozen.exists() and read_json(frozen) != folds:
                raise ValueError("Frozen fold assignment changed")
            atomic_json(frozen, folds)
        elif dataset == "uadfv":
            try:
                rows = build_uadfv_manifest(folder, smoke, digest=lambda path: "")
            except ValueError:
                if source.get("source"):
                    folder = archive_into_drive(config, dataset, source["source"])
                elif source.get("provider") == "kagglehub" and not smoke:
                    # Kaggle's own download cache is also persistent across CPU/GPU sessions.
                    downloaded, marker, provenance = download_kaggle_dataset(source, dataset, drive, drive / "acquisition")
                    for path in videos(downloaded):
                        target = folder / path.relative_to(downloaded)
                        if not target.exists() or sha256(target) != sha256(path):
                            verified_copy(path, target)
                    atomic_json(marker, provenance)
                else:
                    raise ValueError("Provide raw UADFV videos or its configured source") from None
                rows = build_uadfv_manifest(folder, smoke, digest=lambda path: "")
            rows = [{**r, "partition": 0} for r in rows]
        else:
            archive = source.get("archive", "")
            if archive:
                if not Path(archive).is_file():
                    raise FileNotFoundError("Upload the Celeb-DF ZIP to Drive and set its local/mounted path; no URL download is performed")
                folder = archive_into_drive(config, dataset, archive)
            rows = [{**r, "partition": 0} for r in build_celebdf_manifest(folder, smoke, digest=lambda path: "")]
        if dataset != "ffpp":
            rows, invalid = verify_videos(config, dataset, rows, check_video)
            if invalid:
                raise ValueError(f"{dataset}: unreadable videos were listed above; repair the source before continuing")
        record = save_manifest(config, dataset, rows)
        size = sum(Path(r["raw_path"]).stat().st_size for r in rows)
        print(f"{dataset}: {len(rows)} videos verified on Drive ({size/1024**3:.2f} GiB); manifest {record['sha256'][:12]}", flush=True)
    return selected


def storage_report(config):
    drive, local = paths(config)
    result = {"drive_filesystem_free_gib": shutil.disk_usage(drive).free / 1024**3,
              "local_free_gib": shutil.disk_usage(local).free / 1024**3,
              "note": "Filesystem space may differ from Google Drive account quota; verify the account quota separately.",
              "raw": {}, "checkpoint_reserve_gib": .5 * 10 * len(config["training"]["variants"]) + 4}
    for dataset in ("ffpp", "uadfv", "celebdf"):
        raw = drive / "raw" / dataset
        result["raw"][dataset] = sum(p.stat().st_size for p in videos(raw)) / 1024**3
    return result
