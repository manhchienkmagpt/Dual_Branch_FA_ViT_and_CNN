"""Partition source pairs, never individual frames or manipulated videos."""
from collections import Counter
import json
import random

from ..common import fingerprint


def roles(fold):
    if fold not in range(1, 11):
        raise ValueError("fold must be in 1..10")
    order = [1 + (fold - 1 + offset) % 10 for offset in range(10)]
    return {"train": order[:8], "val": order[8:9], "test": order[9:]}


def assign_folds(rows, seed=42):
    if not rows or any(r["dataset"] != "ffpp" for r in rows):
        raise ValueError("FF++ rows required")
    if len({r["video_id"] for r in rows}) != len(rows):
        raise ValueError("Duplicate FF++ video IDs")
    groups = sorted({r["group_id"] for r in rows})
    if len(groups) < 10 or len(groups) % 10:
        raise ValueError("Source group count must be a positive multiple of ten")
    random.Random(seed).shuffle(groups)
    mapping = {group: 1 + i % 10 for i, group in enumerate(groups)}
    sources = {}
    output = []
    for r in rows:
        for source in json.loads(r["source_ids"]):
            if source in sources and sources[source] != r["group_id"]:
                raise ValueError("One source belongs to conflicting groups")
            sources[source] = r["group_id"]
        output.append({**r, "split": "pool", "partition": mapping[r["group_id"]]})
    partition_counts = Counter(mapping.values())
    return output, {"seed": seed, "groups": mapping, "groups_per_partition": {str(k): v for k, v in sorted(partition_counts.items())},
                    "schedule": {str(f): roles(f) for f in range(1, 11)}, "sha256": fingerprint(mapping),
                    "grouping": "source pairs; person identity separation is not independently established"}


def split_rows(rows, fold, split):
    selected = set(roles(fold)[split])
    return [r for r in rows if int(r["partition"]) in selected]
