"""Video experiments. Importing this package never imports Torch or requires CUDA."""

VARIANTS = (
    "favit_clip", "favit_cnn_clip", "favit_cnn_temporal",
    "favit_cnn_no_temporal", "favit_cnn_no_patch",
)
