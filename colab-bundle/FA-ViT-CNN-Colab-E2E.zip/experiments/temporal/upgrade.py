"""Train-only diagnostics and a small validation pilot before a full experiment."""
from pathlib import Path
import copy
import math

import torch
from torch import nn

from ..common import atomic_json, fingerprint, read_json
from ..training import precision_context
from .config import code_identity, run_folder, scientific_config
from .dataset import loader
from .folds import split_rows
from .models import build_model
from .preprocess import materialize
from .reporting import aggregate, metrics
from .training import calibration, device_for, make_optimizer, predict, train_one


def diagnose(config, variant, fold, steps=64, factory=None):
    if config["training"].get("strategy") != "balanced_v2" or steps < 1:
        raise ValueError("diagnose requires balanced_v2 and positive steps")
    settings = calibration(config, factory)
    device = device_for(config)
    clips, cache_identity = materialize(config, "ffpp")
    train = split_rows(clips, fold, "train")
    selected = []
    for label in (0, 1):
        ids = sorted({c["video_id"] for c in train if int(c["label"]) == label})[:8]
        selected.extend(next(c for c in train if c["video_id"] == key) for key in ids)
    # No validation/test samples, no augmentation, no persisted model/checkpoint.
    probe = copy.deepcopy(config)
    probe["training"]["diagnostic_no_augmentation"] = True
    model = (factory(variant) if factory else build_model(probe, variant)).to(device)
    optimizer = make_optimizer(model, probe["training"])
    criterion = nn.BCEWithLogitsLoss()
    tracked = next(p for p in model.classifier.parameters() if p.requires_grad)
    initial = tracked.detach().cpu().clone()
    def fixed_rows():
        return predict(model, selected, probe, device, settings)
    before = metrics(aggregate(fixed_rows()))
    norms, losses = [], []
    # Reuse fixed train-only inputs to separate optimizer failures from augmentation.
    batches = loader(selected, probe, True, 1, settings["microbatch_size"])
    iterator = iter(batches)
    for step in range(steps):
        try:
            images, labels, _ = next(iterator)
        except StopIteration:
            iterator = iter(batches); images, labels, _ = next(iterator)
        model.train(); optimizer.zero_grad(set_to_none=True)
        with precision_context(device, settings["precision"]):
            logits = model(images.to(device, non_blocking=True))
            loss = criterion(logits.float(), labels.to(device, non_blocking=True))
        if not torch.isfinite(loss):
            raise RuntimeError("Sanity check: non-finite loss")
        loss.backward()
        norm = nn.utils.clip_grad_norm_((p for p in model.parameters() if p.requires_grad), 1.)
        if not torch.isfinite(norm):
            raise RuntimeError("Sanity check: non-finite gradients")
        norms.append(float(norm)); losses.append(float(loss.detach()))
        optimizer.step()
        if (step+1) % 16 == 0 or step+1 == steps:
            print(f"sanity step={step+1}/{steps} loss={losses[-1]:.5f} gradient_norm={norms[-1]:.5f}", flush=True)
    after = metrics(aggregate(fixed_rows()))
    delta = float((tracked.detach().cpu()-initial).abs().max())
    passed = all(math.isfinite(n) for n in norms) and any(n > 0 for n in norms) and delta > 0
    report = {"provenance": "train-only diagnostic, not validation/test performance", "variant": variant,
              "fold": fold, "video_ids": [r["video_id"] for r in selected], "steps": steps,
              "passed_gradient_update_checks": passed, "head_max_abs_change": delta,
              "gradient_norm_max": max(norms), "first_loss": losses[0], "last_loss": losses[-1],
              "train_metrics_before": before, "train_metrics_after": after,
              "signature": fingerprint({"science": scientific_config(config), "code": code_identity(), "cache": cache_identity})}
    output = Path(config["drive_root"]) / "diagnostics" / variant / f"fold-{fold:02d}.json"
    atomic_json(output, report)
    print(f"Sanity diagnostic saved: {output}; gradient/update checks passed={passed}; "
          f"small-train AUC before={before['auc']:.4f} after={after['auc']:.4f}", flush=True)
    if not passed:
        raise RuntimeError("Sanity check failed: no finite gradients or parameter update")
    return report


def pilot(config, variant, fold, epochs=3, factory=None):
    if config["training"].get("strategy") != "balanced_v2" or epochs < 1:
        raise ValueError("pilot requires balanced_v2 and positive epochs")
    calibration(config, factory)
    clips, identity = materialize(config, "ffpp")
    train_one(config, variant, fold, clips, identity, factory, epoch_limit=epochs)
    history = read_json(run_folder(config, variant, fold) / "history.json")
    print("Pilot finished. Inspect loss, validation AUC, balanced accuracy and confusion matrix before more folds.", flush=True)
    print(f"Pilot checkpoint can resume from epoch {history[-1]['epoch']+1}; no external/test evaluation was used.", flush=True)
    return history
