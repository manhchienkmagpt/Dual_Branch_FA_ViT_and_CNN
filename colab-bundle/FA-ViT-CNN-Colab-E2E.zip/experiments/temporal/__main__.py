"""Stage-local imports keep acquisition usable without Torch installed."""
import argparse
import json
from pathlib import Path
import sys

from . import VARIANTS


def main():
    parser = argparse.ArgumentParser(description="CPU acquisition / MTCNN clips / temporal 10-fold experiments")
    parser.add_argument("stage", choices=("doctor", "prepare", "preprocess", "exclude-video", "diagnose", "pilot", "run", "evaluate", "summarize", "smoke"))
    parser.add_argument("--config")
    parser.add_argument("--dataset", choices=("ffpp", "uadfv", "celebdf", "all"), default="all")
    parser.add_argument("--variant", choices=(*VARIANTS, "all"), default="all")
    parser.add_argument("--fold", type=int, choices=range(1, 11))
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"))
    parser.add_argument("--calibrate", action="store_true")
    parser.add_argument("--video-id")
    parser.add_argument("--reason")
    parser.add_argument("--pilot-epochs", type=int, default=3)
    parser.add_argument("--sanity-steps", type=int, default=64)
    parser.add_argument("--output", default="experiment-output/temporal-smoke")
    args = parser.parse_args()
    if args.stage == "smoke":
        from .smoke import run_smoke
        run_smoke(args.output); return
    if not args.config:
        parser.error("--config is required")
    from .config import freeze_protocol, load_config
    config = load_config(args.config)
    if args.device:
        config["data"]["device"] = args.device
    if args.stage == "prepare":
        print("CPU prepare worker started; checking the saved protocol on Drive...", flush=True)
    freeze_protocol(config)
    variants = None if args.variant == "all" else [args.variant]
    if variants and args.variant not in config["training"]["variants"]:
        parser.error("Variant is not in the frozen experiment configuration")
    folds = [args.fold] if args.fold else None
    if args.stage == "doctor":
        from .data import storage_report
        report = storage_report(config)
        report.update(expected_training_runs=10*len(config["training"]["variants"]),
                      acquisition_requires_cuda=False, preprocessing_device=config["data"]["device"])
        print(json.dumps(report, indent=2))
        if args.calibrate:
            from .training import calibration
            print(json.dumps(calibration(config), indent=2))
    elif args.stage == "prepare":
        from .data import prepare
        prepare(config, ("ffpp", "uadfv") if args.dataset == "all" else [args.dataset])
    elif args.stage == "exclude-video":
        if args.dataset == "all" or not args.video_id or not args.reason:
            parser.error("exclude-video requires --dataset, --video-id and --reason")
        from .exclusions import register_exclusion
        register_exclusion(config, args.dataset, args.video_id, args.reason)
    elif args.stage == "preprocess":
        from .preprocess import preprocess
        preprocess(config, ("ffpp", "uadfv") if args.dataset == "all" else [args.dataset])
    elif args.stage in ("diagnose", "pilot"):
        if args.variant == "all" or not args.fold:
            parser.error("diagnose/pilot requires one --variant and --fold")
        from .upgrade import diagnose, pilot
        if args.stage == "diagnose":
            diagnose(config, args.variant, args.fold, args.sanity_steps)
        else:
            pilot(config, args.variant, args.fold, args.pilot_epochs)
    elif args.stage == "run":
        from .training import run
        run(config, variants, folds)
        from .reporting import summarize
        summarize(config)
    elif args.stage == "evaluate":
        from .training import evaluate
        selected = [d for d in ("ffpp", "uadfv", "celebdf")
                    if (Path(config.get("cache_root") or config["drive_root"])/"temporal-cache"/d/"active.json").exists()] if args.dataset == "all" else [args.dataset]
        if not selected:
            raise ValueError("No prepared clip cache to evaluate")
        evaluate(config, selected, variants, folds)
    else:
        from .reporting import summarize
        summarize(config)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError) as error:
        print(f"STOP: {error}", file=sys.stderr)
        raise SystemExit(1)
