"""Video-balanced training clips and deterministic, synchronized augmentation."""
from collections import defaultdict
import random

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, Sampler

from ..common import fingerprint


def select_clips(clips, training, seed, epoch, eval_clips):
    grouped = defaultdict(list)
    for clip in clips:
        grouped[clip["video_id"]].append(clip)
    output = []
    for video_id, entries in sorted(grouped.items()):
        entries = sorted(entries, key=lambda c: c["start_frame"])
        if training:
            index = int(fingerprint([seed, epoch, video_id])[:16], 16) % len(entries)
            output.append(entries[index])
        else:
            indices = np.unique(np.linspace(0, len(entries)-1, min(len(entries), eval_clips), dtype=int))
            output.extend(entries[i] for i in indices)
    return output


def transform_clip(paths, training, seed, policy="legacy"):
    rng = random.Random(seed)
    flip = training and rng.random() < .5
    gain = rng.uniform(.85, 1.15) if training else 1.
    bias = rng.uniform(-10, 10) if training else 0.
    jpeg = rng.randint(60, 95) if training and rng.random() < .25 else None
    blur = training and rng.random() < .1
    angle = rng.uniform(-8, 8) if training else 0.
    scale = rng.uniform(.95, 1.05) if training else 1.
    downscale = None
    if training and policy in ("warmup", "mild"):
        gain, bias, jpeg, blur, angle, scale = 1., 0., None, False, 0., 1.
        if policy == "mild":
            gain, bias = rng.uniform(.95, 1.05), rng.uniform(-3, 3)
            jpeg = rng.randint(80, 100) if rng.random() < .2 else None
            downscale = rng.uniform(.75, 1.) if rng.random() < .15 else None
    matrix = cv2.getRotationMatrix2D((111.5, 111.5), angle, scale)
    tensors = []
    for path in paths:
        image = cv2.imread(path)
        if image is None:
            raise IOError(f"Cannot read cached clip frame: {path}")
        image = cv2.resize(image, (224, 224), interpolation=cv2.INTER_AREA)
        if training:
            image = cv2.warpAffine(image, matrix, (224, 224), borderMode=cv2.BORDER_REFLECT_101)
            if flip:
                image = image[:, ::-1]
            image = np.clip(image.astype(np.float32)*gain+bias, 0, 255).astype(np.uint8)
            if blur:
                image = cv2.GaussianBlur(image, (3, 3), 0)
            if downscale:
                side = max(1, round(224*downscale))
                image = cv2.resize(cv2.resize(image, (side, side), interpolation=cv2.INTER_AREA),
                                   (224, 224), interpolation=cv2.INTER_LINEAR)
            if jpeg:
                ok, encoded = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, jpeg])
                if not ok:
                    raise IOError("JPEG augmentation failed")
                image = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB).astype(np.float32)/255.
        rgb = (rgb-np.array([.485, .456, .406], np.float32))/np.array([.229, .224, .225], np.float32)
        tensors.append(torch.from_numpy(np.ascontiguousarray(rgb.transpose(2, 0, 1))))
    return torch.stack(tensors)


class ClipDataset(Dataset):
    def __init__(self, clips, config, training=False, epoch=0):
        self.seed, self.epoch, self.training = int(config["training"]["seed"]), epoch, training
        self.augment = training and not config["training"].get("diagnostic_no_augmentation", False)
        self.rows = select_clips(clips, training, self.seed, epoch, int(config["data"]["eval_clips"]))
        self.balanced = training and config["training"].get("strategy") == "balanced_v2"
        self.available = defaultdict(list)
        if self.balanced:
            for clip in clips:
                self.available[clip["video_id"]].append(clip)
        self.policy = ("warmup" if epoch <= int(config["training"].get("augmentation_warmup_epochs", 2)) else "mild") if self.balanced else "legacy"
        if not self.rows:
            raise ValueError("Requested split contains no valid clips")

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        occurrence = None
        if isinstance(index, tuple):
            index, occurrence = index
        row = self.rows[index]
        if self.balanced and occurrence is not None:
            choices = self.available[row["video_id"]]
            pick = int(fingerprint([self.seed, self.epoch, occurrence, row["video_id"]])[:16], 16) % len(choices)
            row = choices[pick]
        key = [self.seed, self.epoch, row["clip_id"]]
        if occurrence is not None:
            key.append(occurrence)
        seed = int(fingerprint(key)[:8], 16)
        return transform_clip(row["paths"], self.augment, seed, self.policy), torch.tensor(int(row["label"]), dtype=torch.float32), index


class BalancedBatchSampler(Sampler):
    """Exactly half real / half fake per batch, using training videos only."""
    def __init__(self, rows, batch_size, seed):
        if batch_size < 2 or batch_size % 2:
            raise ValueError("Balanced batches require an even batch size")
        self.groups = {label: [i for i, row in enumerate(rows) if int(row["label"]) == label] for label in (0, 1)}
        if not all(self.groups.values()):
            raise ValueError("Balanced batches require both classes")
        self.batch_size, self.seed = batch_size, seed
        self.batches = (len(rows)+batch_size-1)//batch_size
        self.num_samples = self.batches*batch_size

    def __len__(self):
        return self.batches

    def __iter__(self):
        rng = random.Random(self.seed)
        pools, positions = {0: [], 1: []}, {0: 0, 1: 0}
        occurrence = 0
        for _ in range(self.batches):
            batch = []
            for label in (0, 1):
                for _ in range(self.batch_size//2):
                    if positions[label] == len(pools[label]):
                        pools[label] = self.groups[label].copy(); rng.shuffle(pools[label]); positions[label] = 0
                    batch.append((pools[label][positions[label]], occurrence))
                    positions[label] += 1; occurrence += 1
            rng.shuffle(batch)
            yield batch


def loader(clips, config, training=False, epoch=0, microbatch=1):
    dataset = ClipDataset(clips, config, training, epoch)
    generator = torch.Generator().manual_seed(int(config["training"]["seed"])*1009+epoch)
    if training and config["training"].get("strategy") == "balanced_v2":
        sampler = BalancedBatchSampler(dataset.rows, microbatch, int(config["training"]["seed"])*1009+epoch)
        return DataLoader(dataset, batch_sampler=sampler, num_workers=int(config["training"]["num_workers"]),
                          generator=generator, pin_memory=torch.cuda.is_available())
    return DataLoader(dataset, batch_size=microbatch, shuffle=training,
                      num_workers=int(config["training"]["num_workers"]), generator=generator,
                      pin_memory=torch.cuda.is_available(), persistent_workers=False)
