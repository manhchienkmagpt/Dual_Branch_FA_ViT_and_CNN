"""Protocol validation and identities usable in the CPU-only acquisition env."""
from pathlib import Path

from ..common import atomic_json, fingerprint, public_config, read_json, sha256
from . import VARIANTS


def load_config(path):
    import yaml
    config = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    for key in ("drive_root", "local_root"):
        if not isinstance(config.get(key), str) or not config[key].strip():
            raise ValueError(f"Set a nonempty {key}")
        config[key] = str(Path(config[key]).expanduser().resolve())
    if config["drive_root"] == config["local_root"]:
        raise ValueError("Drive and local scratch must be separate")
    if config.get("cache_root"):
        config["cache_root"] = str(Path(config["cache_root"]).expanduser().resolve())
        if config["cache_root"] in (config["drive_root"], config["local_root"]):
            raise ValueError("Read-only source cache must be separate from output and scratch")
        source, output = Path(config["cache_root"]), Path(config["drive_root"])
        if source.is_relative_to(output) or output.is_relative_to(source):
            raise ValueError("Read-only source and output roots cannot be nested")
    if config.get("smoke") and "smoke" not in Path(config["drive_root"]).name.lower():
        raise ValueError("Synthetic results require a separate smoke Drive root")
    d, t = config["data"], config["training"]
    if d["detector"] != "mtcnn" or int(d["image_size"]) != 224:
        raise ValueError("This protocol requires MTCNN and 224x224 images")
    if int(config["folds"]["count"]) != 10:
        raise ValueError("This protocol uses exactly ten rotating folds")
    if not t["variants"] or len(set(t["variants"])) != len(t["variants"]) or not set(t["variants"]) <= set(VARIANTS):
        raise ValueError("Choose distinct temporal experiment variants")
    for key in ("clip_length", "clips_per_video", "eval_clips", "shard_videos"):
        if int(d[key]) <= 0:
            raise ValueError(f"{key} must be positive")
    if int(d["clip_length"]) < 2 or int(d["frame_stride"]) != 1:
        raise ValueError("Use at least two consecutive frames, with stride one")
    if int(d["eval_clips"]) > int(d["clips_per_video"]):
        raise ValueError("eval_clips cannot exceed clips_per_video")
    if d.get("device", "auto") not in ("auto", "cpu", "cuda"):
        raise ValueError("Preprocessing device must be auto, cpu or cuda")
    if not 0 <= float(d["face_margin"]) <= 1 or not 1 <= int(d["jpeg_quality"]) <= 100:
        raise ValueError("Invalid crop margin or JPEG quality")
    if not 0 <= float(d["track_min_iou"]) <= 1 or not 0 <= float(d["detection_probability"]) <= 1:
        raise ValueError("Invalid tracking/detection thresholds")
    for key in ("epochs", "early_stopping_patience", "effective_batch_size", "microbatch_size"):
        if int(t[key]) <= 0:
            raise ValueError(f"training.{key} must be positive")
    if t["precision"] not in ("bf16", "fp16", "fp32"):
        raise ValueError("Unsupported precision")
    if float(config["evaluation"]["threshold"]) != .5:
        raise ValueError("This frozen protocol uses the fixed threshold 0.5")
    if not 0 <= float(t["label_smoothing"]) < 1 or not 0 <= float(t["head_dropout"]) < 1:
        raise ValueError("Invalid smoothing or dropout")
    if t.get("strategy", "legacy") not in ("legacy", "balanced_v2"):
        raise ValueError("Unknown training strategy")
    if t.get("strategy") == "balanced_v2":
        if int(t["microbatch_size"]) < 2 or int(t["microbatch_size"]) % 2:
            raise ValueError("Balanced training requires an even microbatch of at least two")
        if int(t["effective_batch_size"]) % int(t["microbatch_size"]):
            raise ValueError("Effective batch must be divisible by microbatch")
        if float(t["label_smoothing"]) != 0:
            raise ValueError("Balanced v2 uses unsmoothed, unweighted BCE")
        if not 0 <= int(t.get("finetune_blocks", 2)) <= 12:
            raise ValueError("finetune_blocks must be in 0..12")
        if any(float(t.get(key, fallback)) <= 0 for key, fallback in
               (("backbone_lr", 1e-5), ("head_lr", 3e-4))):
            raise ValueError("Learning rates must be positive")
    return config


def scientific_config(config):
    data = {k: v for k, v in config["data"].items()
            if k not in ("device", "ffpp_splits_dir", "min_drive_free_gib", "min_local_free_gib")}
    result = {"data": data, "folds": config["folds"], "training": config["training"],
              "evaluation": config["evaluation"], "smoke": bool(config.get("smoke"))}
    if config.get("cache_root"):
        result["cache_root"] = config["cache_root"]
    return result


def freeze_protocol(config):
    root = Path(config["drive_root"])
    root.mkdir(parents=True, exist_ok=True)
    path = root / "temporal-protocol.json"
    current = scientific_config(config)
    if path.exists() and read_json(path)["science"] != current:
        raise ValueError("Scientific configuration changed; choose a new Drive root")
    if not path.exists():
        # Source credentials/URLs and transient filesystem paths are not protocol inputs.
        atomic_json(path, {"science": current, "config": public_config(config)})


def code_identity():
    root = Path(__file__).resolve().parents[1]
    files = list((root / "temporal").glob("*.py"))
    files += [root / name for name in ("common.py", "data.py", "models.py", "training.py")]
    files += list((root.parent / "training_model" / "models").glob("*.py"))
    return fingerprint({p.relative_to(root.parent).as_posix(): sha256(p) for p in sorted(files)})


def run_folder(config, variant, fold):
    if variant not in VARIANTS or fold not in range(1, 11):
        raise ValueError("Invalid model or fold")
    return Path(config["drive_root"]) / "temporal-runs" / variant / f"fold-{fold:02d}"
