"""Measured clip/video reports; ten folds are not ten independent training seeds."""
from collections import defaultdict
import csv
import json
from pathlib import Path
import statistics

from ..common import atomic_json, read_json, sha256
from .config import run_folder
from .exclusions import effective_rows


def binary_metrics(labels, probabilities):
    if not labels or len(labels) != len(probabilities) or set(labels) != {0, 1}:
        raise ValueError("Metrics require both classes and paired predictions")
    import math
    if any(not math.isfinite(p) or not 0 <= p <= 1 for p in probabilities):
        raise ValueError("Invalid probability")
    tp = sum(y == 1 and p >= .5 for y, p in zip(labels, probabilities))
    tn = sum(y == 0 and p < .5 for y, p in zip(labels, probabilities))
    fp = sum(y == 0 and p >= .5 for y, p in zip(labels, probabilities))
    fn = sum(y == 1 and p < .5 for y, p in zip(labels, probabilities))
    ranked = sorted(zip(probabilities, labels))
    score, lower, i = 0., 0, 0
    while i < len(ranked):
        j = i+1
        while j < len(ranked) and ranked[j][0] == ranked[i][0]:
            j += 1
        negatives = sum(y == 0 for _, y in ranked[i:j])
        positives = j-i-negatives
        score += positives*(lower+.5*negatives)
        lower += negatives; i = j
    positives = sum(labels); negatives = len(labels)-positives
    precision = tp/(tp+fp) if tp+fp else 0.
    recall = tp/(tp+fn) if tp+fn else 0.
    return {"samples": len(labels), "auc": score/(positives*negatives), "accuracy": (tp+tn)/len(labels),
            "precision": precision, "recall": recall, "f1": 2*precision*recall/(precision+recall) if precision+recall else 0.,
            "confusion_matrix": [[tn, fp], [fn, tp]], "threshold": .5}


def aggregate(rows):
    groups = defaultdict(list)
    if len({r["clip_id"] for r in rows}) != len(rows):
        raise ValueError("Duplicate clip predictions")
    for row in rows:
        groups[row["video_id"]].append(row)
    videos = []
    for video, entries in sorted(groups.items()):
        if any(len({e[key] for e in entries}) != 1 for key in ("label", "dataset", "group_id", "partition", "method")):
            raise ValueError("Inconsistent metadata within a video")
        r = entries[0]
        videos.append({k: r[k] for k in ("dataset", "video_id", "label", "group_id", "partition", "method")} |
                      {"probability": statistics.mean(e["probability"] for e in entries), "clips": len(entries)})
    return videos


def metrics(rows):
    return binary_metrics([int(r["label"]) for r in rows], [float(r["probability"]) for r in rows])


def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name+".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    temporary.replace(path)


def publish_predictions(folder, dataset, clip_rows, checkpoint_sha256, cache_identity, signature):
    videos = aggregate(clip_rows)
    report = {"dataset": dataset, "clip": metrics(clip_rows), "video": metrics(videos),
              "checkpoint_sha256": checkpoint_sha256, "cache_identity": cache_identity, "run_signature": signature,
              "aggregation": "mean clip probabilities; each clip uses mean frame logits"}
    write_csv(folder / f"predictions-{dataset}-clips.csv", clip_rows)
    write_csv(folder / f"predictions-{dataset}-videos.csv", videos)
    report["prediction_checksums"] = {level: sha256(folder / f"predictions-{dataset}-{level}.csv")
                                       for level in ("clips", "videos")}
    atomic_json(folder / f"metrics-{dataset}.json", report)
    return report


def summarize(config):
    root = Path(config["drive_root"])
    output = root / "temporal-summaries"
    measured, progress, oof = [], [], []
    for variant in config["training"]["variants"]:
        variant_oof = []
        for fold in range(1, 11):
            folder = run_folder(config, variant, fold)
            state = read_json(folder / "state.json") if (folder / "state.json").exists() else {"status": "not_started"}
            progress.append({"variant": variant, "fold": fold, "status": state["status"], "epoch": state.get("epoch", 0)})
            for dataset in ("ffpp", "uadfv", "celebdf"):
                path = folder / f"metrics-{dataset}.json"
                if not path.exists():
                    continue
                report = read_json(path)
                if state.get("status") != "completed" or report["checkpoint_sha256"] != state.get("best_sha256"):
                    raise ValueError("Report refers to an unfinished run or different checkpoint")
                for level, checksum in report["prediction_checksums"].items():
                    if sha256(folder / f"predictions-{dataset}-{level}.csv") != checksum:
                        raise ValueError("Prediction export checksum mismatch; rerun evaluation")
                measured.append({"variant": variant, "fold": fold, "dataset": dataset,
                                 **{k: v for k, v in report["video"].items() if k != "confusion_matrix"}})
                if dataset == "ffpp":
                    with (folder / "predictions-ffpp-videos.csv").open(newline="", encoding="utf-8") as stream:
                        variant_oof.extend({**r, "variant": variant, "fold": fold} for r in csv.DictReader(stream))
        if variant_oof:
            if len({r["video_id"] for r in variant_oof}) != len(variant_oof):
                raise ValueError("An FF++ video has multiple out-of-fold test predictions")
            if len([r for r in measured if r["variant"] == variant and r["dataset"] == "ffpp"]) == 10:
                from .data import load_manifest
                _, manifest = load_manifest(config, "ffpp")
                expected, _ = effective_rows(config, "ffpp", manifest)
                if {r["video_id"] for r in variant_oof} != {r["video_id"] for r in expected}:
                    raise ValueError("Complete OOF results do not cover the frozen FF++ video set")
            oof.extend(variant_oof)
    summaries = []
    for variant in config["training"]["variants"]:
        for dataset in ("ffpp", "uadfv", "celebdf"):
            entries = [r for r in measured if r["variant"] == variant and r["dataset"] == dataset]
            if entries:
                result = {"variant": variant, "dataset": dataset, "completed_folds": len(entries)}
                for key in ("auc", "accuracy", "precision", "recall", "f1"):
                    values = [r[key] for r in entries]
                    result[key+"_mean"] = statistics.mean(values)
                    result[key+"_sd_across_folds"] = statistics.stdev(values) if len(values) > 1 else None
                if dataset == "ffpp":
                    entries_oof = [r for r in oof if r["variant"] == variant]
                    result["oof_video_metrics"] = metrics(entries_oof)
                    result["oof_complete"] = len(entries) == 10
                summaries.append(result)
    output.mkdir(parents=True, exist_ok=True)
    exclusions = {}
    from .data import load_manifest, manifest_path
    for dataset in ("ffpp", "uadfv", "celebdf"):
        if manifest_path(config, dataset).exists():
            _, manifest = load_manifest(config, dataset)
            included, entries = effective_rows(config, dataset, manifest)
            exclusions[dataset] = {"source_videos": len(manifest["videos"]),
                                   "included_videos": len(included), "excluded_videos": entries}
    atomic_json(output / "progress.json", {"expected_runs": 10*len(config["training"]["variants"]), "runs": progress})
    atomic_json(output / "results.json", {"provenance": "SYNTHETIC SMOKE ONLY" if config.get("smoke") else "measured",
                "summaries": summaries, "fold_metrics": measured, "coverage": exclusions,
                "limitations": ["Fold SD is not training-seed SD; fold training sets share data.",
                                "External datasets are repeated evaluations of the same videos, not enlarged samples.",
                                "Baseline is the project's simplified FA-ViT implementation, not the full original method."]})
    if measured:
        write_csv(output / "fold-metrics.csv", measured)
    if oof:
        write_csv(output / "ffpp-out-of-fold.csv", oof)
    lines = ["# Kết quả FA-ViT-CNN temporal 10-fold", "",
             "DỮ LIỆU TỔNG HỢP — KHÔNG PHẢI KẾT QUẢ KHOA HỌC." if config.get("smoke") else "Chỉ báo cáo số liệu đã đo.",
             "", "| Model | Dataset | Folds | Video AUC mean ± SD (%) |", "|---|---|---:|---:|"]
    for row in summaries:
        sd = row["auc_sd_across_folds"]
        text = f"{100*row['auc_mean']:.2f} ± {100*sd:.2f}" if sd is not None else f"{100*row['auc_mean']:.2f} (SD: N/A)"
        lines.append(f"| {row['variant']} | {row['dataset']} | {row['completed_folds']} | {text} |")
    lines += ["", "SD qua fold không phải SD qua seed. Các tập train giữa fold dùng chung dữ liệu.",
              "Celeb-DF/UADFV được đánh giá bằng từng checkpoint FF++ đã chọn; không chọn fold tốt nhất theo tập ngoài.",
              "Baseline là FA-ViT giản lược của dự án. Số liệu chưa đủ 10 fold được đánh dấu bằng số fold thực tế."]
    for dataset, coverage in exclusions.items():
        if coverage["excluded_videos"]:
            lines += ["", f"{dataset}: dùng {coverage['included_videos']}/{coverage['source_videos']} video."]
            lines += [f"- Loại {entry['video_id']}: {entry['reason']}" for entry in coverage["excluded_videos"]]
    (output / "REPORT-VI.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    print(f"Reports saved: {output}", flush=True)
    return summaries
