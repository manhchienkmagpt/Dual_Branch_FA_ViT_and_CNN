"""Fold-isolated training, video-AUC selection and recoverable epoch commits."""
import math
from pathlib import Path
import time

import torch
from torch import nn

from ..common import (atomic_json, atomic_torch_save, fingerprint, paths, read_json, require_space,
                      save_environment, sha256, environment)
from ..models import encoder_hash, parameter_counts
from ..training import cpu_state, ensure_best, precision_context, restore_rng, rng_state
from .config import code_identity, freeze_protocol, run_folder, scientific_config
from .dataset import loader
from .folds import split_rows
from .models import build_model
from .preprocess import materialize
from .reporting import aggregate, metrics, publish_predictions


def device_for(config):
    if config.get("smoke"):
        return torch.device("cpu")
    if not torch.cuda.is_available():
        raise RuntimeError("Enable a GPU runtime for training/inference. Downloading and MTCNN CPU do not need CUDA.")
    if config["training"]["precision"] == "bf16" and not torch.cuda.is_bf16_supported():
        raise RuntimeError("The frozen BF16 protocol requires a compatible GPU, such as L4")
    return torch.device("cuda")


def calibration(config, factory=None):
    freeze_protocol(config)
    drive, _ = paths(config)
    device = device_for(config)
    signature = fingerprint({"science": scientific_config(config), "code": code_identity()})
    path = drive / "temporal-runtime.json"
    if path.exists():
        record = read_json(path)
        if record["signature"] != signature:
            raise ValueError("Calibration/config/code changed; choose a new experiment root")
        return record
    limit = int(config["training"]["microbatch_size"])
    effective = int(config["training"]["effective_batch_size"])
    precision = "fp32" if config.get("smoke") else config["training"]["precision"]
    candidates = (2,) if config["training"].get("strategy") == "balanced_v2" else (2, 1)
    for batch in candidates:
        if batch > limit or effective % batch:
            continue
        try:
            for variant in config["training"]["variants"]:
                model = optimizer = loss = images = None
                try:
                    model = (factory(variant) if factory else build_model(config, variant, pretrained=False)).to(device).train()
                    optimizer = torch.optim.AdamW((p for p in model.parameters() if p.requires_grad), lr=1e-4)
                    images = torch.randn(batch, int(config["data"]["clip_length"]), 3, 224, 224, device=device)
                    with precision_context(device, precision):
                        loss = model(images).float().square().mean()
                    loss.backward(); optimizer.step()
                finally:
                    del model, optimizer, loss, images
                    if device.type == "cuda":
                        torch.cuda.empty_cache()
            record = {"microbatch_size": batch, "precision": precision, "signature": signature,
                      "effective_batch_size": effective, "gpu": torch.cuda.get_device_name() if device.type == "cuda" else "SYNTHETIC CPU",
                      "environment": environment()}
            atomic_json(path, record)
            return record
        except torch.cuda.OutOfMemoryError:
            print(f"Calibration: microbatch {batch} OOM; trying a smaller common microbatch", flush=True)
    raise RuntimeError("No common microbatch fits; use a larger GPU or start a new protocol")


def runtime(config):
    record = read_json(Path(config["drive_root"]) / "temporal-runtime.json")
    expected = fingerprint({"science": scientific_config(config), "code": code_identity()})
    if record["signature"] != expected:
        raise ValueError("Runtime/code/protocol differs from calibration")
    # CUDA patch versions may change across Colab sessions, but science libraries must match.
    current = environment()["packages"]
    keys = ("torch", "torchvision", "timm", "numpy", "opencv-python-headless")
    if any(current.get(k) != record["environment"]["packages"].get(k) for k in keys):
        raise ValueError("Training dependency versions changed since calibration")
    return record


def predict(model, clips, config, device, settings):
    batches = loader(clips, config, microbatch=settings["microbatch_size"])
    model.eval(); rows = []
    with torch.no_grad():
        for images, labels, indices in batches:
            with precision_context(device, settings["precision"]):
                logits = model(images.to(device))
            probabilities = torch.sigmoid(logits.float()).cpu().tolist()
            for index, probability in zip(indices.tolist(), probabilities):
                c = batches.dataset.rows[index]
                rows.append({k: c[k] for k in ("dataset", "video_id", "clip_id", "label", "group_id", "partition", "method")} |
                            {"probability": probability})
            if len(rows) % 500 == 0 or len(rows) == len(batches.dataset):
                print(f"validation/inference: clips={len(rows)}/{len(batches.dataset)}", flush=True)
    if {r["video_id"] for r in rows} != {c["video_id"] for c in clips}:
        raise ValueError("Prediction coverage differs from input videos")
    return rows


def epoch_train(model, clips, config, device, settings, optimizer, scaler, criterion, epoch):
    batches = loader(clips, config, True, epoch, settings["microbatch_size"])
    model.train(); optimizer.zero_grad(set_to_none=True)
    effective = int(config["training"]["effective_batch_size"])
    sample_count = getattr(batches.batch_sampler, "num_samples", len(batches.dataset))
    upgraded = config["training"].get("strategy") == "balanced_v2"
    processed = window = 0; total = 0.; started = time.monotonic()
    grad_norms = []
    for images, labels, _ in batches:
        if window == 0:
            denominator = min(effective, sample_count-processed)
        labels = labels.to(device, non_blocking=True)
        smoothing = float(config["training"]["label_smoothing"])
        targets = labels*(1-smoothing)+.5*smoothing
        with precision_context(device, settings["precision"]):
            logits = model(images.to(device, non_blocking=True))
            loss = criterion(logits.float(), targets)
        if not torch.isfinite(loss):
            raise FloatingPointError("Non-finite training loss")
        scaler.scale(loss/denominator).backward()
        window += len(labels); processed += len(labels)
        total += float(loss.detach())
        if window == denominator:
            if upgraded:
                scaler.unscale_(optimizer)
                norm = nn.utils.clip_grad_norm_((p for p in model.parameters() if p.requires_grad), 1.)
                if not torch.isfinite(norm):
                    raise FloatingPointError("Non-finite gradient norm")
                grad_norms.append(float(norm))
            scaler.step(optimizer); scaler.update(); optimizer.zero_grad(set_to_none=True); window = 0
        if processed % 100 == 0 or processed == sample_count:
            unit = "sampled_clips" if upgraded else "videos"
            print(f"train epoch={epoch} {unit}={processed}/{sample_count} loss={total/processed:.5f} elapsed={time.monotonic()-started:.0f}s", flush=True)
    result = {"loss": total/processed, "videos": processed, "seconds": time.monotonic()-started}
    if upgraded:
        result.update(sampling="half real / half fake per batch; repeats allowed", unique_source_videos=len(batches.dataset),
                      gradient_norm_mean=sum(grad_norms)/len(grad_norms) if grad_norms else 0.)
        if not any(n > 0 for n in grad_norms):
            raise RuntimeError("No nonzero gradients observed; stop before further folds")
    return result


def make_optimizer(model, training):
    if training.get("strategy") != "balanced_v2":
        return torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),
                                lr=float(training["lr"]), weight_decay=float(training["weight_decay"]))
    groups = {"backbone": [], "adapters": [], "heads": []}
    for name, parameter in model.named_parameters():
        if parameter.requires_grad:
            key = "backbone" if name.startswith("encoder.vit.") else "adapters" if name.startswith("encoder.") else "heads"
            groups[key].append(parameter)
    rates = {"backbone": float(training.get("backbone_lr", 1e-5)), "adapters": float(training["lr"]),
             "heads": float(training.get("head_lr", 3e-4))}
    return torch.optim.AdamW([{"params": values, "lr": rates[name], "name": name}
                             for name, values in groups.items() if values], weight_decay=float(training["weight_decay"]))


def train_one(config, variant, fold, clips, cache_identity, factory=None, epoch_limit=None):
    freeze_protocol(config)
    device = device_for(config); settings = runtime(config)
    train = split_rows(clips, fold, "train"); val = split_rows(clips, fold, "val")
    video_labels = {c["video_id"]: int(c["label"]) for c in train}
    if set(video_labels.values()) != {0, 1} or {int(c["label"]) for c in val} != {0, 1}:
        raise ValueError("Train and validation must each contain both classes")
    group_sets = [{c["group_id"] for c in split_rows(clips, fold, split)} for split in ("train", "val", "test")]
    if any(group_sets[a] & group_sets[b] for a, b in ((0, 1), (0, 2), (1, 2))):
        raise ValueError("Source group crosses fold split boundaries")
    drive, local = paths(config); folder = run_folder(config, variant, fold); folder.mkdir(parents=True, exist_ok=True)
    signature = fingerprint({"science": scientific_config(config), "code": code_identity(), "cache": cache_identity,
                             "runtime": settings, "variant": variant, "fold": fold})
    previous = read_json(folder / "state.json") if (folder / "state.json").exists() else {}
    if previous and previous["signature"] != signature:
        raise ValueError("Checkpoint/config/fold/data mismatch; choose a new Drive root")
    if previous.get("status") == "completed":
        if sha256(folder / "best.pt") != previous["best_sha256"]:
            raise ValueError("Completed best checkpoint is corrupt")
        print(f"Skip completed {variant} fold {fold}", flush=True); return
    require_space(drive, .01 if config.get("smoke") else 3)
    model = (factory(variant) if factory else build_model(config, variant)).to(device)
    initial_hash = encoder_hash(model)
    initial_path = drive / "temporal-initialization.json"
    if initial_path.exists() and read_json(initial_path)["encoder_sha256"] != initial_hash:
        raise ValueError("Encoder initialization differs between variants/folds")
    atomic_json(initial_path, {"encoder_sha256": initial_hash, "seed": config["training"]["seed"]})
    training = config["training"]
    optimizer = make_optimizer(model, training)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=float(training["scheduler_factor"]),
                patience=max(0, int(training["scheduler_patience"])-1), min_lr=float(training["min_lr"]))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and settings["precision"] == "fp16")
    positives = sum(video_labels.values()); weight = (len(video_labels)-positives)/positives
    upgraded = training.get("strategy") == "balanced_v2"
    criterion = nn.BCEWithLogitsLoss(pos_weight=None if upgraded else torch.tensor(weight, device=device), reduction="sum")
    start, best, bad, history, best_hash = 1, -math.inf, 0, [], None
    last = folder / "last.pt"
    if last.exists():
        saved = torch.load(last, map_location="cpu", weights_only=False)
        if saved["signature"] != signature:
            raise ValueError("Last checkpoint does not match this run")
        model.load_state_dict(saved["model"], strict=True); optimizer.load_state_dict(saved["optimizer"])
        scheduler.load_state_dict(saved["scheduler"]); scaler.load_state_dict(saved["scaler"])
        restore_rng(saved["rng"])
        start, best, bad, history, best_hash = saved["epoch"]+1, saved["best"], saved["bad_epochs"], saved["history"], saved["best_sha256"]
        ensure_best(folder, best_hash)
    elif previous.get("epoch", 0):
        raise ValueError("Resume file missing for an unfinished run")
    save_environment(folder)
    atomic_json(folder / "model-info.json", {**parameter_counts(model), "encoder_initial_sha256": initial_hash,
                "pos_weight_train_only": None if upgraded else weight,
                "sampling": "balanced_batches" if upgraded else "one_clip_per_video",
                "variant": variant, "fold": fold, "signature": signature})
    stop = int(training["epochs"])
    if epoch_limit:
        stop = min(stop, start+epoch_limit-1)
    atomic_json(folder / "state.json", {"status": "running", "signature": signature, "epoch": start-1, "best_sha256": best_hash})
    try:
        for epoch in range(start, stop+1):
            if bad >= int(training["early_stopping_patience"]):
                break
            print(f"{variant}: fold {fold}/10, epoch {epoch}/{training['epochs']}", flush=True)
            train_stats = epoch_train(model, train, config, device, settings, optimizer, scaler, criterion, epoch)
            print(f"epoch={epoch}: training finished; starting validation", flush=True)
            val_rows = predict(model, val, config, device, settings)
            val_videos = aggregate(val_rows)
            val_stats = metrics(val_videos); score = val_stats["auc"]
            matrix = val_stats["confusion_matrix"]
            val_stats["balanced_accuracy"] = .5*(matrix[0][0]/sum(matrix[0])+matrix[1][1]/sum(matrix[1]))
            val_stats["probability_mean_by_label"] = {str(label): sum(r["probability"] for r in val_videos if r["label"] == label)/sum(r["label"] == label for r in val_videos) for label in (0, 1)}
            improved = score > best
            print(f"epoch={epoch}: validation video AUC={score:.5f} accuracy={val_stats['accuracy']:.5f} "
                  f"balanced_accuracy={val_stats['balanced_accuracy']:.5f} confusion={matrix}", flush=True)
            if improved:
                best, bad = score, 0
                best_hash = atomic_torch_save({"model": cpu_state(model), "signature": signature, "variant": variant,
                    "fold": fold, "epoch": epoch, "smoke": bool(config.get("smoke"))}, folder / ".best-candidate.pt", local)
            else:
                bad += 1
            scheduler.step(score)
            history.append({"epoch": epoch, "train": train_stats, "validation_video": val_stats,
                            "lr": optimizer.param_groups[0]["lr"], "bad_epochs": bad})
            print(f"epoch={epoch}: saving last.pt and {'new best.pt' if improved else 'retaining best.pt'} (best AUC={best:.5f})", flush=True)
            atomic_torch_save({"model": cpu_state(model), "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                "scaler": scaler.state_dict(), "rng": rng_state(), "signature": signature, "epoch": epoch, "best": best,
                "bad_epochs": bad, "history": history, "best_sha256": best_hash}, last, local)
            ensure_best(folder, best_hash)
            atomic_json(folder / "history.json", history)
            atomic_json(folder / "state.json", {"status": "running", "signature": signature, "epoch": epoch, "best_sha256": best_hash})
            print(f"epoch={epoch}: checkpoint committed: {last}; best AUC={best:.5f}; no-improvement={bad}/{training['early_stopping_patience']}", flush=True)
        completed = bool(history) and (history[-1]["epoch"] >= int(training["epochs"]) or bad >= int(training["early_stopping_patience"]))
        atomic_json(folder / "state.json", {"status": "completed" if completed else "interrupted", "signature": signature,
                    "epoch": history[-1]["epoch"] if history else start-1, "best_sha256": best_hash, "smoke": bool(config.get("smoke"))})
        if completed and not training["keep_completed_resume"]:
            if sha256(folder / "best.pt") != best_hash:
                raise IOError("Best verification failed; retaining resume")
            last.unlink(missing_ok=True)
    except BaseException:
        # Preserve the last committed epoch; don't claim in-progress work was saved.
        committed = torch.load(last, map_location="cpu", weights_only=False) if last.exists() else None
        atomic_json(folder / "state.json", {"status": "interrupted", "signature": signature,
                    "epoch": committed["epoch"] if committed else 0,
                    "best_sha256": committed["best_sha256"] if committed else None})
        raise


def evaluate_one(config, variant, fold, dataset, clips, cache_identity, factory=None):
    device = device_for(config); settings = runtime(config)
    folder = run_folder(config, variant, fold); state = read_json(folder / "state.json")
    if state["status"] != "completed" or sha256(folder / "best.pt") != state["best_sha256"]:
        raise ValueError("Evaluation requires a completed, verified best checkpoint")
    result = folder / f"metrics-{dataset}.json"
    if result.exists():
        old = read_json(result)
        if old["checkpoint_sha256"] == state["best_sha256"] and old["cache_identity"] == cache_identity:
            # Restore deleted exports by evaluating again rather than reporting stale completion.
            if all((folder / f"predictions-{dataset}-{level}.csv").exists()
                   and sha256(folder / f"predictions-{dataset}-{level}.csv") == old.get("prediction_checksums", {}).get(level)
                   for level in ("clips", "videos")):
                return old
    model = (factory(variant) if factory else build_model(config, variant)).to(device)
    saved = torch.load(folder / "best.pt", map_location="cpu", weights_only=False)
    if saved["signature"] != state["signature"] or saved["variant"] != variant or saved["fold"] != fold:
        raise ValueError("Checkpoint provenance mismatch")
    model.load_state_dict(saved["model"], strict=True)
    selected = split_rows(clips, fold, "test") if dataset == "ffpp" else clips
    predictions = predict(model, selected, config, device, settings)
    return publish_predictions(folder, dataset, predictions, state["best_sha256"], cache_identity, state["signature"])


def run(config, variants=None, folds=None, factory=None):
    calibration(config, factory)
    clips, identity = materialize(config, "ffpp")
    variants = variants or config["training"]["variants"]
    for fold in folds or range(1, 11):
        for variant in variants:
            train_one(config, variant, fold, clips, identity, factory)
            evaluate_one(config, variant, fold, "ffpp", clips, identity, factory)
            for dataset in ("uadfv",):
                if (Path(config.get("cache_root") or config["drive_root"]) / "temporal-cache" / dataset / "active.json").exists():
                    external, external_hash = materialize(config, dataset)
                    evaluate_one(config, variant, fold, dataset, external, external_hash, factory)
            from .reporting import summarize
            summarize(config)


def evaluate(config, datasets, variants=None, folds=None, factory=None):
    for dataset in datasets:
        clips, identity = materialize(config, dataset)
        for variant in variants or config["training"]["variants"]:
            for fold in folds or range(1, 11):
                evaluate_one(config, variant, fold, dataset, clips, identity, factory)
