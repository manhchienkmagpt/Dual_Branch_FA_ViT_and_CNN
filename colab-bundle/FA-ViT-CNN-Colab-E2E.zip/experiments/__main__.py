import argparse
import json
import sys

from .common import DATASETS, VARIANTS, environment, load_config, paths, public_config, storage_estimate


def main():
    parser = argparse.ArgumentParser(description="Manifest-based FA-ViT-CNN Colab experiments")
    parser.add_argument("stage", choices=("doctor", "prepare", "preprocess", "train", "evaluate", "summarize", "smoke"))
    parser.add_argument("--config", help="YAML configuration")
    parser.add_argument("--dataset", choices=(*DATASETS, "all"), default="all")
    parser.add_argument("--variant", choices=(*VARIANTS, "all"), default="all")
    parser.add_argument("--seed", type=int, help="One seed; omit for all configured seeds")
    parser.add_argument("--calibrate", action="store_true", help="Probe GPU memory; freeze common microbatch/precision")
    parser.add_argument("--output", default="experiment-output/smoke", help="Empty output folder for synthetic smoke only")
    args = parser.parse_args()
    if args.stage == "smoke":
        from .smoke import run_smoke
        run_smoke(args.output)
        return
    if not args.config:
        parser.error("--config is required")
    config = load_config(args.config)
    if args.stage == "doctor":
        import shutil
        import torch
        drive, local = paths(config)
        report = {"environment": environment(), "config": public_config(config),
                  "cuda_available": torch.cuda.is_available(),
                  "gpu": torch.cuda.get_device_name() if torch.cuda.is_available() else None,
                  "drive_free_gib": shutil.disk_usage(drive).free / 1024**3,
                  "local_free_gib": shutil.disk_usage(local).free / 1024**3,
                  "storage_estimate": storage_estimate(config),
                  "expected_training_runs": len(config["training"]["variants"]) * len(config["training"]["seeds"])}
        print(json.dumps(report, indent=2))
        if args.calibrate:
            from .training import calibrate
            calibrate(config)
    elif args.stage == "prepare":
        from .data import prepare
        prepare(config, DATASETS if args.dataset == "all" else [args.dataset])
    elif args.stage == "preprocess":
        from .cache import preprocess
        preprocess(config, DATASETS if args.dataset == "all" else [args.dataset])
    elif args.stage in ("train", "evaluate"):
        variants = None if args.variant == "all" else [args.variant]
        seeds = [args.seed] if args.seed is not None else None
        if args.stage == "train":
            from .training import train
            train(config, variants, seeds)
        else:
            from .evaluation import evaluate
            evaluate(config, variants, seeds)
    else:
        from .evaluation import summarize
        summarize(config)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, RuntimeError, OSError) as error:
        print(f"STOP: {error}", file=sys.stderr)
        raise SystemExit(1)
