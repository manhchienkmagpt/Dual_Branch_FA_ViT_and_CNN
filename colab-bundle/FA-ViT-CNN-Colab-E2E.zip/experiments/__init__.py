"""Reproducible, manifest-based experiments; legacy training entrypoints are unchanged."""
import os
import sys

# No unsolicited version-check network traffic in training or offline tests.
os.environ.setdefault("NO_ALBUMENTATIONS_UPDATE", "1")
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
# The legacy repository tracks bytecode; do not rewrite those unrelated files.
sys.dont_write_bytecode = True
