"""Colab-side jobs and verifiable evidence. Uses only the notebook's own Drive."""
from collections import deque
import builtins
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import threading
import traceback

if not hasattr(builtins, "_favit_autopilot_state"):
    builtins._favit_autopilot_state = {"lock": threading.Lock(), "active": None, "stop": threading.Event()}
_STATE = builtins._favit_autopilot_state
_LOCK = _STATE["lock"]
_STOP = _STATE["stop"]
STAGES = {"prepare", "preprocess", "calibrate", "train", "evaluate", "summarize"}


def now():
    return datetime.now(timezone.utc).isoformat()


def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def redact(text):
    for key, value in os.environ.items():
        if any(word in key.upper() for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY")) and len(value) >= 6:
            text = text.replace(value, "[REDACTED]")
    return text


def gpu_proof():
    result = subprocess.run(["nvidia-smi", "--query-gpu=name,uuid", "--format=csv,noheader"],
                            capture_output=True, text=True, timeout=20)
    lines = result.stdout.strip().splitlines()
    if result.returncode or not lines or any("L4" not in line.split(",")[0] for line in lines):
        raise RuntimeError("WAITING_L4: allocated accelerator is not NVIDIA L4: " + result.stdout.strip())
    return lines


def cached_index(config, verify=False):
    root = Path(config["drive_root"])
    active = root / "cache" / "active.json"
    if not active.is_file():
        return None
    path = (root / read(active)["index"]).resolve()
    if not path.is_relative_to((root / "cache").resolve()):
        raise ValueError("Invalid cache index path")
    index = read(path)
    if index.get("smoke") or not all(index.get("datasets", {}).get(d, {}).get("complete") for d in ("ffpp", "celebdf", "uadfv")):
        return None
    for key in ("image_size", "train_frames", "eval_frames", "face_margin", "jpeg_quality", "detector", "shard_videos"):
        if index["settings"][key] != config["data"][key]:
            raise ValueError("Frozen preprocessing protocol mismatch: " + key)
    for dataset in index["datasets"].values():
        for shard in dataset["shards"]:
            # Materialize performs full checksums before train/evaluate.
            archive = (path.parent / shard["path"]).resolve()
            if not archive.is_relative_to(path.parent.resolve()):
                raise ValueError("Invalid cache shard path")
            if not archive.is_file():
                return None
            if verify and digest(archive) != shard["sha256"]:
                raise RuntimeError("Cache checksum mismatch: " + str(archive))
    return {"index": str(path), "sha256": digest(path), "complete": True, "smoke": False}


def evidence(task, config):
    drive = Path(config["drive_root"])
    stage = task["stage"]
    if stage == "prepare":
        import csv
        dataset = task["dataset"]
        manifest = drive / "manifests" / f"videos-{dataset}.csv"
        with manifest.open(encoding="utf-8", newline="") as stream:
            count = sum(1 for _ in csv.DictReader(stream))
        expected = {"ffpp": 6000, "celebdf": 518, "uadfv": 98}[dataset]
        if count != expected:
            raise RuntimeError(f"{dataset}: expected {expected} manifest rows, got {count}")
        return {"manifest": str(manifest), "sha256": digest(manifest), "videos": count}
    if stage == "preprocess":
        result = cached_index(config, verify=True)
        if not result:
            raise RuntimeError("Three complete production caches are required")
        bootstrap = runpy.run_path(str(Path(__file__).with_name("bootstrap.py")))
        bootstrap["freeze_protocol"](config)
        return result
    if stage == "calibrate":
        return {"runtime": read(drive / "runtime.json")}
    if stage in ("train", "evaluate"):
        folder = drive / "runs" / task["variant"] / f"seed-{task['seed']}"
        state = read(folder / "state.json")
        if state.get("status") != "completed" or digest(folder / "best.pt") != state.get("best_sha256"):
            raise RuntimeError("Training evidence is incomplete or best checkpoint is corrupt")
        result = {"state": state, "best_sha256": state["best_sha256"]}
        if stage == "evaluate":
            evaluation = folder / "evaluation"
            coverage = read(evaluation / "coverage.json")
            if coverage.get("zero_crop_video_ids") or coverage.get("datasets_absent") or coverage.get("smoke"):
                raise RuntimeError("Evaluation is smoke or a subset")
            result["coverage"] = coverage
            result["metrics_sha256"] = digest(evaluation / "metrics.csv")
            result["predictions_sha256"] = digest(evaluation / "frame-predictions.csv")
            if result["predictions_sha256"] != read(evaluation / "status.json")["predictions_sha256"]:
                raise RuntimeError("Prediction checksum does not match evaluation status")
        return result
    progress = read(drive / "summaries" / "progress.json")
    expected = len(config["training"]["variants"]) * len(config["training"]["seeds"])
    if (not progress.get("complete") or progress.get("smoke")
            or progress.get("measured_runs") != expected or progress.get("expected_runs") != expected):
        raise RuntimeError("Configured measured experiment suite is not complete")
    return {"progress": progress, "report": str(drive / "summaries" / "REPORT-VI.md")}


def submit(task, config, project, archive):
    """Return immediately; the kernel owns one background worker at a time."""
    task = dict(task)
    if task.get("stage") not in STAGES or not task.get("task_id", "").replace("-", "").replace("_", "").isalnum():
        raise ValueError("Invalid autopilot task")
    if config.get("smoke"):
        raise ValueError("Autopilot production jobs cannot use smoke data")
    if task["stage"] == "prepare" and task.get("dataset") not in ("ffpp", "celebdf", "uadfv"):
        raise ValueError("Invalid dataset")
    if task["stage"] in ("train", "evaluate"):
        if task.get("variant") not in config["training"]["variants"] or task.get("seed") not in config["training"]["seeds"]:
            raise ValueError("Run not in the frozen experiment matrix")
    if digest(archive) != task["bundle_sha256"]:
        raise ValueError("Uploaded bundle SHA256 differs from dispatched task")
    with _LOCK:
        saved = Path(config["drive_root"]) / "automation" / "tasks" / f"{task['task_id']}.json"
        if saved.is_file():
            old = read(saved)
            if old.get("status") == "completed" and old.get("bundle_sha256") == task["bundle_sha256"]:
                return old
        active_worker = _STATE["active"]
        if active_worker and active_worker.is_alive():
            current = read(Path(config["drive_root"]) / "automation" / "latest.json")
            if current["task_id"] == task["task_id"]:
                return current
            raise RuntimeError("Another autopilot task is active")
        latest = Path(config["drive_root"]) / "automation" / "latest.json"
        if latest.is_file() and read(latest).get("status") == "running":
            raise RuntimeError("A previous Colab runtime may still be running; reconnect and verify it before submitting")
        _STOP.clear()
        _STATE["active"] = threading.Thread(target=_work, args=(task, dict(config), Path(project)), daemon=True)
        _STATE["active"].start()
    return {"task_id": task["task_id"], "status": "submitted"}


def status(config):
    path = Path(config["drive_root"]) / "automation" / "latest.json"
    return read(path) if path.exists() else {"status": "idle"}


def stop():
    _STOP.set()


def recover(config, previous_task_id, termination):
    """Only after the operator verifies Colab terminated the previous backend.

    A browser disconnect or stale heartbeat is deliberately insufficient.
    """
    if termination.get("termination_confirmed") is not True or not termination.get("termination_message"):
        raise ValueError("Explicit backend termination evidence is required")
    with _LOCK:
        active = _STATE["active"]
        if active and active.is_alive():
            raise RuntimeError("Cannot recover while a local worker is active")
        root = Path(config["drive_root"]) / "automation"
        path = root / "latest.json"
        if path.exists():
            old = read(path)
            if old["task_id"] != previous_task_id and old.get("status") == "running":
                raise RuntimeError("A different task may still be running")
            if old["task_id"] == previous_task_id and old.get("status") == "running":
                old.update(status="interrupted", termination=termination, finished_at=now())
                atomic(root / "tasks" / f"{previous_task_id}.json", old)
                atomic(path, old)
        return {"status": "recovered", "previous_task_id": previous_task_id}


def _work(task, config, project):
    root = Path(config["drive_root"]) / "automation"
    record = {**task, "status": "running", "started_at": now(), "heartbeat_at": now(), "evidence": {}}
    record_lock = threading.Lock()
    heartbeat_stop = threading.Event()

    def save(**updates):
        with record_lock:
            record.update(updates)
            record["heartbeat_at"] = now()
            atomic(root / "tasks" / f"{task['task_id']}.json", record)
            atomic(root / "latest.json", record)

    def heartbeat():
        while not heartbeat_stop.wait(60):
            save()

    save()
    timer = threading.Thread(target=heartbeat, daemon=True)
    timer.start()
    try:
        gpu = gpu_proof()
        save(gpu=gpu)
        bootstrap = runpy.run_path(str(project / "colab" / "bootstrap.py"))
        stage = task["stage"]
        cache = cached_index(config) if stage in ("prepare", "preprocess") else None
        if not cache:
            environment = "preprocess" if stage in ("prepare", "preprocess") else "training"
            python = bootstrap["bootstrap_env"](project, environment)
            session = Path("/content") / f"autopilot-{task['task_id']}.json"
            session.write_text(json.dumps(config), encoding="utf-8")
            arguments = []
            actual_stage = stage
            if stage == "prepare":
                arguments = ["--dataset", task["dataset"]]
            elif stage == "calibrate":
                actual_stage = "doctor"
                if not (Path(config["drive_root"]) / "runtime.json").exists():
                    arguments = ["--calibrate"]
            elif stage in ("train", "evaluate"):
                arguments = ["--variant", task["variant"], "--seed", str(task["seed"])]
            bootstrap["run_stage"](python, project, session, actual_stage, *arguments,
                                   drive_root=config["drive_root"], stop_event=_STOP,
                                   on_log=lambda path: save(log_path=str(path)))
        proof = {"reused_complete_cache": cache} if stage == "prepare" and cache else evidence(task, config)
        save(status="completed", evidence=proof, finished_at=now())
    except BaseException as error:
        log_path = record.get("log_path")
        tail = ""
        if log_path and Path(log_path).is_file():
            with Path(log_path).open(encoding="utf-8", errors="replace") as stream:
                tail = "".join(deque(stream, maxlen=100))[-24000:]
        checkpoints = list((Path(config["drive_root"]) / "runs").glob("*/seed-*/state.json"))
        public = json.loads(json.dumps(config))
        public["sources"] = {}
        failure = {**record, "status": "stopped" if _STOP.is_set() else "failed",
                   "error": redact(str(error)), "traceback": redact(traceback.format_exc()),
                   "log_tail": redact(tail), "config": public, "has_checkpoints": bool(checkpoints),
                   "checkpoint_states": [{"path": str(p), "state": read(p)} for p in checkpoints], "finished_at": now()}
        atomic(root / "errors" / f"{task['task_id']}.json", failure)
        save(**{k: v for k, v in failure.items() if k not in task})
    finally:
        heartbeat_stop.set()
        timer.join(timeout=2)


def install(namespace):
    """Expose a stable notebook API without retaining stale worker modules."""
    return {
        "submit": lambda task: submit(task, namespace["CONFIG"], namespace["PROJECT"], namespace["PROJECT_ZIP"]),
        "status": lambda: status(namespace["CONFIG"]),
        "stop": stop,
        "recover": lambda task_id, termination: recover(namespace["CONFIG"], task_id, termination),
    }
