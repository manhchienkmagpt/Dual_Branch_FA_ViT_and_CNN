# Ứng viên balanced v2 — chẩn đoán và cải thiện khả năng học

Quan sát thật của `favit_clip/fold-01`: epoch 1 AUC validation 0.5576,
epoch 2 AUC 0.50758; confusion matrix lần lượt dự đoán tất cả thật / tất cả giả.
Hai epoch chưa chứng minh nguyên nhân là kiến trúc; đây là dấu hiệu phải kiểm tra
quy trình tối ưu và mất cân bằng lớp trước khi mở rộng 50 lượt.

Notebook: `FA_ViT_CNN_Upgrade_v2.ipynb`. Bundle riêng:
`FA-ViT-CNN-Upgrade-v2.zip`. Không thay gói notebook cũ trên Drive.

## Quy trình mặc định

1. Dừng cell training cũ, giữ runtime nếu muốn dùng lại ảnh đã giải nén.
2. Mở notebook v2 bằng Colab, chọn L4, chạy từ đầu. Mặc định `MODE=pilot`,
   `VARIANT=favit_clip`, `FOLD=1`. Không có bước download hoặc preprocess.
3. Kiểm tra gradient hữu hạn và trọng số thay đổi trên tối đa 16 video **train**,
   tắt augmentation. 64 bước optimizer ngắn chỉ là chẩn đoán; kết quả trên tập nhỏ
   không phải AUC validation và không chứng minh model đã khái quát tốt.
4. Chạy pilot 3 epoch. Xem loss, AUC, balanced accuracy, confusion matrix và
   mean xác suất theo nhãn. Các chỉ số này đều có trong `history.json`.
5. `MODE=continue` tiếp tục model/fold hiện tại. Chỉ chọn `MODE=full` sau khi
   đánh giá pilot; không tự chọn cấu hình hoặc ngưỡng dựa trên tập test/UADFV.

## Những thay đổi thử nghiệm

- Mỗi microbatch gồm 1 thật + 1 giả, lấy mẫu chỉ từ partition train.
  Tái lấy mẫu lớp ít; mỗi lần lấy có thể chọn clip/augmentation khác.
  Validation và test giữ nguyên video/phân bố gốc. Tên log `sampled_clips`
  phân biệt số lượt lấy mẫu với số video nguồn duy nhất.
- BCE không `pos_weight`, label smoothing = 0 để tránh bù mất cân bằng hai lần.
  Loss mới không so trực tiếp trị số với weighted BCE cũ.
- Fine-tune hai block cuối và norm của ViT pretrained: LR 1e-5;
  adapter LR 1e-4; head/CNN/fusion/temporal LR 3e-4, gradient clip norm 1.
- Thay BatchNorm2d trong các CNN bằng GroupNorm để giảm phụ thuộc thống kê
  batch rất nhỏ; không thay ViT LayerNorm. Đây là **thay đổi kiến trúc** và
  phải công bố khi báo cáo kết quả, không gọi là baseline gốc.
- Epoch 1–2 chỉ flip; sau đó brightness/contrast nhẹ, JPEG quality 80–100
  xác suất 0.2, downscale 0.75–1 xác suất 0.15. Dùng chung tham số cho mọi
  frame trong clip. Không áp dụng augmentation cho validation/test.
- Không thêm dữ liệu UADFV/Celeb-DF vào training. Không thay fold nguồn,
  không cắt lại clip, không thêm hoặc tự bỏ video lỗi.

## Dữ liệu và checkpoint

`cache_root` trỏ đến `FA_ViT_CNN_Experiments` ở chế độ chỉ đọc. Đọc lại manifest,
exclusions và active crop cache, kiểm tra checksum/tương thích preprocessing.
Lệnh prepare/preprocess/exclude-video bị chặn khi `cache_root` được đặt.
Đầu ra mới ở `FA_ViT_CNN_Upgrade_v2`, gồm protocol/runtime, diagnostics,
temporal-runs, history và checkpoint riêng. Không resume trọng số bản cũ
vào thí nghiệm mới vì loss, sampling và kiến trúc đã thay đổi.

Log mới có tiến độ khôi phục từng shard, validation AUC/balanced accuracy,
confusion matrix và xác nhận checkpoint sau khi commit. Không tự dùng
accuracy 83.33% làm tiêu chí thành công trên validation mất cân bằng.

## Giới hạn và đối chứng cần làm

Chưa có benchmark/AUC v2 trên FF++ thật. Các thay đổi được gom thành một
ứng viên chẩn đoán; không thể quy lợi ích riêng cho augmentation, normalization
hay fine-tuning nếu chưa làm ablation. Khi pilot học được, nên đối chứng lần lượt
balanced BCE, fine-tuning, GroupNorm và augmentation với cùng fold/seed,
giữ tập test ngoài quá trình chọn cấu hình. Fine-tuning có thể tăng VRAM/thời gian;
calibration vẫn kiểm tra microbatch 2 trên GPU thực tế và dừng nếu không vừa.

Tham khảo API: [BCEWithLogitsLoss](https://docs.pytorch.org/docs/stable/generated/torch.nn.BCEWithLogitsLoss.html),
[timm pretrained models](https://huggingface.co/docs/timm/en/quickstart).

## Kiểm chứng local

38 kiểm thử temporal/detector hồi quy và 3 kiểm thử v2 đã qua. Các kiểm thử v2
kiểm tra batch cân bằng, không lấy mẫu validation vào train, nguồn cache không bị
thay đổi sau diagnostic/pilot/resume, gradient hữu hạn và trọng số head thay đổi,
log AUC/checkpoint, và backward trên mô hình ViT thật với trọng số khởi tạo ngẫu nhiên.
Hai block cuối có gradient, block đầu giữ cố định, GroupNorm thay BatchNorm đúng.
Notebook đã parse/compile toàn bộ cell. Host local dùng Torch CPU; chưa đo
AUC/VRAM/tốc độ v2 trên L4 và chưa dùng fixture để khẳng định hiệu quả FF++.
