# FA-ViT-CNN thời gian: một notebook, CPU tải dữ liệu và L4 huấn luyện

Mở **[FA_ViT_CNN_10Fold.ipynb](FA_ViT_CNN_10Fold.ipynb)**. Upload gói code
`FA-ViT-CNN-Colab-E2E.zip` lên MyDrive trước. Không cần push repository lên GitHub.
Notebook không khai báo accelerator mặc định; có thể bắt đầu bằng CPU.

## Chạy qua các phiên Colab

1. Runtime CPU, `RUN_STAGE=download`: mount Drive, cài môi trường acquisition nhẹ,
   xác nhận điều khoản FF++, tải FF++ c23 và UADFV, kiểm tra video, tạo mapping fold.
   Bước này không cài/import Torch, MTCNN hay yêu cầu CUDA.
2. Chọn runtime L4, mở lại notebook, `RUN_STAGE=preprocess`: mount Drive và nạp
   lại code/config. MTCNN dùng GPU khi `PREPROCESS_DEVICE=auto`; có thể chọn `cpu`
   để chạy mà không bật GPU. Môi trường MTCNN được cài riêng khi cần.
3. `RUN_STAGE=train`: dùng môi trường training riêng, calibrate và chạy/resume.
   GPU là bắt buộc ở bước production này. `FOLD=0`, `VARIANT=all` chạy cả 50 lượt;
   chọn một fold/variant để chia công việc qua nhiều phiên.
4. Sau khi upload ZIP Celeb-DF, chọn `RUN_STAGE=celebdf`. Các cell cuối nhận ZIP,
   lưu vào Drive, giải nén, xử lý MTCNN và đánh giá checkpoint đã train.

Sau mỗi lần đổi runtime, chạy notebook từ đầu với giai đoạn tương ứng. Các cell
khác được bỏ qua; dữ liệu/checkpoint được khôi phục từ Drive. Notebook không tự
đổi runtime hoặc tự bật GPU. Không dùng hai runtime ghi cùng Drive root đồng thời.

## Dữ liệu bền vững

Mặc định dùng `/content/drive/MyDrive/FA_ViT_CNN_Temporal_10Fold`:

```text
raw/ffpp/                 video FF++ gốc
raw/uadfv/                video UADFV
raw/celebdf/              video từ ZIP upload muộn
downloads/                archive/downloader đã lưu
temporal-manifests/       manifest, checksum và folds.json
temporal-cache/<dataset>/ crop shards, metadata, active.json
temporal-runs/<variant>/fold-XX/ checkpoint, history và predictions
temporal-summaries/        JSON, CSV và REPORT-VI.md
pretrained-cache/         trọng số pretrained
logs/                     log từng giai đoạn
```

FF++ tải trực tiếp vào vùng raw trên Drive. Khi resume, video tải dở không được
coi là hoàn tất chỉ vì file tồn tại: kiểm tra decode đầu/cuối và số frame trước
khi đóng băng manifest. File hỏng được giữ với hậu tố `.incomplete-*` để tải lại.
Nếu còn thiếu video, pipeline tải tiếp trước thay vì giải mã lại toàn bộ video
đã có. Khi đủ video, mỗi file mới/thay đổi được copy về `/content`, tính SHA-256
trong cùng lượt đọc rồi kiểm tra đầu/cuối trên bản local. Tiến độ hiện tên file
đang kiểm tra; kết quả được lưu dần trong `temporal-manifests/verification-*.json`.
Resume tái sử dụng kết quả với file không đổi dung lượng/mtime; preprocessing
vẫn kiểm tra SHA-256 đối với manifest đã đóng băng. Nếu ngắt giữa kiểm tra, tối
đa nhóm 25 kết quả chưa lưu phải làm lại. Lần kiểm tra đầu vẫn phụ thuộc tốc độ
Drive nhưng không còn chạy im lặng: có dòng khởi động và heartbeat sau 30 giây
chưa có đầu ra mới. Heartbeat chỉ xác nhận worker còn sống, không chứng minh
I/O đang tiến triển.
KaggleHub của UADFV cũng dùng cache trên Drive; video được chuẩn hóa vào raw.
Crop lưu thành TAR với checksum; mỗi shard 64 video. Nếu ngắt giữa shard, làm lại
shard đó từ video đã lưu, không cần tải lại nguồn. Không tự xóa video gốc.

Drive cần đủ chỗ cho video, frame, pretrained và checkpoint. Có từ 100 GB trống
là cấu hình đã chọn, không phải bảo đảm về dung lượng. Xem ước lượng sau shard
đầu và quota thực tế của tài khoản; dung lượng filesystem báo có thể khác quota.
Training materialize crop vào `/content` để tránh đọc nhiều ảnh trực tiếp từ Drive.

## Fold và clip

### Loại trừ video không tạo được clip

Không tự bỏ qua mọi video lỗi. Sau khi kiểm tra `coverage.json`, có thể ghi nhận
đúng video được tác giả quyết định loại bằng ô `EXCLUDE_FFPP_VIDEO` trong cell
preprocess (ví dụ `ffpp/Deepfakes/638_640`), kèm `EXCLUSION_REASON`.
Hoặc gọi `run(ACQ_PYTHON, 'exclude-video', '--dataset', 'ffpp', '--video-id',
'ffpp/Deepfakes/638_640', '--reason', 'Author approved: no valid consecutive clip')`.
Sau đó chạy preprocess bình thường: kiểm tra/tái sử dụng shard FF++ đã lưu,
hoàn tất coverage sau loại trừ, rồi tiếp tục UADFV. Giữ nguyên Drive root.

Quyết định được lưu trong `temporal-manifests/exclusions-ffpp.json`, gắn với
checksum manifest nguồn. Không xóa video gốc, không thay manifest hay chia lại fold.
Cache ghi rõ số video nguồn, số video dùng và danh sách loại; training, evaluation
và kiểm tra out-of-fold cùng bỏ đúng các video đó. Báo cáo JSON/Markdown công bố
video bị loại và lý do. Với bộ hiện tại, FF++ còn 5.999/6.000 video.
Mã mới nhận diện chính xác bản crop cũ tương thích để dùng lại các TAR, gồm cả
shard chứa video đã loại. Những video lỗi khác vẫn khiến pipeline dừng.

500 cặp nguồn FF++ lấy từ ba danh sách chính thức được gộp, xáo trộn seed 42 rồi
chia p1–p10. Hai video nguồn và các bản giả của cặp luôn ở cùng một phần.
Đây là giao thức cross-validation mới, không phải split benchmark chính thức.
Quan hệ cặp nguồn không xác nhận danh tính người độc lập giữa các phần.

| Lượt | Train | Val | Test |
|---|---|---|---|
| 1 | p1–p8 | p9 | p10 |
| 2 | p2–p9 | p10 | p1 |
| 10 | p10,p1–p7 | p8 | p9 |

Mỗi video tạo tối đa 8 clip có vị trí bắt đầu phân bố đều; mỗi clip gồm 8 frame
liên tiếp, stride 1. MTCNN theo cùng mặt trong clip và căn chỉnh 5 landmarks về
mẫu cố định 224×224, giữ margin 20%. Video ngắn, mặt mất tracking hoặc landmarks
lỗi được ghi coverage. Không lặp frame để bù. Nếu video không có clip hợp lệ,
pipeline dừng để xử lý, không âm thầm bỏ video test.

Train lấy một clip/video/epoch; val/test lấy tối đa bốn clip phân bố đều trong
các clip hợp lệ. Cả năm mô hình dùng cùng dữ liệu và tham số augmentation trong
toàn clip. Crop được tạo một lần, không nhân bản theo fold. Không trộn cache ảnh
tĩnh cũ (20/50 frame lấy thưa) với cache chuỗi frame mới.

## Mô hình và cách huấn luyện

| Variant | Nội dung |
|---|---|
| `favit_clip` | FA-ViT hiện có, LN–Dropout–Linear, trung bình logits frame |
| `favit_cnn_clip` | CNN 2D độc lập hiện tại và concatenation |
| `favit_cnn_temporal` | CNN thời gian + chênh lệch đặc trưng + fusion theo patch |
| `favit_cnn_no_temporal` | Fusion patch, bỏ xử lý thời gian |
| `favit_cnn_no_patch` | CNN thời gian, spatial pooling thay fusion patch |

Encoder là FA-ViT giản lược hiện có của dự án, không tái hiện đầy đủ bài gốc.
ViT đóng băng, GAM/LAM, CNN và classifier được train. CNN tạo map 128 kênh;
temporal depthwise convolution kernel 3 nhận map gốc và chênh lệch giữa frame;
cross-attention 4 head, chiều 128 kết hợp với patch tokens FA-ViT. Descriptor
128 chiều ghép CLS 768 chiều, qua LN–Dropout(0.3)–Linear. Trung bình logits
frame tạo một logit clip; trung bình xác suất clip tạo điểm video.

Mỗi fold khởi tạo mới cùng seed 42, không chuyển checkpoint trained giữa fold.
AdamW, LR/weight decay 1e-4, label smoothing 0.05, BCE với pos_weight từ video
train của fold. Tối đa 30 epoch, early stopping patience 5. Best, scheduler và
stopping đều dựa trên **video AUC của val FF++**; scheduler patience 2, factor 0.5.
Điểm bằng nhau giữ checkpoint sớm hơn. Phân loại dùng ngưỡng 0.5 cố định.

Calibrate thử toàn bộ cấu hình với clip đầy đủ, gồm backward và optimizer step.
Chốt microbatch chung 2 hoặc 1 clip, BF16 trên L4; accumulation đạt effective
batch 8 clip. OOM sau khi chốt không tự đổi giao thức. Thay clip length, seed,
architecture, thư viện khoa học hoặc cấu hình training cần experiment root mới.

Checkpoint lưu sau mỗi epoch gồm optimizer/scheduler/scaler/RNG. Resume làm lại
phần epoch đang dở, tiếp tục từ epoch hoàn tất. Best được xác minh checksum.
Run hoàn tất bỏ qua training, nhưng vẫn có thể tạo lại prediction exports.
50 lượt có thể cần nhiều phiên GPU; đo epoch thực tế trước khi ước lượng thời gian.

## Celeb-DF cuối notebook

Không có URL/lệnh tự tải Celeb-DF trong workflow mới. Upload ZIP lớn lên Drive
và nhập `CELEBDF_ZIP`; hoặc bật `UPLOAD_CELEBDF` để upload qua giao diện. File
upload được sao lưu vào Drive trước khi giải nén. ZIP cần đúng video và
`List_of_testing_videos.txt`; hỗ trợ một thư mục bọc ngoài. Label test list
`1=real`, `0=fake` được đổi sang nhãn mô hình `0=real`, `1=fake`.

Nhận/giải nén chạy trên CPU, MTCNN dùng CPU/GPU. Bật `EVALUATE_CELEBDF` khi
có GPU và checkpoint để inference; có thể tắt để chỉ chuẩn bị dữ liệu bằng CPU.
Chưa upload thì thông báo chờ, không chặn FF++/UADFV. Cache từng dataset độc lập;
thêm Celeb-DF không thay đổi fingerprint training FF++ hoặc chọn lại checkpoint.

## Kết quả và giới hạn

Mỗi fold lưu dự đoán clip/video, metrics, confusion matrix, history và provenance.
FF++ có out-of-fold predictions: mỗi video chỉ xuất hiện ở test một lần. Báo cáo
mean ± SD qua fold và AUC pooled out-of-fold; không coi SD này là biến thiên qua
training seed. UADFV/Celeb-DF được đánh giá bằng checkpoint từng fold, không
chọn fold tốt nhất theo dữ liệu ngoài và không coi các lần đánh giá cùng video
là dữ liệu mới. Báo cáo chưa đủ fold được đánh dấu số fold thực tế.

## CLI và kiểm tra

```bash
python -m experiments.temporal doctor --config colab/experiment_config.temporal.yaml
python -m experiments.temporal prepare --config colab/experiment_config.temporal.yaml
python -m experiments.temporal preprocess --config colab/experiment_config.temporal.yaml --device auto
python -m experiments.temporal doctor --config colab/experiment_config.temporal.yaml --calibrate
python -m experiments.temporal run --config colab/experiment_config.temporal.yaml --fold 1
python -m experiments.temporal evaluate --config colab/experiment_config.temporal.yaml --dataset celebdf
python -m experiments.temporal summarize --config colab/experiment_config.temporal.yaml
python -m experiments.temporal smoke --output experiment-output/temporal-smoke
```

Smoke dùng video, detector và encoder tổng hợp riêng, kiểm tra cả 50 lượt và
upload Celeb-DF muộn. Các số đó tuyệt đối không phải kết quả khoa học. Kiểm thử
local không thay thế bước xác nhận môi trường L4, MTCNN thật và nguồn dữ liệu
được cấp quyền trên Colab.
