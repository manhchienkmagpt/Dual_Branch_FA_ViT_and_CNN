# Chạy ảnh crop trên Windows, RTX 5060 Ti 16 GB

Chế độ PC đọc trực tiếp ảnh đang có trên E:/F:. Không cần Colab, Google Drive, video gốc, MTCNN hay đóng TAR. Dữ liệu nguồn được giữ nguyên; toàn bộ ảnh hợp lệ được sử dụng. Transform của model vẫn resize ảnh về 224×224 như cấu hình thí nghiệm.

## Cài môi trường

Dùng Python 3.11 x64. Từ thư mục repo, chạy PowerShell:

```powershell
.\colab\setup_pc.ps1
```

Script tạo `.venv-pc`, cài `torch==2.7.1`/`torchvision==0.22.1` từ CUDA 12.8 index, cài dependencies training và thử convolution/matrix multiplication forward/backward thật trên CUDA. Chọn bản này vì [PyTorch 2.7 bổ sung Blackwell/CUDA 12.8](https://pytorch.org/blog/pytorch-2-7/); [cặp wheel chính thức cho Windows](https://pytorch.org/get-started/previous-versions/#v2-7-1) được pin để có thể tái tạo môi trường. Driver NVIDIA trên PC cần tương thích với wheel và vượt qua phép thử CUDA. Đây không phải benchmark tốc độ/VRAM.

Cũng có thể chạy thủ công các lệnh tương ứng, không cần activate môi trường:

```powershell
py -3.11 -m venv .venv-pc
.\.venv-pc\Scripts\python.exe -m pip install --upgrade pip
.\.venv-pc\Scripts\python.exe -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
.\.venv-pc\Scripts\python.exe -m pip install -r colab/requirements-training.txt
.\.venv-pc\Scripts\python.exe -m pip check
```

Không dùng Colab bootstrap CUDA 12.1 cho máy này. Ảnh đã crop nên không cài `facenet-pytorch` vào môi trường training; dependency cũ của nó có thể thay phiên bản Torch.

## Đường dẫn đã cấu hình

File `colab/experiment_config.pc.yaml` chứa bốn nguồn:

```text
FF++ train: E:/Deepfake_Data_Chien/ffpp_faces_mtcnn
FF++ test:  E:/Deepfake_Data_Chien/ffpp_celebdf_data/processed/faces/ffpp/c23/test
Celeb-DF:   E:/Deepfake_Data_Chien/ffpp_celebdf_data/processed/faces/celebdf/test
UADFV:      F:/DeepFakedata/UADFV
```

Cấu trúc được đọc:

```text
FF++ train root/
  train/                         # tự dùng nhánh này nếu có; nếu không đọc nhãn ngay ở root
    original/                    # ảnh nằm phẳng hoặc có thư mục con đều được
    Deepfakes/
    Face2Face/
    FaceSwap/
    NeuralTextures/
    FaceShifter/

FF++ test root/
  real/<video>/ảnh...
  fake/Deepfakes/<video>/ảnh...
  fake/Face2Face/<video>/ảnh...
  fake/FaceSwap/<video>/ảnh...
  fake/NeuralTextures/<video>/ảnh...
  fake/FaceShifter/<video>/ảnh...

Celeb-DF test root/
  0/<video>/ảnh...                # 0 = real theo cấu trúc ảnh của tác giả
  1/<video>/ảnh...                # 1 = fake

UADFV root/
  real/<video>/ảnh...
  fake/<video>/ảnh...
```

FF++ train cũng nhận `real/fake` hoặc `0/1` khi nhãn đã gộp. Tên phương pháp FF++ không phân biệt hoa/thường, dấu `_`, `-` hoặc khoảng trắng. Tập inference yêu cầu thư mục video; các frame train không cần video ID. UADFV chỉ đánh dấu grouping đã ghép khi các folder ID real/fake trùng hoàn toàn một-một. Số frame trong audit là số ảnh thực có, không ép về 20/50 frame.

Theo yêu cầu tác giả, cấu hình PC mặc định **bỏ đọc/hash/verify toàn bộ ảnh và bỏ chặn ảnh trùng train/test**. Phần lập danh sách đường dẫn, nhãn và video vẫn cần thiết; terminal báo mỗi 10.000 ảnh. Ảnh hỏng sẽ được báo khi DataLoader đọc đến, không bị âm thầm loại khỏi kết quả.

```yaml
pc_input_checks:
  verify_image_contents: false
  reject_identical_train_test: false
  known_ffpp_overlap_reported: true
```

`known_ffpp_overlap_reported: true` ghi lại lỗi trùng ảnh tác giả đã cung cấp trước đó. JSON gắn cờ này vào kết quả FF++, không mô tả tập này như untouched test. Ở chế độ nhanh, fingerprint dựa vào đường dẫn/kích thước/mtime, không xác minh nội dung; `ffpp_identical_train_test_images` là `null` (chưa đếm), không ghi 0. Không suy ra source/identity separation từ tên folder.

Để kiểm tra đầy đủ, đặt `verify_image_contents: true`. Đặt thêm `reject_identical_train_test: true` nếu muốn dừng khi phát hiện trùng; để false thì chỉ ghi nhận số ảnh trùng. Giữ nguyên chế độ khi resume các run đã có checkpoint; thay đổi fingerprint/code yêu cầu output riêng nếu chữ ký không còn khớp.

## Kiểm tra dữ liệu trước

```powershell
.\.venv-pc\Scripts\python.exe colab/run_supplemental_suite.py --config colab/experiment_config.pc.yaml --inspect
```

Lệnh này xuất `data-audit.json` cùng `input-manifest.json`, không train và không chạy CUDA. Nó tuân theo `pc_input_checks`: mặc định chỉ lập danh sách/kiểm tra cấu trúc, không mở/hash ảnh và không chặn trùng nội dung. Nếu không cần chạy riêng, có thể bỏ lệnh `--inspect` và chạy training trực tiếp. Bước lập danh sách tối thiểu vẫn diễn ra để DataLoader biết ảnh, nhãn và video nào cần dùng.

## Train và inference

```powershell
.\.venv-pc\Scripts\python.exe colab/run_supplemental_suite.py --config colab/experiment_config.pc.yaml --phase all --max-hours 0
```

Giữ thứ tự matched-head → CNN-only → capacity → dual seed 42 nếu chưa có lượt PC tương thích → hai cặp matched/dual seed 123/2026. `--phase ablations` chỉ chạy bốn lượt đầu; `--phase multiseed` chạy bốn lượt sau. `--max-hours` là giới hạn mềm ở ranh giới epoch; inference/export đang chạy có thể vượt mốc. Chạy lại cùng lệnh để resume. Không chạy đồng thời nhiều notebook/runner trên cùng thư mục kết quả.

Workflow **đã chọn theo yêu cầu tác giả**:

1. Gradient chỉ tính trên ảnh FF++ train.
2. Sau mỗi epoch, evaluate toàn bộ Celeb-DF ở frame-level, không backpropagate trên Celeb-DF.
3. Best checkpoint, scheduler và early stopping dùng **Celeb-DF frame AUC**, không dùng accuracy hoặc video AUC. Patience và các hyperparameter giữ theo YAML.
4. Khi run hoàn tất, best checkpoint được inference trên FF++ test, Celeb-DF và UADFV; xuất frame metrics, video-mean/video-median metrics và từng manipulation FF++.

**Celeb-DF đã tham gia model selection và sau đó được dùng lại để báo cáo.** Đây không phải ước lượng trên untouched test set của Celeb-DF. Mọi JSON có protocol này; các dòng metric/thống kê Celeb-DF có `evaluation_role: model_selection_reuse`. CI/p-value vẫn là exploratory và không khắc phục selection bias. UADFV không được dùng để cập nhật model/chọn checkpoint. Nếu paper cũ ghi chưa dùng Celeb-DF để chọn checkpoint, cần sửa mô tả sau khi xác nhận lịch sử chạy thực tế.

## Kết quả, VRAM và resume

Mặc định kết quả nằm ở `experiment-output/pc-results/`, scratch ở `experiment-output/pc-work/`. Có thể đổi hai đường dẫn này trong YAML nhưng phải giữ chúng riêng với các folder ảnh. Bắt đầu ở thư mục output riêng: protocol PC khác protocol Colab, nên không tự nhập checkpoint lịch sử hoặc trộn hai loại run.

`runtime.json` ghi microbatch/precision được đo thực tế. Probe bắt đầu từ 16 rồi thử 8/4/2/1 khi OOM, effective batch vẫn 16. Khi đã có checkpoint, giữ config, dữ liệu và runtime đã chốt; đổi chúng sẽ bị chặn bằng signature. Checkpoint lưu cả optimizer/scheduler/scaler/RNG sau mỗi epoch. Nếu ngắt trước khi epoch đầu hoàn tất thì có thể chạy lại epoch đầu; nếu checkpoint của một epoch đã lưu bị mất thì báo lỗi. `last.pt` được giữ để resume/kiểm chứng.

Lần train đầu có thể cần tải trọng số pretrained nếu chưa có cache. Mỗi epoch có thời gian thực đo trong history; `supplemental/timing.json` ghi thời gian epoch/inference. Các file này giúp dự trù lại thời gian trên đúng PC thay vì dùng ước lượng của L4/T4.

File để gửi lại đọc kết quả:

```text
experiment-output/pc-results/supplemental/paper-results.json
```

Ngoài ra có JSON từng run, history, audit, ensemble và so sánh; trong `runs/` có best/last checkpoint và frame prediction CSV. Giữ cả các artifact gốc này. Chỉ xuất lại JSON trên CPU, không train:

```powershell
.\.venv-pc\Scripts\python.exe colab/run_supplemental_suite.py --config colab/experiment_config.pc.yaml --export-only
```

Môi trường Windows/5060 Ti thật và các thư mục E:/F: cần được xác nhận bằng setup/inspect trên PC của tác giả; kiểm thử local của dự án dùng CPU và ảnh giả. Các thông số cũ trong paper vẫn cần được đối chiếu với config/log gốc trước khi gộp kết quả mới.
