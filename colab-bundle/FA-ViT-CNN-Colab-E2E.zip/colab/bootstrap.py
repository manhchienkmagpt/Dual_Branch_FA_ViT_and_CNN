"""Small Colab bootstrap: isolated Python runtimes, never replace Colab's Torch."""
from pathlib import Path
from collections import deque
from datetime import datetime, timezone
from html import escape
import hashlib
import json
import os
import queue
import re
import signal
import shutil
import subprocess
import sys
import threading
import time


class StageOutput:
    """Keep child-process tqdm updates in one notebook display per download."""

    progress_pattern = re.compile(r"^(?P<label>.*?)\s*(?P<percent>\d{1,3})%\|[^|]*\|\s*(?P<stats>.*)$")

    def __init__(self):
        self.handle = None
        self.inline_width = 0
        self.label = ""
        self.display = self.html = None
        try:
            from IPython import get_ipython
            from IPython.display import HTML, display
            if getattr(get_ipython(), "kernel", None) is not None:
                self.display, self.html = display, HTML
        except ImportError:
            pass

    def write(self, line):
        match = self.progress_pattern.match(line.rstrip("\r\n"))
        if match:
            if self.display is not None:
                label = match["label"].strip() or self.label or "Download"
                percent = min(100, int(match["percent"]))
                content = self.html(
                    f'<div style="margin:6px 0"><div>{escape(label)}</div>'
                    f'<progress value="{percent}" max="100" style="width:100%;max-width:640px"></progress>'
                    f'<div style="font-family:monospace">{percent}% · {escape(match["stats"])}</div></div>')
                if self.handle is None:
                    self.handle = self.display(content, display_id=True)
                else:
                    self.handle.update(content)
            else:
                text = line.rstrip("\r\n")
                print("\r" + text.ljust(self.inline_width), end="", flush=True)
                self.inline_width = len(text)
            return
        self.finish()
        if line.startswith("Official FF++ download/resume:"):
            self.label = line.strip().split(":", 1)[1].strip()
        print(line, end="", flush=True)

    def finish(self):
        if self.inline_width:
            print(flush=True)
        self.handle = None
        self.inline_width = 0


def bootstrap_command(command, log_path):
    result = subprocess.run(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    output = result.stdout or ""
    for key, value in os.environ.items():
        if len(value) >= 6 and any(word in key.upper() for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY")):
            output = output.replace(value, "[REDACTED]")
    with Path(log_path).open("a", encoding="utf-8") as log:
        log.write(output)
    print(output, end="", flush=True)
    if result.returncode:
        raise RuntimeError(f"Environment setup failed (exit {result.returncode}). Log: {log_path}\n"
                           + "\n".join(output.splitlines()[-60:]))


def bootstrap_env(project, stage, device="auto"):
    if stage not in ("acquisition", "preprocess", "training"):
        raise ValueError("Unknown environment stage")
    if device not in ("auto", "cpu", "cuda"):
        raise ValueError("device must be auto, cpu or cuda")
    if stage == "training" and device == "cpu":
        raise ValueError("Production training requires a GPU")
    # nvidia-smi does not import or install Torch in the Colab kernel.
    gpu_probe = None
    if stage != "acquisition" and device != "cpu" and shutil.which("nvidia-smi"):
        gpu_probe = subprocess.run(["nvidia-smi", "-L"], stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, text=True)
    has_gpu = bool(gpu_probe and gpu_probe.returncode == 0 and "GPU" in gpu_probe.stdout)
    backend = "cpu" if stage == "acquisition" or device == "cpu" else "cuda" if has_gpu else "cpu"
    if stage == "training" or (stage != "acquisition" and device == "cuda"):
        if not has_gpu:
            raise RuntimeError("Enable a Colab GPU for this stage; downloads can run on CPU")
        backend = "cuda"
    project = Path(project).resolve()
    requirement = project / "colab" / f"requirements-{stage}.txt"
    versions = ("2.2.2", "0.17.2") if stage == "preprocess" else ("2.5.1", "0.20.1")
    identity = hashlib.sha256(requirement.read_bytes() + repr((versions, backend)).encode()).hexdigest()
    environment = Path("/content") / f"favit-env-{stage}-{backend}"
    python = environment / "bin" / "python"
    marker = environment / "favit-bootstrap.json"
    if python.exists() and marker.exists() and json.loads(marker.read_text()).get("identity") == identity:
        return str(python)
    logs = project / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    log_path = logs / f"bootstrap-{stage}.log"
    bootstrap_command([sys.executable, "-m", "pip", "install", "--quiet", "uv>=0.8,<1"], log_path)
    if not python.exists():
        # This exact task-owned path may contain an interrupted initial install.
        bootstrap_command([sys.executable, "-m", "uv", "venv", "--python", "3.11", "--seed", "--clear", str(environment)], log_path)
    if stage != "acquisition":
        # MTCNN and training retain separate, compatible Torch environments.
        wheel_index = "https://download.pytorch.org/whl/cu121" if backend == "cuda" else "https://download.pytorch.org/whl/cpu"
        bootstrap_command([sys.executable, "-m", "uv", "pip", "install", "--python", str(python),
                        f"torch=={versions[0]}", f"torchvision=={versions[1]}",
                        "--index-url", wheel_index], log_path)
    bootstrap_command([sys.executable, "-m", "uv", "pip", "install", "--python", str(python),
                    "-r", str(requirement)], log_path)
    bootstrap_command([str(python), "-m", "pip", "check"], log_path)
    if stage != "acquisition":
        check = "import torch, torchvision; print('Torch:',torch.__version__,'CUDA:',torch.cuda.is_available())"
        if backend == "cuda":
            check += "; assert torch.cuda.is_available(), 'Select a GPU runtime in Colab'"
        bootstrap_command([str(python), "-c", check], log_path)
    else:
        bootstrap_command([str(python), "-c", "import importlib.util; assert importlib.util.find_spec('torch') is None; import cv2,yaml"], log_path)
    marker.write_text(json.dumps({"identity": identity}), encoding="utf-8")
    return str(python)


def template_config(python, project):
    command = [python, "-c", "import yaml,json,sys; print(json.dumps(yaml.safe_load(open(sys.argv[1]))))",
               str(Path(project) / "colab" / "experiment_config.yaml")]
    return json.loads(subprocess.check_output(command, text=True))


def freeze_protocol(config):
    """Allow changing the run selection before training, keeping all science fixed."""
    path = Path(config["drive_root"]) / "protocol.json"
    public = json.loads(json.dumps(config))
    public["sources"] = {}
    if path.exists():
        old = json.loads(path.read_text(encoding="utf-8"))
        comparable = lambda item: {key: item[key] for key in ("data", "training", "evaluation")}
        before, after = comparable(old), comparable(public)
        selection_changed = any(before["training"].get(key) != after["training"].get(key)
                                for key in ("variants", "seeds"))
        # Work on copies: never remove the selection from the saved protocol.
        before, after = json.loads(json.dumps(before)), json.loads(json.dumps(after))
        for item in (before, after):
            for key in ("variants", "seeds"):
                item["training"].pop(key, None)
        if before != after:
            raise RuntimeError("Existing scientific protocol differs; preserve it or use a new Drive root")
        if selection_changed and any((path.parent / "runs").glob("*/seed-*/state.json")):
            raise RuntimeError("Run selection changed after training started; use a new Drive root")
        if not selection_changed:
            return
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(public, indent=2), encoding="utf-8")
    temporary.replace(path)


def run_stage(python, project, config_file, stage, *arguments, drive_root=None, stop_event=None, on_log=None, module="experiments"):
    environment = os.environ.copy()
    environment["NO_ALBUMENTATIONS_UPDATE"] = "1"
    if drive_root:
        environment["HF_HOME"] = str(Path(drive_root) / "pretrained-cache" / "huggingface")
        environment["TORCH_HOME"] = str(Path(drive_root) / "pretrained-cache" / "torch")
    # Colab may discard inherited child stdout/stderr. Forward through Python so
    # both the notebook and a persistent log retain the actual download error.
    environment["PYTHONUNBUFFERED"] = "1"
    logs = Path(drive_root or project) / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    log_path = logs / f"{stage}-{stamp}.log"
    if module not in ("experiments", "experiments.temporal"):
        raise ValueError("Unsupported experiment module")
    command = [python, "-u", "-m", module, stage, "--config", str(config_file), *map(str, arguments)]
    tail = deque(maxlen=30)
    output = StageOutput()
    print(f"Log: {log_path}", flush=True)
    if on_log:
        on_log(log_path)
    secrets = [v for k, v in environment.items() if len(v) >= 6 and
               any(word in k.upper() for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY"))]

    def redact(line):
        for secret in secrets:
            line = line.replace(secret, "[REDACTED]")
        return line

    def terminate(process):
        if process.poll() is not None:
            return
        if os.name == "posix":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
            process.wait()
    with log_path.open("w", encoding="utf-8") as log:
        if module == "experiments.temporal":
            initial = f"Starting {module} stage={stage}; Drive log opened successfully.\n"
            print(initial, end="", flush=True)
            log.write(initial); log.flush()
        with subprocess.Popen(command, cwd=project, env=environment, stdout=subprocess.PIPE,
                              stdin=subprocess.DEVNULL, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1,
                              start_new_session=os.name == "posix") as process:
            lines = queue.Queue()

            def reader():
                try:
                    for line in process.stdout:
                        lines.put(line)
                finally:
                    lines.put(None)

            thread = threading.Thread(target=reader, daemon=True)
            thread.start()
            last_output = time.monotonic()
            try:
                while True:
                    if stop_event and stop_event.is_set():
                        raise InterruptedError("Autopilot stop requested; last completed epoch is preserved")
                    try:
                        line = lines.get(timeout=1)
                    except queue.Empty:
                        if module == "experiments.temporal" and time.monotonic()-last_output >= 30:
                            heartbeat = f"[{stage}] worker pid={process.pid} still running; waiting at the last reported operation (30s without output).\n"
                            print(heartbeat, end="", flush=True)
                            log.write(heartbeat); log.flush()
                            last_output = time.monotonic()
                        continue
                    if line is None:
                        break
                    line = redact(line)
                    last_output = time.monotonic()
                    output.write(line)
                    log.write(line)
                    log.flush()
                    tail.append(line)
                returncode = process.wait()
            except BaseException:
                terminate(process)
                raise
            finally:
                output.finish()
                thread.join(timeout=2)
    if returncode:
        raise RuntimeError(f"Stage {stage} failed (exit {returncode}). Log: {log_path}\n"
                           + "".join(tail))
