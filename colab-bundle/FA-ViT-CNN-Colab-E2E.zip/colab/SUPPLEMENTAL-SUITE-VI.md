# Chạy các thí nghiệm bổ sung và xuất bằng chứng JSON

Script: `colab/run_supplemental_suite.py`. Script dùng cache và lịch train hiện có, chạy tuần tự theo ưu tiên, lưu kết quả vào `DRIVE_ROOT/supplemental/`. Không sửa số liệu trong paper hoặc dự đoán quyết định Accept.

Nếu dùng ảnh crop trực tiếp trên Windows, xem [hướng dẫn PC](PC-WINDOWS-VI.md) và dùng `experiment_config.pc.yaml`. Chế độ PC có đường dẫn, input format và protocol chọn checkpoint riêng (Celeb-DF frame AUC), không cần cache TAR và không dùng lại protocol Colab một cách ngầm định.

## Thứ tự

| Ưu tiên | Mô hình | Seed | Vai trò |
|---|---|---|---|
| 1 | `favit_matched` | 42 | Kiểm soát LN–Dropout head |
| 2 | `cnn_only` | 42 | CNN độc lập; ensemble 50:50 với matched-head |
| 3 | `favit_capacity` | 42 | Kiểm soát số tham số bằng residual MLP |
| 4 | `favit_cnn` | 42 | Dual cùng protocol để đối chiếu ba ablation |
| 5–6 | `favit_matched`, `favit_cnn` | 123 | Cặp lặp lại thứ hai |
| 7–8 | `favit_matched`, `favit_cnn` | 2026 | Cặp lặp lại thứ ba |

Tối đa tám lượt. Script tái sử dụng lượt đã hoàn tất nếu checkpoint và chữ ký config/data/code khớp. Vì FA-ViT-CNN seed 42 đã có trong paper, lượt 4 chỉ cần train khi chưa có artifact **tương thích với native runner** trong thư mục `runs/favit_cnn/seed-42/`. Script không coi số in trong paper hoặc một file `.pth` không có provenance là bằng chứng tái sử dụng. Không train lại FA-ViT linear. CNN/capacity chỉ có một seed; phần độ ổn định qua ba seed chỉ áp dụng cho cặp dual/matched-head.

## Điều kiện

1. Hoàn tất notebook 01: cache của FF++, Celeb-DF và UADFV đều `complete: true`. Nếu Celeb-DF còn lỗi quota, script ghi trạng thái blocked; không thay dataset hoặc âm thầm bỏ tập test.
2. Dùng môi trường **training** của notebook 02, không dùng môi trường MTCNN. Có đủ GPU và dung lượng theo cấu hình.
3. Giữ nguyên config tạo các lượt hiện tại: 20/50 frame, split, preprocessing, optimizer và tối đa 30 epoch/patience 5. Script gọi từng variant/seed một cách tường minh; **không cần sửa danh sách variants/seeds trong config hai lượt hiện tại**, tránh làm sai chữ ký resume.
4. Không chạy đồng thời cell train thông thường, autopilot hoặc runner khác trên cùng thư mục kết quả. Khóa của script chỉ ngăn hai bản script chạy trong cùng runtime, không điều phối notebook khác hoặc một runtime Colab khác.

## Lệnh

Từ repository root, xem hàng đợi mà chưa chạy GPU:

```bash
python colab/run_supplemental_suite.py --config colab/experiment_config.yaml --plan
```

Trên Colab, nạp ZIP mới và chạy cell môi trường/config của notebook 02 trước. Sau đó thêm một cell:

```python
!{PYTHON} -u "{PROJECT}/colab/run_supplemental_suite.py" --config "{CONFIG_FILE}" --phase all --max-hours 24
```

Chỉ ưu tiên ablation trước:

```python
!{PYTHON} -u "{PROJECT}/colab/run_supplemental_suite.py" --config "{CONFIG_FILE}" --phase ablations --max-hours 24
```

Chạy lại cùng lệnh để tiếp tục. `--phase multiseed` chỉ lên lịch bốn lượt seed 123/2026; các kết quả đã có vẫn được đọc khi xuất thống kê. `--max-hours 0` bỏ giới hạn thời gian. Ngân sách là **giới hạn mềm**: kiểm tra ở ranh giới epoch, không cắt checkpoint giữa chừng; epoch, evaluation hoặc export đang chạy có thể vượt mốc. Mỗi epoch dùng cơ chế resume native, vì vậy có thêm chi phí nạp model/optimizer so với một tiến trình train liên tục. Không giảm epoch/frame để ép khớp thời gian.

Chỉ xuất lại JSON, không train:

```python
!{PYTHON} -u "{PROJECT}/colab/run_supplemental_suite.py" --config "{CONFIG_FILE}" --export-only
```

Mã thoát 0: hoàn tất các lượt được chọn; 2: hết ngân sách/chưa đủ kết quả; lỗi khác: xem `failure.json`. Lượt chưa train xong giữ trạng thái interrupted và checkpoint resume, không được báo như kết quả hội tụ.

## Kết quả để đọc và cập nhật paper

- `supplemental/paper-results.json`: đầu mối tổng hợp; chứa metric từng seed, mean/sample SD khi có nhiều seed, config, code hash, trạng thái và kết quả từng lượt.
- `supplemental/runs/<variant>-seed-<seed>.json`: trạng thái, history mỗi epoch, số tham số, metric frame/video mean/median và từng manipulation; prediction theo video; tham chiếu và SHA256 checkpoint, CSV, config và môi trường.
- `supplemental/ensembles/seed-42.json`: kết quả ensemble xác suất 50:50 từ matched-head/CNN-only, không train thêm.
- `supplemental/comparisons.json`: dual so với matched/CNN/capacity/ensemble; DeLong và Holm exploratory cho bốn đối chứng trong từng dataset/seed; CI95% của chênh lệch AUC qua paired bootstrap với grouping được cung cấp. Không khẳng định đã hiệu chỉnh chung mọi dataset/seed. Thiếu cặp/membership khác nhau được ghi rõ.
- `supplemental/data-audit.json`: số video/crop, video không crop được, kiểm tra source/group không xuyên split, checksum manifest. Identity separation và tương thích với split lịch sử vẫn cần artifact gốc để xác minh.
- `supplemental/plan.json`, `progress.json`, `current-task.json`, `timing.json`, `failure.json` khi có lỗi: hàng đợi, thời gian thực đo và lý do dừng. `failure.json` là sự kiện lỗi gần nhất, không thay thế trạng thái mới nhất trong `progress.json`.

Giữ cả thư mục native `runs/`: checkpoint `.pt`, frame prediction CSV và môi trường là bằng chứng gốc. JSON tổng hợp đủ để đọc/soạn bảng; không thay thế toàn bộ artifact kiểm chứng. Đọc `progress.json` và cờ `smoke` trước khi sử dụng: fixture/smoke không được đưa vào paper. Một seed có SD bằng `null`, không ghi thành 0. Các thống kê là exploratory khi grouping chưa xác minh; ba seed cũng không bảo đảm Accept hoặc ổn định tuyệt đối.

Sau mỗi lượt đánh giá thành công, JSON tổng hợp được cập nhật. Sau mỗi epoch, JSON của lượt đó và tiến độ được lưu. Có thể đọc kết quả phần đã xong trong khi các phần khác còn thiếu, nhưng mọi số liệu cần được ghi đúng phạm vi.
