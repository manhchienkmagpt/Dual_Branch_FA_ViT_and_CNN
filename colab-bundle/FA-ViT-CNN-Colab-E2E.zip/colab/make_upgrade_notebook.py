"""Build an isolated, cache-reusing balanced-v2 diagnostic/pilot notebook."""
import ast
import json
from pathlib import Path

from make_notebooks import MOUNT, code, md


def main():
    mount = MOUNT.replace("FA-ViT-CNN-Colab-E2E.zip", "FA-ViT-CNN-Upgrade-v2.zip")
    mount = mount.replace("/content/favit-code", "/content/favit-code-v2")
    cells = [md('''# FA-ViT — balanced v2: kiểm tra khả năng học và pilot
Chọn **L4 GPU**. Dừng cell training cũ trước khi chạy notebook này để hai tiến trình không tranh GPU.
Notebook mặc định chỉ chạy kiểm tra gradient/trọng số trên 16 video train, sau đó pilot **3 epoch, fold 1, favit_clip**.
Dùng lại crop/shard, manifest, fold và video loại trừ trong `FA_ViT_CNN_Experiments`.
Kết quả mới lưu riêng trong `FA_ViT_CNN_Upgrade_v2`; không ghi đè checkpoint cũ.
Không cần tải dữ liệu hoặc preprocess lại. Nếu giữ cùng runtime, dùng lại ảnh đã giải nén.

**Thay đổi thử nghiệm:** batch 1 thật + 1 giả, BCE không trọng số/không smoothing;
fine-tune hai block cuối ViT với LR nhỏ, GroupNorm thay BatchNorm ở CNN;
hai epoch đầu chỉ flip, sau đó thêm brightness/JPEG/downscale nhẹ và nhất quán giữa các frame.
Đây là cấu hình ứng viên chưa có kết quả thực nghiệm trên dữ liệu thật; không bảo đảm AUC tăng.
Validation/test giữ phân bố gốc. UADFV/Celeb-DF chỉ dùng đánh giá, không đưa vào sampler train.'''),
             code(mount), md('''## 1. Cấu hình và kiểm tra nguồn cache
Giữ nguyên `SOURCE_ROOT`. `OUTPUT_ROOT` phải khác thư mục nguồn.
`MODE=pilot` chạy kiểm tra khả năng học rồi pilot; `continue` tiếp tục model/fold đang chọn;
`full` là lựa chọn chủ động chạy toàn bộ 50 lượt. Xem pilot trước khi chọn full.'''), code(r'''
import os
SOURCE_ROOT = '/content/drive/MyDrive/FA_ViT_CNN_Experiments' #@param {type:'string'}
OUTPUT_ROOT = '/content/drive/MyDrive/FA_ViT_CNN_Upgrade_v2' #@param {type:'string'}
MODE = 'pilot' #@param ['pilot', 'continue', 'full']
VARIANT = 'favit_clip' #@param ['favit_clip', 'favit_cnn_clip', 'favit_cnn_temporal', 'favit_cnn_no_temporal', 'favit_cnn_no_patch']
FOLD = 1 #@param {type:'integer'}
PILOT_EPOCHS = 3 #@param {type:'integer'}
SANITY_STEPS = 64 #@param {type:'integer'}
assert 1 <= FOLD <= 10 and PILOT_EPOCHS >= 1 and SANITY_STEPS >= 1
source = Path(SOURCE_ROOT).resolve()
output = Path(OUTPUT_ROOT).resolve()
assert source != output and not source.is_relative_to(output) and not output.is_relative_to(source)
CONFIG = json.loads((source/'temporal-session.json').read_text())
CONFIG.update(drive_root=str(output), cache_root=str(source), local_root='/content/favit-temporal-work')
CONFIG['sources'] = {}  # No acquisition in this read-only-cache notebook.
CONFIG['training'].update(strategy='balanced_v2', label_smoothing=0.0, head_dropout=0.1,
    finetune_blocks=2, backbone_lr=1e-5, lr=1e-4, head_lr=3e-4,
    augmentation_warmup_epochs=2, microbatch_size=2, effective_batch_size=8)
CONFIG_FILE = Path('/content/favit-upgrade-config.json')
CONFIG_FILE.write_text(json.dumps(CONFIG, indent=2))
for dataset in ['ffpp', 'uadfv']:
    base = source/'temporal-cache'/dataset
    pointer = json.loads((base/'active.json').read_text())
    index_path = (base/pointer['index']).resolve()
    assert index_path.is_relative_to(base.resolve())
    index = json.loads(index_path.read_text())
    assert index['complete'] and not index['smoke'], f'{dataset}: source cache incomplete'
    print(dataset, 'source cache complete; exclusions:', index.get('excluded_videos', []))
TRAIN_PYTHON = bootstrap['bootstrap_env'](PROJECT, 'training', device='cuda')
def run(stage, *arguments):
    return bootstrap['run_stage'](TRAIN_PYTHON, PROJECT, CONFIG_FILE, stage, *arguments,
                                  drive_root=OUTPUT_ROOT, module='experiments.temporal')
run('doctor')
'''), md('''## 2. Chạy kiểm tra và pilot
Kiểm tra nhỏ chỉ xác nhận gradient hữu hạn, trọng số thật sự cập nhật và đo khả năng học trên video train.
Nó không thay thế kết quả validation. Nếu mất cân bằng dự đoán vẫn kéo dài, cần xem diagnostic thay vì chạy full.
Console mới hiển thị tiến độ giải nén, validation AUC, balanced accuracy, confusion matrix và checkpoint đã lưu.'''), code(r'''
if MODE == 'pilot':
    run('diagnose', '--variant', VARIANT, '--fold', str(FOLD), '--sanity-steps', str(SANITY_STEPS))
    run('pilot', '--variant', VARIANT, '--fold', str(FOLD), '--pilot-epochs', str(PILOT_EPOCHS))
elif MODE == 'continue':
    run('run', '--variant', VARIANT, '--fold', str(FOLD))
else:
    run('run')
'''), md('''## 3. Xem lịch sử validation
Loss v2 là BCE trên batch cân bằng nên không so trực tiếp trị số với loss có trọng số của bản cũ.
Quan sát AUC, balanced accuracy, confusion matrix và phân bố xác suất hai lớp.
Sau pilot, `MODE=continue` tiếp tục từ checkpoint; giữ nguyên OUTPUT_ROOT/config.
Pilot dừng theo giới hạn số epoch gọi lần này; chạy lại pilot có thể train thêm epoch.'''), code(r'''
history_path = output/'temporal-runs'/VARIANT/f'fold-{FOLD:02d}'/'history.json'
if history_path.is_file():
    history = json.loads(history_path.read_text())
    for row in history:
        val = row['validation_video']
        print(f"epoch={row['epoch']} loss={row['train']['loss']:.5f} "
              f"AUC={100*val['auc']:.2f}% balanced_acc={100*val['balanced_accuracy']:.2f}% "
              f"confusion={val['confusion_matrix']}")
    print('Checkpoints:', history_path.parent)
else:
    print('Chưa có epoch hoàn tất; xem log trong OUTPUT_ROOT/logs.')
''')]
    for i, cell in enumerate(cells):
        cell['id'] = f'upgrade-{i:03d}'
        if cell['cell_type'] == 'code':
            ast.parse(cell['source'])
    notebook = {'nbformat': 4, 'nbformat_minor': 5, 'metadata': {
        'colab': {'name': 'FA_ViT_CNN_Upgrade_v2.ipynb'},
        'kernelspec': {'display_name': 'Python 3', 'language': 'python', 'name': 'python3'}}, 'cells': cells}
    target = Path(__file__).with_name('FA_ViT_CNN_Upgrade_v2.ipynb')
    target.write_text(json.dumps(notebook, ensure_ascii=False, indent=1), encoding='utf-8')
    print(target)


if __name__ == '__main__':
    main()
