"""Direct local crop input and frame-AUC Celeb-DF checkpoint selection.

Kept outside experiments/ so the existing Colab checkpoint code hash is intact.
PC runs have their own protocol/signatures and output directory.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys
import time

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

from experiments.common import (atomic_torch_save, clean_json, code_hash, environment,
                                fingerprint, public_config, read_json, require_space, sha256)
from colab.run_supplemental_suite import Evidence, error_text, now, optional_json, plan

PROTOCOL = "pc_crops_celebdf_frame_auc_v1"
EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
METHODS = {"original": ("original", 0), "real": ("original", 0), "0": ("original", 0),
           "fake": ("fake", 1), "1": ("fake", 1), "deepfakes": ("Deepfakes", 1),
           "face2face": ("Face2Face", 1), "faceswap": ("FaceSwap", 1),
           "neuraltextures": ("NeuralTextures", 1), "faceshifter": ("FaceShifter", 1)}
METHODS.update(deepfake=("Deepfakes", 1), neuraltexture=("NeuralTextures", 1))


def protocol_note(known_ffpp_overlap=False):
    note = {"id": PROTOCOL, "gradient_training": "FF++ frames only",
            "checkpoint_selection": "maximum Celeb-DF frame AUC",
            "scheduler_and_early_stopping": "Celeb-DF frame AUC",
            "reporting": {"ffpp": "held-out from checkpoint selection; split separation requires audit",
                          "celebdf": "selection set reused for reporting; NOT an untouched test estimate",
                          "uadfv": "not used for training or checkpoint selection"},
            "video_prediction": "mean/median frame probabilities after checkpoint selection"}
    if known_ffpp_overlap:
        note["reporting"]["ffpp"] = "author-reported train/test overlap; NOT an untouched test estimate"
    return note


def validate_locations(config):
    for name, source in config["pc_data"].items():
        source = Path(source).expanduser().resolve()
        for key in ("drive_root", "local_root"):
            destination = Path(config[key]).expanduser().resolve()
            if destination.is_relative_to(source) or source.is_relative_to(destination):
                raise ValueError(f"Keep {key} separate from input images: {name}")


def annotate_roles(value, known_ffpp_overlap=False):
    if isinstance(value, list):
        return [annotate_roles(item, known_ffpp_overlap) for item in value]
    if isinstance(value, dict):
        result = {key: annotate_roles(item, known_ffpp_overlap) for key, item in value.items()}
        if result.get("dataset") in ("ffpp", "celebdf", "uadfv"):
            result["evaluation_role"] = ("model_selection_reuse" if result["dataset"] == "celebdf" else "post_training_inference")
            if result["dataset"] == "ffpp" and known_ffpp_overlap:
                result["known_training_overlap_reported"] = True
        return result
    return value


def method_key(name):
    return name.lower().replace("_", "").replace("-", "").replace(" ", "")


def images(folder):
    return sorted((p for p in folder.rglob("*") if p.is_file() and p.suffix.lower() in EXTENSIONS),
                  key=lambda p: p.relative_to(folder).as_posix().casefold())


def directories(folder):
    if not folder.is_dir():
        raise FileNotFoundError(f"Missing input directory: {folder}")
    return sorted((p for p in folder.iterdir() if p.is_dir()), key=lambda p: p.name.casefold())


def reject_loose_images(folder):
    if any(p.is_file() and p.suffix.lower() in EXTENSIONS for p in folder.iterdir()):
        raise ValueError(f"Images outside their label/video directories would be ignored: {folder}")


def frame_row(path, root, dataset, method, label, split, video=None, ordinal=0, verify=True):
    if verify:
        from PIL import Image
        data = path.read_bytes()
        with Image.open(io.BytesIO(data)) as image:
            width, height = image.size
            image.verify()
        content_hash, size, modified = hashlib.sha256(data).hexdigest(), len(data), None
    else:
        # Index files without opening or decoding their image contents.
        stat = path.stat()
        content_hash, width, height = None, None, None
        size, modified = stat.st_size, stat.st_mtime_ns
    relative = path.relative_to(root).as_posix()
    return {"dataset": dataset, "split": split, "method": method, "label": label,
            "video_id": f"{dataset}/{method}/{video}" if video is not None else None,
            "video_key": video, "crop_path": f"{dataset}/{split}/{relative}",
            "local_path": str(path.absolute()), "source_relative_path": relative,
            "frame_index": ordinal, "frame_index_kind": "sorted_crop_ordinal",
            "group_id": f"{dataset}/{method}/{video}" if video is not None else None,
            "grouping_verified": 0, "source_ids": "[]", "sha256": content_hash,
            "file_size": size, "mtime_ns": modified, "width": width, "height": height}


def scan_inputs(config, progress=False):
    """Keep every supplied crop; only test folders must identify the parent video."""
    validate_locations(config)
    checks = config.get("pc_input_checks", {})
    verify = checks.get("verify_image_contents", True)
    reject_duplicates = checks.get("reject_identical_train_test", True)
    if not verify and reject_duplicates:
        raise ValueError("Duplicate content detection requires verify_image_contents: true")
    indexed = 0
    def announce(message):
        if progress:
            print(message, file=sys.stderr, flush=True)
    def row(*args, **kwargs):
        nonlocal indexed
        result = frame_row(*args, **kwargs, verify=verify)
        indexed += 1
        if indexed % 10000 == 0:
            announce(f"Indexed {indexed:,} crops ({'content verification' if verify else 'paths/metadata only'})")
        return result
    announce("Reading crop paths and labels" + (" with full content checks" if verify else "; image hashing/duplicate checks skipped"))
    pc = config["pc_data"]
    roots = {key: Path(pc[key]).expanduser().resolve() for key in
             ("ffpp_train_root", "ffpp_test_root", "celebdf_test_root", "uadfv_test_root")}
    for root in roots.values():
        directories(root)
    train_root = roots["ffpp_train_root"]
    if (train_root / "train").is_dir():
        train_root = train_root / "train"
    reject_loose_images(train_root)
    training, test, empty = [], [], []
    recognized = []
    for category in directories(train_root):
        key = method_key(category.name)
        if key in METHODS:
            method, label = METHODS[key]
            recognized.append(key)
            for i, path in enumerate(images(category)):
                training.append(row(path, train_root, "ffpp", method, label, "train", ordinal=i))
        elif images(category):
            raise ValueError(f"Unknown FF++ training label directory: {category}")
    if not recognized or {r["label"] for r in training} != {0, 1}:
        raise ValueError("FF++ training needs real and fake crops under recognized label/method directories")
    announce(f"FF++ train: {len(training):,} crops indexed")

    def add_videos(category, dataset, method, label, root):
        if any(p.is_file() and p.suffix.lower() in EXTENSIONS for p in category.iterdir()):
            raise ValueError(f"Inference requires video subfolders, found loose images: {category}")
        video_folders = directories(category)
        if not video_folders:
            raise ValueError(f"No video folders in inference category: {category}")
        for video in video_folders:
            found = images(video)
            if not found:
                empty.append({"dataset": dataset, "method": method, "video": video.name})
            for i, path in enumerate(found):
                test.append(row(path, root, dataset, method, label, "test", video.name, i))

    ffroot = roots["ffpp_test_root"]
    reject_loose_images(ffroot)
    ff_classes = {p.name.casefold(): p for p in directories(ffroot)}
    if set(ff_classes) != {"real", "fake"}:
        raise ValueError("FF++ inference root must contain real/<video> and fake/<method>/<video>")
    add_videos(ff_classes["real"], "ffpp", "original", 0, ffroot)
    reject_loose_images(ff_classes["fake"])
    found_methods = set()
    for category in directories(ff_classes["fake"]):
        key = method_key(category.name)
        if key not in METHODS or METHODS[key][0] in ("original", "fake"):
            raise ValueError(f"Unknown FF++ fake method directory: {category}")
        method, label = METHODS[key]
        if method in found_methods:
            raise ValueError(f"Duplicate FF++ fake method alias: {category}")
        found_methods.add(method)
        add_videos(category, "ffpp", method, label, ffroot)
    expected = {"Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures", "FaceShifter"}
    if found_methods != expected:
        raise ValueError("FF++ inference requires all five methods; missing: " + str(sorted(expected - found_methods)))
    for dataset, key, mapping in (("celebdf", "celebdf_test_root", {"0": ("real", 0), "1": ("fake", 1)}),
                                  ("uadfv", "uadfv_test_root", {"real": ("real", 0), "fake": ("fake", 1)})):
        root = roots[key]
        reject_loose_images(root)
        classes = {p.name.casefold(): p for p in directories(root)}
        if set(classes) != set(mapping):
            raise ValueError(f"{dataset} root must contain exactly {list(mapping)} label directories")
        for name, (method, label) in mapping.items():
            add_videos(classes[name], dataset, method, label, root)
    if empty:
        raise ValueError("Empty video folders must be reviewed before inference: " + json.dumps(empty[:10]))
    for dataset in ("ffpp", "celebdf", "uadfv"):
        if {r["label"] for r in test if r["dataset"] == dataset} != {0, 1}:
            raise ValueError(f"{dataset} inference needs nonempty real and fake video folders")
    all_rows = training + test
    if len({r["crop_path"].casefold() for r in all_rows}) != len(all_rows):
        raise ValueError("Duplicate crop identities")
    overlaps = []
    if verify:
        train_hashes = {r["sha256"] for r in training}
        overlaps = [r["crop_path"] for r in test if r["dataset"] == "ffpp" and r["sha256"] in train_hashes]
    if overlaps and reject_duplicates:
        raise ValueError("Identical images occur in FF++ train and test: " + json.dumps(overlaps[:10]))
    # UADFV source pairing is asserted only for exact, one-to-one folder-ID matches.
    real = {r["video_key"] for r in test if r["dataset"] == "uadfv" and r["label"] == 0}
    fake = {r["video_key"] for r in test if r["dataset"] == "uadfv" and r["label"] == 1}
    if real == fake:
        for row in test:
            if row["dataset"] == "uadfv":
                row.update(group_id="uadfv:" + row["video_key"], grouping_verified=1,
                           source_ids=json.dumps([row["video_key"]]))
    # No identity/source metadata is invented for flat FF++ training or Celeb-DF.
    portable = [{k: v for k, v in row.items() if k != "local_path"} for row in all_rows]
    if not verify:
        fields = {"dataset", "split", "method", "label", "video_id", "crop_path", "frame_index",
                  "group_id", "grouping_verified", "file_size", "mtime_ns"}
        portable = [{k: v for k, v in item.items() if k in fields} for item in portable]
    data_hash = fingerprint(portable)
    counts = dict(Counter(f"{r['dataset']}/{r['split']}/{r['method']}" for r in all_rows))
    videos = Counter(r["dataset"] for r in {row["video_id"]: row for row in test}.values())
    verification = {"mode": "full" if verify else "quick", "image_contents_verified": bool(verify),
                    "fingerprint_basis": "sha256_contents" if verify else "paths_sizes_mtimes_only",
                    "ffpp_duplicate_check": "performed" if verify else "skipped_by_user_configuration",
                    "reject_identical_train_test": bool(reject_duplicates),
                    "known_ffpp_overlap_reported": bool(checks.get("known_ffpp_overlap_reported", False) or overlaps)}
    audit = {"status": "checked" if verify else "indexed_without_content_checks", "dataset_hash": data_hash,
             "input_verification": verification, "roots": {k: str(v) for k, v in roots.items()},
             "resolved_ffpp_train_root": str(train_root), "frame_counts": counts, "test_video_counts": dict(videos),
             "training_video_membership": "not required; unknown for flat training images",
             "ffpp_identical_train_test_images": len(overlaps) if verify else None,
             "ffpp_source_video_separation": "not_established",
             "identity_disjointness": "not_established", "official_test_membership": "not_verified_from_folders",
             "uadfv_pairing_verified_by_folder_ids": real == fake,
             "sampling": "all existing supplied crops; no subsampling, recropping or source-file changes",
             "evaluation_protocol": protocol_note(verification["known_ffpp_overlap_reported"])}
    announce(f"Input index ready: {len(training):,} training crops; {len(test):,} inference crops")
    return {"train": training, "selection": [r for r in test if r["dataset"] == "celebdf"],
            "test": test, "dataset_hash": data_hash, "audit": audit, "portable": portable}


def pc_signature(config, data, runtime, variant, seed):
    return fingerprint({"protocol": PROTOCOL, "training": config["training"], "data": data["dataset_hash"],
                        "runtime": {k: runtime[k] for k in ("precision", "microbatch_size")},
                        "variant": variant, "seed": seed, "code": code_hash(),
                        "pc_adapter": sha256(Path(__file__)), "smoke": bool(config.get("smoke"))})


class PCEvidence(Evidence):
    def __init__(self, config, data, runtime, phase="all"):
        super().__init__(config, phase)
        self.data, self.runtime = data, runtime

    def save(self, name, value):
        known_overlap = self.data["audit"]["input_verification"]["known_ffpp_overlap_reported"]
        if isinstance(value, dict):
            value = {**value, "evaluation_protocol": self.data["audit"]["evaluation_protocol"],
                     "input_verification": self.data["audit"]["input_verification"]}
        super().save(name, annotate_roles(value, known_overlap))

    def save_native(self, path, value):
        self.save("../" + Path(path).relative_to(self.drive).as_posix(), value)

    def export_run(self, job):
        from experiments.evaluation import checked_predictions, evaluation_tables, aggregate_videos
        import pandas as pd
        folder = self.drive / "runs" / job["variant"] / f"seed-{job['seed']}"
        state = optional_json(folder / "state.json", {})
        result = {**job, "status": state.get("status", "not_started"), "state": state,
                  "updated_at": now(), "smoke": bool(self.config.get("smoke")), "metrics": [],
                  "history": optional_json(folder / "history.json", []), "artifacts": {},
                  "descriptive_results_available": False, "evaluation_protocol": self.data["audit"]["evaluation_protocol"],
                  "input_verification": self.data["audit"]["input_verification"]}
        predictions = None
        try:
            if state:
                if state.get("signature") != pc_signature(self.config, self.data, self.runtime, job["variant"], job["seed"]):
                    raise ValueError("PC run input/config/code/precision differs; use a new output directory")
                if state.get("protocol") != PROTOCOL:
                    raise ValueError("Checkpoint belongs to another selection protocol")
            for name in ("config.json", "model-info.json", "environment.json", "history.json", "state.json"):
                path = folder / name
                if path.exists():
                    result["artifacts"][name] = self.reference(path)
            result["config"] = optional_json(folder / "config.json")
            result["model_info"] = optional_json(folder / "model-info.json")
            if state.get("status") == "completed":
                best = folder / "best.pt"
                if not best.is_file() or sha256(best) != state.get("best_sha256"):
                    raise ValueError("Best checkpoint missing or corrupt")
                result["artifacts"]["best.pt"] = self.reference(best)
                result["status"] = "evaluation_pending"
                status = optional_json(folder / "evaluation/status.json")
                csv = folder / "evaluation/frame-predictions.csv"
                if status:
                    if (status.get("signature") != state["signature"] or status.get("best_sha256") != state["best_sha256"]
                            or not csv.is_file() or sha256(csv) != status.get("predictions_sha256")):
                        raise ValueError("Inference is stale or corrupt")
                    predictions = checked_predictions(pd.read_csv(csv))
                    if set(predictions.crop_path) != {r["crop_path"] for r in self.data["test"]}:
                        raise ValueError("Inference crop membership differs")
                    result.update(status="completed", descriptive_results_available=True,
                                  metrics=evaluation_tables(predictions, self.config["evaluation"]["threshold"]),
                                  video_predictions=aggregate_videos(predictions).to_dict(orient="records"),
                                  video_predictions_median=aggregate_videos(predictions, "median").to_dict(orient="records"))
                    result["artifacts"]["frame-predictions.csv"] = self.reference(csv)
        except Exception as error:
            predictions = None
            result.update(status="invalid", error=error_text(error), metrics=[], descriptive_results_available=False)
        self.save(f"runs/{job['id']}.json", result)
        return result, predictions


def train_epoch(config, data, runtime, evidence, job, model_factory=None):
    import torch
    from experiments.training import (loader_for, one_epoch, cpu_state, rng_state, restore_rng, ensure_best)
    from experiments.models import build_experiment_model, seed_everything, parameter_counts, encoder_hash
    variant, seed = job["variant"], job["seed"]
    folder = Path(config["drive_root"]) / "runs" / variant / f"seed-{seed}"
    folder.mkdir(parents=True, exist_ok=True)
    signature = pc_signature(config, data, runtime, variant, seed)
    state = optional_json(folder / "state.json", {})
    if state and (state.get("signature") != signature or state.get("protocol") != PROTOCOL):
        raise ValueError("PC run protocol/data/config/code changed; use a new output directory")
    if state.get("status") == "completed":
        if sha256(folder / "best.pt") != state["best_sha256"]:
            raise ValueError("Completed PC checkpoint is corrupt")
        return True
    if not state:
        evidence.save_native(folder / "state.json", {"status": "interrupted", "signature": signature,
                            "epoch": 0, "best_sha256": None, "protocol": PROTOCOL,
                            "smoke": bool(config.get("smoke"))})
    training = config["training"]
    device = torch.device(runtime["device"])
    if runtime["precision"] == "bf16" and (device.type != "cuda" or not torch.cuda.is_bf16_supported()):
        raise ValueError("PC resume requires BF16 support matching its calibrated protocol")
    seed_everything(seed)
    model = model_factory(variant, seed) if model_factory else build_experiment_model(variant, config, seed)
    info = {**parameter_counts(model), "variant": variant, "seed": seed, "runtime": runtime,
            "encoder_initial_sha256": encoder_hash(model), "dataset_hash": data["dataset_hash"],
            "protocol": PROTOCOL}
    if info["encoder_initial_sha256"] is not None:
        initialization = evidence.drive / "initializations" / f"pc-seed-{seed}.json"
        old_initialization = optional_json(initialization)
        if old_initialization and old_initialization["encoder_sha256"] != info["encoder_initial_sha256"]:
            raise ValueError("Encoder initialization differs between PC variants")
        evidence.save_native(initialization, {"encoder_sha256": info["encoder_initial_sha256"], "seed": seed})
    model.to(device)
    optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                                 lr=float(training["lr"]), weight_decay=float(training["weight_decay"]))
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode="max", factor=float(training["scheduler_factor"]),
                    patience=max(0, int(training["scheduler_patience"]) - 1), min_lr=float(training["min_lr"]))
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and runtime["precision"] == "fp16")
    positives = sum(r["label"] for r in data["train"])
    weight = training.get("pos_weight")
    weight = (len(data["train"]) - positives) / positives if weight is None else float(weight)
    if weight <= 0 or not math.isfinite(weight):
        raise ValueError("Positive finite class weight required")
    criterion = torch.nn.BCEWithLogitsLoss(pos_weight=torch.tensor(weight, device=device), reduction="sum")
    epoch, best, bad, history, best_hash = 1, -math.inf, 0, [], state.get("best_sha256")
    last = folder / "last.pt"
    if last.exists():
        saved = torch.load(last, map_location="cpu", weights_only=False)
        if saved["signature"] != signature:
            raise ValueError("Resume checkpoint signature differs")
        model.load_state_dict(saved["model"], strict=True)
        optimizer.load_state_dict(saved["optimizer"])
        scheduler.load_state_dict(saved["scheduler"])
        scaler.load_state_dict(saved["scaler"])
        restore_rng(saved["rng"])
        epoch, best, bad, history, best_hash = saved["epoch"] + 1, saved["best"], saved["bad_epochs"], saved["history"], saved["best_sha256"]
        ensure_best(folder, best_hash)
    elif state and state.get("epoch", 0) > 0:
        raise ValueError("Interrupted PC run has no resume checkpoint; refusing to restart it silently")
    for name, value in (("config.json", public_config(config)), ("model-info.json", info), ("environment.json", environment())):
        evidence.save_native(folder / name, value)
    started = time.monotonic()
    train_loader = loader_for(data["train"], config, True, seed, epoch, runtime["microbatch_size"])
    train_loader.dataset.smoothing = float(training["label_smoothing"])
    selection_loader = loader_for(data["selection"], config, False, seed, epoch, runtime["microbatch_size"])
    train_metrics = one_epoch(model, train_loader, device, criterion, runtime["precision"], optimizer, scaler,
                              int(training["effective_batch_size"]))
    selection_metrics = one_epoch(model, selection_loader, device, criterion, runtime["precision"])
    score = float(selection_metrics["auc"])
    if not math.isfinite(score):
        raise ValueError("Celeb-DF frame AUC is non-finite; cannot select checkpoint")
    if score > best:
        best, bad = score, 0
        best_hash = atomic_torch_save({"model": cpu_state(model), "signature": signature, "epoch": epoch,
                                      "variant": variant, "seed": seed, "protocol": PROTOCOL},
                                     folder / ".best-candidate.pt", config["local_root"])
    else:
        bad += 1
    scheduler.step(score)
    history.append(clean_json({"epoch": epoch, "train": train_metrics, "selection": selection_metrics,
                    "selection_dataset": "celebdf", "selection_level": "frame", "selection_metric": "auc",
                    "lr": optimizer.param_groups[0]["lr"], "bad_epochs": bad,
                    "seconds": time.monotonic() - started}))
    atomic_torch_save({"model": cpu_state(model), "optimizer": optimizer.state_dict(), "scheduler": scheduler.state_dict(),
                      "scaler": scaler.state_dict(), "rng": rng_state(), "epoch": epoch, "best": best,
                      "bad_epochs": bad, "history": history, "signature": signature, "best_sha256": best_hash},
                     last, config["local_root"])
    ensure_best(folder, best_hash)
    finished = epoch >= int(training["epochs"]) or bad >= int(training["early_stopping_patience"])
    evidence.save_native(folder / "history.json", history)
    evidence.save_native(folder / "state.json",
                  {"status": "completed" if finished else "interrupted", "signature": signature,
                   "epoch": epoch, "best_sha256": best_hash, "best_selection_auc": best, "protocol": PROTOCOL,
                   "smoke": bool(config.get("smoke"))})
    print(f"{variant}, seed {seed}, epoch {epoch}: Celeb-DF frame AUC={score:.5f}, best={best:.5f}", flush=True)
    return finished


def infer(config, data, runtime, evidence, job, model_factory=None):
    import pandas as pd
    import torch
    from experiments.training import loader_for, precision_context
    from experiments.models import build_experiment_model
    folder = evidence.drive / "runs" / job["variant"] / f"seed-{job['seed']}"
    state = read_json(folder / "state.json")
    signature = pc_signature(config, data, runtime, job["variant"], job["seed"])
    if state.get("status") != "completed" or state.get("signature") != signature:
        raise ValueError("PC training is not complete or checkpoint protocol differs")
    if sha256(folder / "best.pt") != state["best_sha256"]:
        raise ValueError("PC best checkpoint is corrupt")
    old, predictions = evidence.export_run(job)
    if old["status"] == "completed":
        return
    model = model_factory(job["variant"], job["seed"]) if model_factory else build_experiment_model(
        job["variant"], config, job["seed"], pretrained=False)
    saved = torch.load(folder / "best.pt", map_location="cpu", weights_only=False)
    if saved["signature"] != signature:
        raise ValueError("PC checkpoint content signature differs")
    model.load_state_dict(saved["model"], strict=True)
    device = torch.device(runtime["device"])
    model.to(device).eval()
    rows = []
    loader = loader_for(data["test"], config, False, job["seed"], microbatch=runtime["microbatch_size"])
    with torch.inference_mode():
        for images_batch, _, indices in loader:
            with precision_context(device, runtime["precision"]):
                scores = model(images_batch.to(device)).float().sigmoid().cpu().tolist()
            for i, score in zip(indices.tolist(), scores):
                rows.append({**{k: v for k, v in data["test"][i].items() if k != "local_path"}, "probability": score})
    evaluation = folder / "evaluation"
    evaluation.mkdir(exist_ok=True)
    csv = evaluation / "frame-predictions.csv"
    pd.DataFrame(rows).to_csv(csv, index=False)
    evidence.save_native(evaluation / "status.json",
                  {"signature": signature, "best_sha256": state["best_sha256"], "predictions_sha256": sha256(csv)})


def run_pc(config, phase="all", max_hours=24, export_only=False, model_factory=None,
           clock=time.monotonic, inspect_only=False):
    import torch
    from experiments.training import calibrate, runtime_settings
    validate_locations(config)
    root = Path(config["drive_root"])
    basic = Evidence(config, phase)
    basic.save("pc-plan.json", {"jobs": plan(phase), "evaluation_protocol": protocol_note(), "max_hours": max_hours})
    started = clock()
    evidence = None
    try:
        if not config.get("smoke"):
            require_space(root, 3)
        data = scan_inputs(config, progress=True)
        basic.save("data-audit.json", data["audit"])
        basic.save("input-manifest.json", {"dataset_hash": data["dataset_hash"], "frames": data["portable"]})
        if inspect_only:
            return data["audit"]
        if not config.get("smoke") and not export_only:
            if not torch.cuda.is_available():
                raise RuntimeError("CUDA GPU required for PC training; check the Windows PyTorch CUDA build")
            # Actual execution catches architecture/driver incompatibility before training.
            probe = torch.randn(16, 16, device="cuda", requires_grad=True)
            (probe @ probe).sum().backward()
            torch.cuda.synchronize()
            del probe
            torch.cuda.empty_cache()
            if not (root / "runtime.json").exists():
                calibrate(config)
        if export_only and not (root / "runtime.json").exists() and not any((root / "runs").glob("*/seed-*/state.json")):
            runtime = {"device": "cpu", "precision": "uninitialized", "microbatch_size": config["training"]["microbatch_size"]}
        else:
            runtime = runtime_settings(config)
        if not config.get("smoke"):
            os.environ.setdefault("HF_HOME", str(root / "pretrained-cache" / "huggingface"))
            os.environ.setdefault("TORCH_HOME", str(root / "pretrained-cache" / "torch"))
        evidence = PCEvidence(config, data, runtime, phase)
        evidence.export("exported" if export_only else "running")
        if export_only:
            return evidence.export("exported")
        limit = max_hours * 3600 if max_hours else math.inf
        last_epoch_seconds = 0
        for job in evidence.jobs:
            folder = root / "runs" / job["variant"] / f"seed-{job['seed']}"
            if folder.exists() and not (folder / "state.json").exists() and any(folder.iterdir()):
                raise ValueError(f"Unverified run folder; refusing to overwrite: {folder}")
            while True:
                remaining = limit - (clock() - started)
                if remaining <= 0 or remaining < last_epoch_seconds:
                    evidence.save("current-task.json", {**job, "status": "budget_exhausted", "at": now()})
                    return evidence.export("budget_exhausted", job["id"])
                before = clock()
                previous_epoch = optional_json(folder / "state.json", {}).get("epoch", 0)
                evidence.save("current-task.json", {**job, "status": "training", "started_at": now()})
                done = train_epoch(config, data, runtime, evidence, job, model_factory)
                last_epoch_seconds = clock() - before
                epoch = read_json(folder / "state.json")["epoch"]
                if epoch > previous_epoch:
                    timing = optional_json(evidence.root / "timing.json", {"epochs": [], "evaluations": []})
                    timing["epochs"].append({"run": job["id"], "epoch": epoch, "seconds": last_epoch_seconds,
                                             "finished_at": now()})
                    evidence.save("timing.json", timing)
                evidence.export_run(job)
                evidence.save("current-task.json", {**job, "status": "training", "updated_at": now()})
                progress = optional_json(evidence.root / "progress.json", {})
                progress.update(status="running", active_run=job["id"], updated_at=now())
                evidence.save("progress.json", progress)
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                if done:
                    break
            if clock() - started >= limit:
                evidence.save("current-task.json", {**job, "status": "budget_exhausted", "at": now()})
                return evidence.export("budget_exhausted", job["id"])
            evaluation_started = clock()
            previous_evaluation = optional_json(folder / "evaluation/status.json")
            evidence.save("current-task.json", {**job, "status": "evaluating", "started_at": now()})
            infer(config, data, runtime, evidence, job, model_factory)
            if previous_evaluation != optional_json(folder / "evaluation/status.json"):
                timing = optional_json(evidence.root / "timing.json", {"epochs": [], "evaluations": []})
                timing["evaluations"].append({"run": job["id"], "seconds": clock() - evaluation_started,
                                              "finished_at": now()})
                evidence.save("timing.json", timing)
            evidence.export("running", job["id"])
        evidence.save("current-task.json", {"status": "completed", "at": now()})
        return evidence.export("completed")
    except BaseException as error:
        status = "interrupted" if isinstance(error, KeyboardInterrupt) else "blocked"
        failure = {"status": status, "error": error_text(error), "at": now(), "evaluation_protocol": protocol_note()}
        basic.save("failure.json", failure)
        basic.save("current-task.json", {**optional_json(basic.root / "current-task.json", {}), **failure})
        if evidence is not None:
            try:
                evidence.export(status)
            except Exception as export_error:
                basic.save("export-failure.json", {"error": error_text(export_error), "at": now()})
        else:
            basic.save("progress.json", {**failure, "complete": False})
        raise
