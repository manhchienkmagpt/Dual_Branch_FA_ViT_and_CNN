# FA-ViT-CNN: Colab end-to-end

**Workflow mới cho video và 10-fold:** dùng một notebook
[`FA_ViT_CNN_10Fold.ipynb`](FA_ViT_CNN_10Fold.ipynb), theo
[`TEMPORAL-10FOLD-VI.md`](TEMPORAL-10FOLD-VI.md). Tải video trên CPU, lưu cả
video/frame lên Drive, chỉ bật GPU khi cần MTCNN/training. Celeb-DF nhận ZIP
thủ công ở cuối. Phần bên dưới mô tả workflow frame cũ, dùng Drive root riêng.

Bộ này chuẩn bị dữ liệu, chạy hai đối chứng còn thiếu và lưu bằng chứng để cập nhật paper. Chạy **notebook 01 trước, notebook 02 sau** với GPU L4.

Phạm vi hiện tại: **`favit_matched` và `cnn_only`, seed 42 — tổng cộng hai lượt train**. FA-ViT linear và FA-ViT-CNN đã có kết quả trong paper nên không nằm trong hàng đợi bổ sung. Giữ nguyên nguồn dữ liệu, split, MTCNN, ảnh 224×224, 20 frame train/50 frame validation-test, tối đa 30 epoch và patience 5. Giới hạn khoảng một ngày chưa bảo đảm đủ với cấu hình nguyên bản; cần đo thời gian epoch thực tế.

Để chạy thêm toàn bộ ablation còn thiếu và hai cặp seed bổ sung bằng **script riêng**, dùng [`run_supplemental_suite.py`](run_supplemental_suite.py); xem [hướng dẫn và các file JSON](SUPPLEMENTAL-SUITE-VI.md). Script ưu tiên matched-head/CNN/capacity, tái sử dụng artifact hợp lệ và xuất `supplemental/paper-results.json` sau từng lượt. Notebook 02 và autopilot vẫn mặc định hai lượt đã chọn; script mở rộng được gọi bằng lệnh riêng.

Để tự động upload, chọn L4, nhận log và sửa lỗi qua Antigravity/Codex, xem [AUTOPILOT-VI.md](AUTOPILOT-VI.md). Trên máy local: `python colab/autopilot.py doctor`, rồi `python colab/autopilot.py start`. Không chạy thủ công song song khi bộ điều phối đang hoạt động.

FF++ ưu tiên mirror chính thức **EU2** vì EU/canis:8100 hiện từ chối kết nối. Pipeline kiểm tra danh mục mirror và chuyển sang mirror chính thức khác khi cần, giữ các video đã tải. Nếu mọi mirror đều không truy cập được, hệ thống giữ dữ liệu và thử lại có giới hạn; không sửa code chỉ vì server ngừng hoạt động.

## Bắt đầu nhanh

1. Upload `FA-ViT-CNN-Colab-E2E.zip` vào thư mục gốc **MyDrive**. Không cần giải nén trên Drive.
2. Mở `01_prepare_data.ipynb` trong Google Colab bằng **File → Upload notebook**. Chọn GPU runtime.
3. Chạy cell mount Drive và thiết lập môi trường. Ba nguồn tải đã được điền sẵn theo yêu cầu của bạn; đọc điều khoản FF++ và bật checkbox xác nhận trước khi chạy tải.
4. Chạy tải → kiểm tra manifest → preprocess → xem ảnh mẫu. Cache được lưu trên Drive sau từng shard.
5. Mở `02_run_experiments.ipynb`, cùng ZIP và Drive root. Chạy kiểm tra GPU, train, evaluate, summarize.

Mặc định Drive root là `/content/drive/MyDrive/FA_ViT_CNN_Experiments`. Đổi đường dẫn ở cell đầu tiên nếu cần. Bản code chạy được giải nén vào ổ tạm Colab; không cần push lên GitHub. `BUNDLE-MANIFEST.json` lưu checksum các file trong gói.

## Những đầu vào bạn cần cung cấp

| Dataset | Cách lấy | Đầu vào notebook |
|---|---|---|
| FF++ c23 và FaceShifter | Script v4 do bạn cung cấp | `https://kaldir.vc.in.tum.de/faceforensics_download_v4.py` |
| Celeb-DF-v2 | ZIP trên Drive do bạn cung cấp | `https://drive.google.com/file/d/1iLx76wsbi9itnkxSqz9BVBl4ZvnbIazj/view` |
| UADFV | Kaggle mirror do bạn chọn | `kagglehub.dataset_download("adityakeshri9234/uadfv-dataset")` |

Không cần nhập lại ba nguồn. UADFV được nhận diện là mirror trên Kaggle, không phải máy chủ gốc của tác giả; manifest vẫn kiểm tra đủ 49 real + 49 fake video và quan hệ tên cặp. KaggleHub trả về thư mục dữ liệu; pipeline đọc video trực tiếp từ thư mục đó, không cố giải nén nó như file ZIP hoặc sao chép toàn bộ video lên Drive. Phiên bản Kaggle xác định được từ cache sẽ được ghi vào provenance và tái sử dụng khi chạy lại.

Mirror Kaggle có cả video và ảnh frame có sẵn. Pipeline chỉ chọn file video, bỏ qua các ảnh có sẵn để mọi dataset đều được crop bằng cùng MTCNN và cùng protocol.

Nếu Kaggle yêu cầu đăng nhập, thêm **Colab Secret** tên `KAGGLE_API_TOKEN`, cho phép notebook truy cập rồi bật `USE_KAGGLE_SECRET`. Mặc định thử nguồn public, không bắt đăng nhập. Token chỉ nằm trong biến môi trường và được truyền tới tiến trình tải; không được ghi vào config, notebook output hoặc gói ZIP. Có thể ghi đè `sources.uadfv.source` bằng archive URL/path để dùng cách tải cũ.

ZIP Celeb-DF đã được xác nhận tên `Celeb-DF-v2.zip`, dung lượng khoảng 9,95 GB. Cấu hình mới yêu cầu tối thiểu 40 GiB local trống trước bước tải để có chỗ cho cả ZIP, dữ liệu giải nén và FF++. Không tải gói này xuống workspace khi chỉ kiểm tra cấu hình.

HTTP/Drive downloads có thể chịu giới hạn quota hoặc link hết hạn. Pipeline dừng với lỗi để sửa nguồn; không thay dữ liệu bằng bộ khác. Download FF++ có thể tiếp tục các file mà script chính thức đã tải. ZIP/TAR được kiểm tra đường dẫn trước khi giải nén. Archive có checksum do nhà cung cấp công bố có thể thêm vào config để đối chiếu.

## Chia tập và preprocess

- FF++ dùng original và đủ **năm** phương pháp giả, c23. Các JSON split chính thức được snapshot khi chuẩn bị lần đầu, lưu checksum. Không chia theo thứ tự tên video.
- Cả target/source ID của video giả phải ở cùng split và cùng cặp nguồn. Đây là kiểm tra theo ID nguồn, **không chứng minh identity-disjointness**; nhiều ID nguồn vẫn có thể liên quan cùng người hoặc cùng video YouTube.
- Celeb-DF dùng đúng danh sách 518 video test; nhãn danh sách chính thức `1=real, 0=fake` được đổi sang nhãn mô hình `0=real, 1=fake`.
- UADFV ghép real/fake theo tên gốc chỉ khi có quan hệ một-một rõ ràng. Nếu không xác lập được, grouping được đánh dấu chưa xác minh.
- MTCNN lấy khuôn mặt lớn nhất, margin 20%, JPEG quality 95, resize 224×224. Tối đa 20 frame/video train, 50 frame/video validation/test. Video ngắn không tạo frame index trùng.
- Frame đọc lỗi, không có mặt và video không có crop đều có log coverage. Mặc định evaluation dừng khi có test video không có crop; muốn phân tích subset phải bật `evaluation.allow_missing_videos`, và báo cáo vẫn đánh dấu chưa đầy đủ.

Manifest giữ dataset, split, phương pháp, video ID, source IDs, group ID, nhãn, frame index và crop path. `data.groups_csv` nhận metadata nhóm bổ sung do tác giả xác minh, với cột `dataset,video_id,group_id`, phủ đầy đủ dataset tương ứng. Không tự đoán danh tính Celeb-DF từ tên file.

## Drive, dung lượng và nhiều phiên

```text
FA_ViT_CNN_Experiments/
  cache/                 # TAR shards, checksums, preview; không phải hàng trăm nghìn file lẻ
  manifests/             # Video provenance, official split snapshot, trạng thái tải
  pretrained-cache/      # Trọng số pretrained dùng chung giữa các phiên
  runtime.json           # Microbatch/precision đã chốt cho cả bộ
  protocol.json          # Cấu hình không chứa link riêng
  runs/<variant>/seed-N/ # Best, resume đang chạy, config, environment, history, predictions
  summaries/             # CSV, JSON, LaTeX, biểu đồ, báo cáo tiếng Việt
```

Video gốc chỉ ở `/content/favit-work/raw`, không được tự upload lên Drive. Chúng mất khi Colab thu hồi runtime. Sau khi cache đủ, notebook 01 bỏ qua tải lại; notebook 02 khôi phục shard xuống ổ local để train nhanh hơn.

`doctor` in dung lượng trống và ước lượng weights còn phải lưu cho hai lượt được chọn, chưa kể crop cache, pretrained cache và chỗ tạm cho checkpoint. Cần kiểm tra quota thực tế trong giao diện Drive: số dung lượng do filesystem báo có thể không phản ánh đúng quota tài khoản.

Tiền xử lý lưu sau mỗi shard 64 video. Ngắt giữa shard thì làm lại shard đó; các shard đã lưu và đúng checksum được bỏ qua. Chỉ một shard được giải nén tạm khi tạo, nhưng khi training các shard crop cần nằm trên ổ local.

Training lưu sau **mỗi epoch**, gồm optimizer/scheduler/scaler/RNG và early stopping. Resume từ epoch hoàn tất gần nhất; phần epoch bị ngắt phải chạy lại. `best.pt` được xác minh checksum; quá trình công bố best/last có cơ chế phục hồi khi ngắt giữa hai lần ghi. Run hoàn tất giữ best inference weights và mặc định xóa resume riêng của chính runner để giảm dung lượng. Không xóa file của người dùng.

Nếu đổi code khoa học, dữ liệu, số seed, augmentation, microbatch hoặc precision sau khi đã chạy, dùng Drive root mới. Các run khác protocol không được trộn. Chọn GPU tương thích với precision/bộ nhớ đã chốt khi resume; OOM không tự giảm batch giữa các mô hình.

## Bộ thí nghiệm

| Variant | Nội dung |
|---|---|
| `favit_linear` | Encoder FA-ViT hiện có + linear head |
| `favit_matched` | Cùng encoder + LN–Dropout–linear head |
| `favit_cnn` | Cùng encoder + CNN RGB độc lập + head LN–Dropout |
| `cnn_only` | CNN độc lập + head LN–Dropout |
| `favit_capacity` | FA-ViT + residual MLP 768→168→768 + head LN–Dropout |

Mặc định chỉ chọn `favit_matched` và `cnn_only`, seed `42`: **hai lượt train**. Bảng trên mô tả toàn bộ biến thể mà code hỗ trợ; linear, dual và capacity control không được lên lịch. Encoder khởi tạo theo seed và hash khởi tạo được lưu để kiểm tra. CNN-only và nhánh CNN của dual dùng chung quy tắc khởi tạo theo seed.

Capacity control thêm 258,984 tham số; dual thêm 258,688 so với matched-head baseline, chênh khoảng 0.11% phần thêm. Đây là đối chứng dung lượng, không phải cơ chế tương đương CNN.

Cấu hình mới: AdamW, lr/weight decay `1e-4`, tối đa 30 epoch, effective batch 16, label smoothing 0.05, pos_weight từ nhãn train, Dropout head 0.3, FAL tắt. Best/scheduler/early stopping dựa FF++ validation accuracy; early stopping patience 5. Không chọn checkpoint bằng test cross-dataset. BF16 nếu hỗ trợ, nếu không FP16; calibration chốt microbatch chung trước khi chạy.

Các số mới **không tự động tái lập bảng cũ**: split cũ và lịch sử run chưa được xác minh. Bộ mới tạo một protocol có thể truy vết. Các lệnh cũ `training_model/train.py` vẫn giữ nguyên.

## Kết quả và giới hạn thống kê

Mỗi run xuất frame predictions, video predictions mean/median, coverage và metric tables. Có FF++ từng manipulation lẫn tổng, Celeb-DF và UADFV; Accuracy/AUC/Precision/Recall/F1. Video aggregation không coi từng frame là mẫu độc lập.

Ensemble lấy trung bình xác suất **50:50** từ `favit_matched` và `cnn_only` cùng seed, cùng crop membership. Không tune trọng số trên test.

Báo cáo hiện tại có hai đối chứng và ensemble 50:50 của chúng. Một seed không có sample standard deviation qua seed. Khi chưa nhập predictions FA-ViT-CNN cũ, so sánh dual/matched-head được ghi thiếu dữ liệu, không tự chép số trong paper vào pipeline. Chỉ so trực tiếp với bảng cũ khi xác minh cùng split, crop, lịch train và tập test. Các chức năng DeLong/Holm/bootstrap vẫn được giữ cho dữ liệu cặp đầy đủ; thiếu grouping không được coi là đã giải quyết phụ thuộc nguồn/danh tính.

Các file tổng hợp:

- `metrics-per-seed.csv`, `metrics-mean-std.csv`, `results.tex`.
- `paired-delong-exploratory.csv`, `primary-comparison-bootstrap.json`.
- `parameter-counts.json`, `video-auc.png/pdf`, `training-curves.png`.
- `REPORT-VI.md`, `progress.json` có các lượt/dataset thiếu và phân tích subset.

## Chạy bằng CLI và kiểm thử

Trong notebook, tiến độ tải được cập nhật tại chỗ: mỗi lượt tải (ví dụ `original`, `Deepfakes`) có một thanh riêng, kèm phần trăm, số file và thời gian ước tính từ downloader. Các thông báo/lỗi vẫn hiển thị riêng; log trên Drive giữ toàn bộ lần cập nhật. Khi chạy qua terminal, thanh tiến độ cập nhật trên cùng dòng.

Để áp dụng thay đổi hiển thị cho notebook đang mở: thay gói ZIP trên Drive bằng bản mới, chạy lại cell giải nén/nạp `bootstrap`, rồi chạy lại cell tải dữ liệu. Giữ nguyên runtime và `local_root` để downloader tiếp tục dùng các video đã tải. Phiên tải đang chạy vẫn dùng bộ hiển thị cũ cho đến khi chạy lại cell.

Nếu một bước báo lỗi, notebook hiển thị stdout/stderr của tiến trình và lưu bản log tại `DRIVE_ROOT/logs/<stage>-<timestamp>.log`. Với lỗi `prepare`, xem thêm `manifests/preparation-status.json` để biết dataset nào chưa sẵn sàng. Có thể chạy lại riêng FF++ bằng `run('prepare', '--dataset', 'ffpp')`; chỉ chạy preprocess sau khi tất cả dataset đã chuẩn bị thành công.

Từ repository root, với đúng môi trường/dependencies:

```bash
python -m experiments doctor --config colab/experiment_config.yaml
python -m experiments prepare --config colab/experiment_config.yaml
python -m experiments preprocess --config colab/experiment_config.yaml
python -m experiments doctor --calibrate --config colab/experiment_config.yaml
python -m experiments train --config colab/experiment_config.yaml
python -m experiments evaluate --config colab/experiment_config.yaml
python -m experiments summarize --config colab/experiment_config.yaml
```

Có thể thêm `--dataset ffpp` cho prepare/preprocess, hoặc `--variant favit_cnn --seed 42` cho train/evaluate. Chuẩn bị đủ cache trước khi train: thêm/thay dataset sau đó sẽ đổi cache hash và không thể gắn vào run cũ.

```bash
python -m pip install pytest  # Chỉ cần cho kiểm thử phát triển, không phải notebook.
python -m pytest tests/test_colab_experiments.py -q
python -m experiments smoke --output experiment-output/my-smoke-test
```

Smoke tạo video màu, detector giả và encoder nhỏ: **không phải FA-ViT train thật, không dùng số đó cho paper**. Mỗi lần smoke chọn thư mục output mới. Xem `VALIDATION.md` để phân biệt kiểm tra local và phần cần xác minh trên GPU Colab.

Gói source có thể tạo lại bằng `python colab/make_notebooks.py` rồi `python colab/package_bundle.py`. Hai notebook là JSON nbformat 4, code cells đã được kiểm tra cú pháp. Pipeline không tự mount tài khoản Drive, gửi dữ liệu, push GitHub hoặc nộp paper; những bước kết nối được bạn thực hiện trong Colab.
