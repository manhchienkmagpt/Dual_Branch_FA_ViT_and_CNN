"""Priority-ordered supplemental experiments and verifiable JSON evidence.

Uses the existing prepared cache and frozen training settings. It never downloads
datasets, changes the notebook's two-run selection, or edits the manuscript.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from experiments.common import (DATASETS, atomic_json, clean_json, code_hash,
                                fingerprint, load_config, public_config, read_json, sha256)


def now():
    return datetime.now(timezone.utc).isoformat()


def plan(phase="all"):
    jobs = [("favit_matched", 42, "ablations", "Control for LayerNorm/Dropout head"),
            ("cnn_only", 42, "ablations", "Independent CNN and 50:50 ensemble"),
            ("favit_capacity", 42, "ablations", "Parameter-matched MLP control"),
            ("favit_cnn", 42, "ablations", "Compatible dual reference; reuse verified completed run")]
    for seed in (123, 2026):
        jobs.extend([("favit_matched", seed, "multiseed", "Repeat matched-head reference"),
                     ("favit_cnn", seed, "multiseed", "Repeat dual under the same seed")])
    return [{"id": f"{variant}-seed-{seed}", "variant": variant, "seed": seed,
             "phase": group, "purpose": purpose, "priority": i + 1}
            for i, (variant, seed, group, purpose) in enumerate(jobs)
            if phase == "all" or phase == group]


def optional_json(path, default=None):
    return read_json(path) if path.is_file() else default


def error_text(error):
    # Errors can contain values from environment variables; JSON must not leak them.
    import os
    text = str(error)
    for key, value in os.environ.items():
        if len(value) >= 6 and any(word in key.upper() for word in ("TOKEN", "SECRET", "PASSWORD", "API_KEY")):
            text = text.replace(value, "[REDACTED]")
    return text


@contextmanager
def execution_lock(config):
    """Release automatically on process death; prevent two runners in one runtime."""
    local = Path(config["local_root"])
    local.mkdir(parents=True, exist_ok=True)
    with (local / "supplemental-runner.lock").open("a+b") as handle:
        import os
        if os.name == "nt":
            import msvcrt
            handle.seek(0, 2)
            if handle.tell() == 0:
                handle.write(b"1")
                handle.flush()
            handle.seek(0)
            try:
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError as error:
                raise RuntimeError("Another supplemental runner holds this runtime lock") from error
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError as error:
                raise RuntimeError("Another supplemental runner holds this runtime lock") from error
            try:
                yield
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)


class Evidence:
    def __init__(self, config, phase="all"):
        self.config = config
        self.drive = Path(config["drive_root"])
        self.root = self.drive / "supplemental"
        self.root.mkdir(parents=True, exist_ok=True)
        self.jobs = plan(phase)

    def save(self, name, value):
        value = clean_json(value)
        for attempt in range(5):
            try:
                atomic_json(self.root / name, value)
                return
            except PermissionError:
                # A scanner/read handle can briefly block atomic replacement on
                # Windows. Persistent permission errors still stop the runner.
                if attempt == 4:
                    raise
                time.sleep(.05 * 2**attempt)

    def reference(self, path):
        return {"path": path.relative_to(self.drive).as_posix(), "sha256": sha256(path),
                "bytes": path.stat().st_size}

    def export_run(self, job):
        """Recompute metrics from hashed frame predictions, never printed paper values."""
        folder = self.drive / "runs" / job["variant"] / f"seed-{job['seed']}"
        state = optional_json(folder / "state.json", {})
        result = {**job, "updated_at": now(), "smoke": bool(self.config.get("smoke")),
                  "status": state.get("status", "not_started"), "state": state,
                  "metrics": [], "history": optional_json(folder / "history.json", []),
                  "artifacts": {}, "descriptive_results_available": False}
        for name in ("config.json", "model-info.json", "environment.json", "history.json", "state.json"):
            path = folder / name
            if path.is_file():
                result["artifacts"][name] = self.reference(path)
        result["config"] = optional_json(folder / "config.json")
        result["model_info"] = optional_json(folder / "model-info.json")
        predictions = None
        try:
            if state.get("status") == "completed":
                best = folder / "best.pt"
                if not best.is_file() or sha256(best) != state.get("best_sha256"):
                    raise ValueError("Missing or corrupt best checkpoint")
                result["artifacts"]["best.pt"] = self.reference(best)
                evaluation = folder / "evaluation"
                status = optional_json(evaluation / "status.json")
                result["status"] = "evaluation_pending"
                if status:
                    from experiments.cache import cache_info, dataset_hash
                    from experiments.evaluation import checked_predictions, evaluation_tables, aggregate_videos
                    import pandas as pd
                    _, index = cache_info(self.config)
                    csv = evaluation / "frame-predictions.csv"
                    info = result["model_info"] or {}
                    if (status.get("best_sha256") != state["best_sha256"]
                            or status.get("dataset_hash") != dataset_hash(index)
                            or info.get("dataset_hash") != dataset_hash(index)
                            or not csv.is_file() or sha256(csv) != status.get("predictions_sha256")):
                        raise ValueError("Stale, incompatible or corrupt evaluation; rerun native evaluation")
                    if info.get("variant") != job["variant"] or info.get("seed") != job["seed"]:
                        raise ValueError("Model metadata does not identify the requested run")
                    from experiments.training import runtime_settings
                    runtime = runtime_settings(self.config)
                    expected = fingerprint({"training": self.config["training"], "seed": job["seed"],
                                            "variant": job["variant"], "dataset": dataset_hash(index),
                                            "runtime": {key: runtime[key] for key in ("precision", "microbatch_size")},
                                            "code": code_hash(), "smoke": bool(self.config.get("smoke"))})
                    if state.get("signature") != expected:
                        raise ValueError("Run protocol/code differs from the current configuration")
                    predictions = checked_predictions(pd.read_csv(csv))
                    result["metrics"] = evaluation_tables(predictions, self.config["evaluation"]["threshold"])
                    coverage = read_json(evaluation / "coverage.json")
                    result["coverage"] = coverage
                    result["status"] = "completed"
                    result["descriptive_results_available"] = not (coverage.get("zero_crop_video_ids")
                                                                    or coverage.get("datasets_absent"))
                    result["artifacts"]["frame-predictions.csv"] = self.reference(csv)
                    result["video_predictions"] = aggregate_videos(predictions).to_dict(orient="records")
                    result["video_predictions_median"] = aggregate_videos(predictions, "median").to_dict(orient="records")
        except Exception as error:
            predictions = None
            result.update(status="invalid", error=error_text(error), descriptive_results_available=False, metrics=[])
        self.save(f"runs/{job['id']}.json", result)
        return result, predictions

    def export(self, status="running", active=None):
        from experiments.evaluation import ensemble, evaluation_tables, aggregate_videos, paired, delong_paired, holm, paired_bootstrap
        import pandas as pd
        results, predictions = [], {}
        # Also inspect the other phases for statistics when invoked with --phase.
        for job in plan():
            result, frame = self.export_run(job)
            results.append(result)
            if frame is not None and result["descriptive_results_available"]:
                predictions[job["variant"], job["seed"]] = frame
        ensemble_metrics = []
        for seed in (42, 123, 2026):
            if ("favit_matched", seed) in predictions and ("cnn_only", seed) in predictions:
                try:
                    frame = ensemble(predictions["favit_matched", seed], predictions["cnn_only", seed])
                    predictions["score_ensemble_50_50", seed] = frame
                    metrics = evaluation_tables(frame, self.config["evaluation"]["threshold"])
                    ensemble_metrics.extend({"variant": "score_ensemble_50_50", "seed": seed, **row} for row in metrics)
                    self.save(f"ensembles/seed-{seed}.json", {"status": "measured", "seed": seed,
                              "weights": [0.5, 0.5], "metrics": metrics,
                              "video_predictions": aggregate_videos(frame).to_dict(orient="records")})
                except ValueError as error:
                    self.save(f"ensembles/seed-{seed}.json", {"status": "incompatible", "error": error_text(error)})
            else:
                self.save(f"ensembles/seed-{seed}.json", {"status": "missing_paired_run", "seed": seed})
        references = ("favit_matched", "cnn_only", "favit_capacity", "score_ensemble_50_50")
        comparisons, bootstraps = [], []
        for dataset in DATASETS:
            for seed in (42, 123, 2026):
                family = []
                for reference in references:
                    a, b = predictions.get(("favit_cnn", seed)), predictions.get((reference, seed))
                    row = {"dataset": dataset, "seed": seed, "reference": reference, "status": "missing_paired_run",
                           "delta_auc": None, "p_nominal": None, "family_size": len(references)}
                    if a is not None and b is not None:
                        try:
                            # Require identical crop membership as well as video membership.
                            paired(a, b, "crop_path")
                            left, right = paired(aggregate_videos(a[a.dataset == dataset]),
                                                 aggregate_videos(b[b.dataset == dataset]), "video_id")
                            row.update(delong_paired(left.label, left.probability, right.probability), status="measured")
                        except ValueError as error:
                            row.update(status="incompatible", error=error_text(error))
                    family.append(row)
                for row, corrected in zip(family, holm([r["p_nominal"] for r in family])):
                    comparisons.append({**row, "p_holm": corrected,
                                        "interpretation": "exploratory; DeLong assumes independent videos"})
            for reference in references:
                pairs, seeds = [], []
                for seed in (42, 123, 2026):
                    a, b = predictions.get(("favit_cnn", seed)), predictions.get((reference, seed))
                    if a is not None and b is not None:
                        try:
                            paired(a, b, "crop_path")
                            pair = paired(aggregate_videos(a[a.dataset == dataset]),
                                          aggregate_videos(b[b.dataset == dataset]), "video_id")
                            # Across-seed membership must also match exactly.
                            if pairs:
                                paired(pairs[0][0], pair[0], "video_id")
                            pairs.append(pair)
                            seeds.append(seed)
                        except ValueError:
                            continue  # Incompatibility is explicitly recorded in comparisons above.
                measured = paired_bootstrap(pairs, self.config["evaluation"].get("bootstrap_reps", 2000),
                                            self.config["evaluation"].get("bootstrap_seed", 2026))
                bootstraps.append({"dataset": dataset, "reference": reference, "seeds": seeds,
                                   "paired_seeds": len(seeds),
                                   "training_seed_variability_observed": len(seeds) > 1, **measured})
        self.save("comparisons.json", {"primary": "dual minus matched-head, Celeb-DF video AUC",
                  "holm_family": list(references), "holm_scope": "four references per dataset and seed; cross-dataset/seed tests remain exploratory",
                  "comparisons": comparisons, "paired_bootstrap": bootstraps})
        rows = [{"variant": r["variant"], "seed": r["seed"], **metric}
                for r in results if r["status"] == "completed" for metric in r["metrics"]] + ensemble_metrics
        summary = []
        if rows:
            table = pd.DataFrame(rows)
            for keys, group in table.groupby(["variant", "dataset", "level", "method"]):
                entry = dict(zip(("variant", "dataset", "level", "method"), keys))
                entry.update(seeds=sorted(group.seed.unique().tolist()), seed_count=int(group.seed.nunique()))
                for metric in ("auc", "accuracy", "f1", "precision", "recall"):
                    entry[metric] = {"mean": float(group[metric].mean()),
                                     "sample_std": float(group[metric].std()) if len(group) > 1 else None}
                summary.append(entry)
        selected = [r for r in results if r["id"] in {j["id"] for j in self.jobs}]
        complete = all(r["status"] == "completed" and r["descriptive_results_available"] for r in selected)
        progress = {"updated_at": now(), "status": status, "active_run": active,
                    "selected_jobs": self.jobs, "completed": [r["id"] for r in selected if r["status"] == "completed"],
                    "pending": [{"id": r["id"], "status": r["status"]} for r in selected
                                if r["status"] != "completed" or not r["descriptive_results_available"]],
                    "complete": complete, "smoke": bool(self.config.get("smoke"))}
        self.save("progress.json", progress)
        bundle = {"schema_version": 1, "updated_at": now(), "progress": progress,
                  "protocol": public_config(self.config), "code_hash": code_hash(),
                  "runner_sha256": sha256(Path(__file__)),
                  "run_results": results, "metrics_per_seed": rows, "metrics_across_seeds": summary,
                  "statistics": "comparisons.json", "data_audit": "data-audit.json",
                  "statistical_results": {"comparisons": comparisons, "paired_bootstrap": bootstraps},
                  "data_audit_result": optional_json(self.root / "data-audit.json"),
                  "scope_limits": ["No automatic acceptance decision or manuscript edits",
                                   "Historical table values are never imported as new measurements",
                                   "Capacity/CNN controls have one seed; full seed uncertainty is not estimated for them",
                                   "Source-group validity depends on manifest metadata; identity separation is not established"]}
        self.save("paper-results.json", bundle)
        return progress


def data_audit(config, coverage, index):
    from experiments.cache import dataset_hash
    from experiments.data import audit_manifest
    audit_manifest(coverage)
    group_splits = {}
    for row in coverage:
        if int(row.get("grouping_verified", 0)):
            group_splits.setdefault((row["dataset"], row["group_id"]), set()).add(row["split"])
    cross = [list(key) for key, splits in group_splits.items() if len(splits) > 1]
    if cross:
        raise ValueError("Verified source groups cross split boundaries")
    drive = Path(config["drive_root"])
    files = list((drive / "manifests").glob("videos-*.csv"))
    files += list((drive / "manifests" / "official-splits").glob("*.json"))
    provenance = drive / "manifests" / "ffpp-split-provenance.json"
    if provenance.is_file():
        files.append(provenance)
    return {"status": "checked", "dataset_hash": dataset_hash(index),
            "manifest_artifacts": [{"path": p.relative_to(drive).as_posix(), "sha256": sha256(p)} for p in files],
            "videos_by_split": dict(Counter(f"{r['dataset']}/{r['split']}" for r in coverage)),
            "crops_by_split": {key: sum(int(r["saved_frames"]) for r in coverage
                                      if f"{r['dataset']}/{r['split']}" == key)
                                      for key in {f"{r['dataset']}/{r['split']}" for r in coverage}},
            "zero_crop_video_ids": [r["video_id"] for r in coverage if not int(r["saved_frames"])],
            "unverified_grouping_videos": dict(Counter(r["dataset"] for r in coverage
                                                       if not int(r.get("grouping_verified", 0)))),
            "source_split_overlap_found": False, "identity_disjointness": "not_established",
            "historical_paper_split_equivalence": "requires_original_run_manifests"}


def run(config, phase="all", max_hours=24, export_only=False, model_factory=None, clock=time.monotonic):
    from experiments.cache import cache_info, materialize
    from experiments.training import calibrate, train_one
    from experiments.evaluation import evaluate_one
    import torch
    evidence = Evidence(config, phase)
    evidence.save("plan.json", {"jobs": evidence.jobs, "max_hours": max_hours,
                  "budget_policy": "soft limit checked at epoch boundaries; an active epoch/evaluation may overrun",
                  "unchanged_protocol": public_config(config), "historical_reuse": "native compatible checkpoints only"})
    if export_only:
        return evidence.export("exported")
    started = clock()
    seconds = max_hours * 3600 if max_hours else math.inf
    evidence.save("data-audit.json", {"status": "pending", "updated_at": now()})
    try:
        _, index = cache_info(config)
        missing = [d for d in DATASETS if not index.get("datasets", {}).get(d, {}).get("complete")]
        if missing:
            raise ValueError("Complete caches required: " + ", ".join(missing) +
                             ". Finish notebook 01; this script does not download or substitute datasets.")
        for key in ("image_size", "train_frames", "eval_frames", "face_margin", "jpeg_quality", "detector", "shard_videos"):
            if index["settings"].get(key) != config["data"][key]:
                raise ValueError("Frozen preprocessing settings differ: " + key)
        frames, coverage, index = materialize(config)
        evidence.save("data-audit.json", data_audit(config, coverage, index))
        evidence.export("running")
        if not (Path(config["drive_root"]) / "runtime.json").exists() and not config.get("smoke"):
            calibrate(config)
        durations = []
        for job in evidence.jobs:
            folder = Path(config["drive_root"]) / "runs" / job["variant"] / f"seed-{job['seed']}"
            if folder.is_dir() and not (folder / "state.json").is_file() and any(folder.iterdir()):
                raise ValueError("Run folder contains unverified artifacts without native state.json: " + str(folder))
            while True:
                state = optional_json(folder / "state.json", {})
                if state.get("status") == "completed":
                    # Native skip validates the exact protocol and checkpoint hash.
                    train_one(config, job["variant"], job["seed"], frames, index, epochs_override=1)
                    break
                remaining = seconds - (clock() - started)
                if remaining <= 0 or (durations and remaining < max(durations[-2:])):
                    evidence.save("current-task.json", {**job, "status": "budget_exhausted", "at": now()})
                    return evidence.export("budget_exhausted", job["id"])
                epoch_started = clock()
                evidence.save("current-task.json", {**job, "status": "training", "started_at": now()})
                factory = (lambda: model_factory(job["variant"], job["seed"])) if model_factory else None
                # Native resume is exercised one epoch at a time to preserve the protocol
                # and stop without relabeling a partially trained model as completed.
                train_one(config, job["variant"], job["seed"], frames, index,
                          model_factory=factory, epochs_override=1)
                elapsed = clock() - epoch_started
                durations.append(elapsed)
                timing = optional_json(evidence.root / "timing.json", {"epochs": [], "evaluations": []})
                timing["epochs"].append({"run": job["id"], "epoch": optional_json(folder / "state.json", {}).get("epoch"),
                                         "seconds": elapsed, "finished_at": now()})
                evidence.save("timing.json", timing)
                evidence.export_run(job)
                progress = optional_json(evidence.root / "progress.json", {})
                progress.update(status="running", active_run=job["id"], updated_at=now(),
                                last_checkpoint={"run": job["id"], "epoch": timing["epochs"][-1]["epoch"]})
                evidence.save("progress.json", progress)
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
            if clock() - started >= seconds:
                evidence.save("current-task.json", {**job, "status": "budget_exhausted", "at": now()})
                return evidence.export("budget_exhausted", job["id"])
            evidence.save("current-task.json", {**job, "status": "evaluating", "started_at": now()})
            evaluation_started = clock()
            previous_evaluation = optional_json(folder / "evaluation" / "status.json")
            factory = (lambda: model_factory(job["variant"], job["seed"])) if model_factory else None
            evaluate_one(config, job["variant"], job["seed"], frames, coverage, index, model_factory=factory)
            timing = optional_json(evidence.root / "timing.json", {"epochs": [], "evaluations": []})
            timing["evaluations"].append({"run": job["id"], "seconds": clock() - evaluation_started,
                                           "finished_at": now()})
            evidence.save("timing.json", timing)
            if previous_evaluation != optional_json(folder / "evaluation" / "status.json"):
                evidence.export("running", job["id"])
            else:
                evidence.export_run(job)
            print(f"Saved JSON evidence: {job['id']}", flush=True)
        evidence.save("current-task.json", {"status": "completed", "finished_at": now()})
        return evidence.export("completed")
    except BaseException as error:
        status = "interrupted" if isinstance(error, KeyboardInterrupt) else "blocked"
        failure = {"status": status, "error": error_text(error), "at": now(), "elapsed_seconds": clock() - started}
        evidence.save("failure.json", failure)
        evidence.save("current-task.json", {**optional_json(evidence.root / "current-task.json", {}), **failure})
        try:
            evidence.export(status)
        except Exception as export_error:
            evidence.save("export-failure.json", {"error": error_text(export_error), "at": now()})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(ROOT / "colab" / "experiment_config.yaml"))
    parser.add_argument("--phase", choices=("all", "ablations", "multiseed"), default="all")
    parser.add_argument("--max-hours", type=float, default=24, help="Soft budget; 0 means no time limit")
    parser.add_argument("--plan", action="store_true", help="Print the queue without loading GPU libraries or running jobs")
    parser.add_argument("--export-only", action="store_true", help="Read existing results and regenerate JSON without training")
    parser.add_argument("--inspect", action="store_true", help="Validate local PC crop inputs and write the manifest without training")
    args = parser.parse_args()
    if args.max_hours < 0 or not math.isfinite(args.max_hours):
        parser.error("--max-hours must be finite and nonnegative")
    config = load_config(args.config)
    if args.inspect and config.get("input_mode") != "pc_crops":
        parser.error("--inspect requires input_mode: pc_crops")
    if args.plan:
        print(json.dumps({"jobs": plan(args.phase), "config": public_config(config)}, indent=2))
        return
    if config.get("input_mode") == "pc_crops":
        from colab.pc_crops import validate_locations
        validate_locations(config)
    with execution_lock(config):
        if config.get("input_mode") == "pc_crops":
            from colab.pc_crops import run_pc
            progress = run_pc(config, args.phase, args.max_hours, args.export_only, inspect_only=args.inspect)
        else:
            progress = run(config, args.phase, args.max_hours, args.export_only)
    print(json.dumps(progress, indent=2))
    if not args.export_only and not args.inspect and not progress["complete"]:
        raise SystemExit(2)  # Partial/budget-limited output is not full success.


if __name__ == "__main__":
    main()
