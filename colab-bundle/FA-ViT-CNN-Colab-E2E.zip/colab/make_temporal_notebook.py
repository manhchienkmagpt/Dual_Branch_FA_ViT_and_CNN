"""Generate the single CPU-first, phase-gated temporal Colab notebook."""
import ast
import json
from pathlib import Path

from make_notebooks import MOUNT, md, code


def main():
    cells = [
        md('''# FA-ViT-CNN thời gian — 10-fold trên Colab
**Bắt đầu bằng runtime CPU.** Chọn `RUN_STAGE=download` để tải video và lưu Drive.
Khi tải xong, đổi runtime sang **L4**, chọn `preprocess` để chạy MTCNN, rồi `train`.
MTCNN cũng chạy được trên CPU nếu chọn `PREPROCESS_DEVICE=cpu`.

Chạy lại từ đầu notebook sau khi đổi runtime; chỉ giai đoạn được chọn thực thi.
Video gốc, crop shards, manifests, checkpoint và báo cáo đều nằm trên Drive.
50 lượt = 5 cấu hình × 10 fold; tối đa 30 epoch/lượt, patience 5.
Các cell Celeb-DF nằm cuối và chỉ dùng ZIP bạn upload. Không cần Celeb-DF để chạy FF++/UADFV.
Upload gói code `FA-ViT-CNN-Colab-E2E.zip` lên MyDrive trước khi chạy.'''),
        code(MOUNT),
        md('''## 1. Chọn giai đoạn và cấu hình
`download` không cài Torch/MTCNN, không yêu cầu GPU. `preprocess` dùng CPU/GPU tùy chọn.
`train` yêu cầu GPU; `celebdf` nhận ZIP ở các cell cuối rồi đánh giá bằng checkpoint đã hoàn tất.
Quy trình khoa học được đóng băng khi bắt đầu; đổi clip length hoặc kiến trúc cần Drive root mới.
Đặt `FOLD=0` cho cả 10 fold; `VARIANT=all` cho cả năm cấu hình.'''),
        code(r'''
import subprocess, os
RUN_STAGE = 'download' #@param ['download', 'preprocess', 'train', 'celebdf']
PREPROCESS_DEVICE = 'auto' #@param ['auto', 'cpu', 'cuda']
ACCEPTED_FFPP_TERMS = False #@param {type:'boolean'}
USE_KAGGLE_SECRET = False #@param {type:'boolean'}
FOLD = 0 #@param {type:'integer'}
VARIANT = 'all' #@param ['all', 'favit_clip', 'favit_cnn_clip', 'favit_cnn_temporal', 'favit_cnn_no_temporal', 'favit_cnn_no_patch']
assert 0 <= FOLD <= 10
ACQ_PYTHON = bootstrap['bootstrap_env'](PROJECT, 'acquisition', device='cpu')
session = Path(DRIVE_ROOT)/'temporal-session.json'
session.parent.mkdir(parents=True, exist_ok=True)
if session.is_file():
    CONFIG = json.loads(session.read_text())
else:
    command = [ACQ_PYTHON, '-c', 'import yaml,json,sys; print(json.dumps(yaml.safe_load(open(sys.argv[1]))))',
               str(PROJECT/'colab'/'experiment_config.temporal.yaml')]
    CONFIG = json.loads(subprocess.check_output(command, text=True))
CONFIG['drive_root'] = DRIVE_ROOT
CONFIG['local_root'] = '/content/favit-temporal-work'
CONFIG['data']['device'] = PREPROCESS_DEVICE
CONFIG['sources']['ffpp']['accepted_terms'] = ACCEPTED_FFPP_TERMS
CONFIG_FILE = Path('/content/favit-temporal-session.json')
def save_session():
    CONFIG_FILE.write_text(json.dumps(CONFIG, indent=2))
    stage_config = session.with_suffix('.tmp')
    stage_config.write_text(json.dumps(CONFIG, indent=2))
    stage_config.replace(session)
save_session()
if USE_KAGGLE_SECRET:
    from google.colab import userdata
    os.environ['KAGGLE_API_TOKEN'] = userdata.get('KAGGLE_API_TOKEN')
def run(python, stage, *arguments):
    return bootstrap['run_stage'](python, PROJECT, CONFIG_FILE, stage, *arguments,
                                  drive_root=DRIVE_ROOT, module='experiments.temporal')
run(ACQ_PYTHON, 'doctor')
'''),
        md('''## 2. Tải video — chạy bằng CPU
FF++ dùng script chính thức, c23 và năm kiểu giả. UADFV giữ nguồn Kaggle đã cấu hình.
Cả video tải về và tiến độ tải được lưu trên Drive. Hãy xác nhận điều khoản FF++ bằng checkbox phía trên.
Không có lệnh tải Celeb-DF tự động. Khi hoàn tất, có thể ngắt CPU runtime rồi đổi sang L4.'''),
        code("if RUN_STAGE == 'download':\n    run(ACQ_PYTHON, 'prepare')\nelse:\n    print('Bỏ qua tải video; dùng dữ liệu đã lưu trên Drive.')"),
        md('''## 3. MTCNN và clip frame — CPU hoặc GPU
GPU giúp tăng tốc MTCNN; chọn `PREPROCESS_DEVICE=auto` để dùng GPU nếu có.
Mỗi video lấy tối đa 8 đoạn, mỗi đoạn 8 frame liên tiếp; tracking cùng khuôn mặt, căn chỉnh bằng 5 landmarks.
Frame được đóng shard và lưu Drive, dùng chung cho mọi fold. Shard hợp lệ không bị xử lý lại.
Thống kê dung lượng mẫu xuất hiện sau mỗi shard; kiểm tra quota Drive trước khi chạy toàn bộ.'''),
        code(r'''
if RUN_STAGE == 'preprocess':
    # Optional explicit exclusions are saved on Drive and reused across runtimes.
    EXCLUDE_FFPP_VIDEO = '' #@param {type:'string'}
    EXCLUSION_REASON = 'Author approved exclusion after inspecting preprocessing coverage' #@param {type:'string'}
    if EXCLUDE_FFPP_VIDEO.strip():
        run(ACQ_PYTHON, 'exclude-video', '--dataset', 'ffpp',
            '--video-id', EXCLUDE_FFPP_VIDEO.strip(), '--reason', EXCLUSION_REASON)
    PREP_PYTHON = bootstrap['bootstrap_env'](PROJECT, 'preprocess', device=PREPROCESS_DEVICE)
    run(PREP_PYTHON, 'preprocess', '--device', PREPROCESS_DEVICE)
else:
    print('Bỏ qua MTCNN; chọn preprocess khi đã sẵn sàng.')
'''),
        md('''## 4. Xem lịch fold và tình trạng cache
p1–p10 được chia theo cặp video nguồn. Lượt 1: train p1–p8, val p9, test p10.
Lượt 10: train p10,p1–p7, val p8, test p9. Không chia các frame của một nhóm sang nhiều tập.
Đổi runtime không làm mất dữ liệu trên Drive; chỉ cần khởi tạo lại notebook.'''),
        code(r'''
folds_path = Path(DRIVE_ROOT)/'temporal-manifests'/'folds.json'
if folds_path.is_file():
    print(json.dumps(json.loads(folds_path.read_text())['schedule'], indent=2))
for dataset in ['ffpp', 'uadfv']:
    base = Path(DRIVE_ROOT)/'temporal-cache'/dataset
    pointer = base/'active.json'
    if pointer.is_file():
        index = json.loads((base/json.loads(pointer.read_text())['index']).read_text())
        print(dataset, 'complete:', index['complete'], 'clips:', sum(s['clips'] for s in index['shards']))
        if index.get('excluded_videos'):
            print('Video loại trừ:', index['excluded_videos'])
            print('Video sử dụng:', index['included_videos'], '/', index['source_videos'])
    else:
        print(dataset, ': chưa có cache preprocess trên Drive')
'''),
        md('''## 5. Training/resume — bật L4 GPU
Năm cấu hình: FA-ViT baseline hiện có, CNN 2D, bản thời gian đầy đủ, bỏ thời gian và bỏ fusion patch.
Mỗi lượt tối đa 30 epoch, patience 5; checkpoint chọn theo video AUC của val FF++.
Calibrate chốt microbatch chung và BF16. Mọi fold khởi tạo mới; không chuyển model đã train giữa fold.
Mỗi epoch lưu best/last và trạng thái lên Drive. Chạy lại để resume; lượt hoàn tất được bỏ qua.
Thời gian 50 lượt có thể vượt nhiều phiên Colab; không có cam kết hoàn thành trong một ngày.'''),
        code(r'''
if RUN_STAGE == 'train':
    TRAIN_PYTHON = bootstrap['bootstrap_env'](PROJECT, 'training', device='cuda')
    run(TRAIN_PYTHON, 'doctor', '--calibrate')
    arguments = ['--variant', VARIANT]
    if FOLD:
        arguments += ['--fold', str(FOLD)]
    run(TRAIN_PYTHON, 'run', *arguments)
else:
    print('Bỏ qua training; CPU runtime vẫn tải/kiểm tra dữ liệu bình thường.')
'''),
        md('''## 6. Kết quả FF++ và UADFV
Mỗi video FF++ chỉ có một dự đoán out-of-fold test. Báo cáo mean ± SD qua fold không phải qua seed.
UADFV dùng checkpoint FF++ đã chọn, không chọn fold tốt nhất theo tập ngoài.'''),
        code(r'''
from IPython.display import display, Markdown
report = Path(DRIVE_ROOT)/'temporal-summaries'/'REPORT-VI.md'
if report.is_file():
    display(Markdown(report.read_text()))
else:
    print('Chưa có kết quả; training và đánh giá sẽ tạo báo cáo trên Drive.')
'''),
        md('''## 7. Celeb-DF — upload muộn, xử lý sau cùng
Chọn `RUN_STAGE=celebdf` khi ZIP đã có. Khuyến nghị upload ZIP lớn trực tiếp lên Drive rồi nhập đường dẫn dưới.
Nếu dùng nút upload, file được sao lưu vào Drive trước khi giải nén. ZIP cần có `List_of_testing_videos.txt` và video tương ứng; hỗ trợ thư mục bọc ngoài.
Nhận/giải nén ZIP chạy trên CPU; MTCNN dùng CPU/GPU theo lựa chọn. Inference production cần GPU.
Nếu chưa có GPU, vẫn có thể nhận ZIP và tạo clip; chạy lại giai đoạn này với L4 để đánh giá.
Không cần chạy lại FF++ khi bổ sung Celeb-DF.'''),
        code(r'''
CELEBDF_ZIP = '/content/drive/MyDrive/Celeb-DF-v2.zip' #@param {type:'string'}
UPLOAD_CELEBDF = False #@param {type:'boolean'}
EVALUATE_CELEBDF = True #@param {type:'boolean'}
if RUN_STAGE == 'celebdf':
    if UPLOAD_CELEBDF:
        from google.colab import files
        import shutil
        uploaded = files.upload()
        assert len(uploaded) == 1, 'Chọn đúng một ZIP.'
        name = next(iter(uploaded))
        assert name.lower().endswith('.zip')
        target = Path(DRIVE_ROOT)/'uploads'/Path(name).name
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name+'.uploading')
        shutil.copyfile(name, temporary)
        digest = hashlib.sha256()
        with temporary.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024*1024), b''):
                digest.update(chunk)
        assert digest.hexdigest() == hashlib.sha256(uploaded[name]).hexdigest()
        temporary.replace(target)
        CELEBDF_ZIP = str(target)
        del uploaded
    if not Path(CELEBDF_ZIP).is_file():
        print('Chưa có ZIP Celeb-DF. Upload sau; dữ liệu và kết quả FF++ được giữ nguyên.')
    else:
        CONFIG['sources']['celebdf']['archive'] = CELEBDF_ZIP
        save_session()
        run(ACQ_PYTHON, 'prepare', '--dataset', 'celebdf')
        PREP_PYTHON = bootstrap['bootstrap_env'](PROJECT, 'preprocess', device=PREPROCESS_DEVICE)
        run(PREP_PYTHON, 'preprocess', '--dataset', 'celebdf', '--device', PREPROCESS_DEVICE)
        if EVALUATE_CELEBDF:
            TRAIN_PYTHON = bootstrap['bootstrap_env'](PROJECT, 'training', device='cuda')
            arguments = ['--dataset', 'celebdf', '--variant', VARIANT]
            if FOLD:
                arguments += ['--fold', str(FOLD)]
            run(TRAIN_PYTHON, 'evaluate', *arguments)
            run(TRAIN_PYTHON, 'summarize')
else:
    print('Celeb-DF dành cho giai đoạn cuối; không tự tải hoặc xử lý ở giai đoạn khác.')
'''),
    ]
    for index, cell in enumerate(cells):
        cell["id"] = f"temporal-{index:03d}"
        if cell["cell_type"] == "code":
            ast.parse(cell["source"])
    notebook = {"nbformat": 4, "nbformat_minor": 5,
                "metadata": {"colab": {"name": "FA_ViT_CNN_10Fold.ipynb"},
                             "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                             "language_info": {"name": "python"}}, "cells": cells}
    path = Path(__file__).with_name("FA_ViT_CNN_10Fold.ipynb")
    path.write_text(json.dumps(notebook, ensure_ascii=False, indent=1), encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
