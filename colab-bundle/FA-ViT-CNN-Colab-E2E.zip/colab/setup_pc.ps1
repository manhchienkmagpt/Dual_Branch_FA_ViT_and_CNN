param([string]$PythonVersion = '3.11')
$ErrorActionPreference = 'Stop'
$RepoRoot = Split-Path -Parent $PSScriptRoot
Push-Location -LiteralPath $RepoRoot
try {
    & py "-$PythonVersion" -m venv .venv-pc
    if ($LASTEXITCODE -ne 0) { throw 'Install Python 3.11 x64 and the py launcher first.' }
    $PcPython = Join-Path $RepoRoot '.venv-pc/Scripts/python.exe'
    & $PcPython -m pip install --upgrade pip
    if ($LASTEXITCODE -ne 0) { throw 'pip upgrade failed.' }
    # Official Windows CUDA 12.8 pair with Blackwell support. Do not use the
    # Colab CUDA 12.1 bootstrap or facenet-pytorch for already-cropped PC images.
    & $PcPython -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cu128
    if ($LASTEXITCODE -ne 0) { throw 'PyTorch CUDA 12.8 installation failed.' }
    & $PcPython -m pip install -r colab/requirements-training.txt
    if ($LASTEXITCODE -ne 0) { throw 'Training dependencies failed to install.' }
    & $PcPython -m pip check
    if ($LASTEXITCODE -ne 0) { throw 'Dependency conflicts detected.' }
    $env:CUBLAS_WORKSPACE_CONFIG = ':4096:8'
    $GpuCheck = @'
import torch
import huggingface_hub
import safetensors.torch
from timm.models._hub import has_hf_hub
has_hf_hub(necessary=True)
assert torch.cuda.is_available(), 'CUDA unavailable: check the NVIDIA driver and PyTorch CUDA wheel'
print('PyTorch:', torch.__version__, 'CUDA:', torch.version.cuda)
print('GPU:', torch.cuda.get_device_name(0), 'capability:', torch.cuda.get_device_capability(0))
x = torch.randn(2, 3, 32, 32, device='cuda', requires_grad=True)
m = torch.nn.Conv2d(3, 8, 3).cuda()
m(x).square().mean().backward()
a = torch.randn(16, 16, device='cuda', requires_grad=True)
(a @ a).sum().backward()
torch.cuda.synchronize()
print('CUDA convolution and matrix multiplication forward/backward passed')
'@
    & $PcPython -c $GpuCheck
    if ($LASTEXITCODE -ne 0) { throw 'CUDA execution check failed; training was not started.' }
    Write-Host 'Ready. Inspect crops using .venv-pc/Scripts/python.exe colab/run_supplemental_suite.py --config colab/experiment_config.pc.yaml --inspect'
} finally {
    Pop-Location
}
