# Tự động chạy Colab với Antigravity và Codex

Bộ điều phối local chỉ chạy hai đối chứng `favit_matched` và `cnn_only`, seed 42 trên L4, đánh giá ba dataset và tổng hợp. Giữ nguyên dữ liệu và lịch train; không chạy lại linear/dual/capacity. Antigravity thao tác browser; Codex CLI nhận log để sửa code và kiểm thử. Không cần giữ phiên chat Codex này mở sau khi bộ điều phối chạy, nhưng máy local phải bật, có mạng và Chrome còn hoạt động.

```mermaid
flowchart LR
    A[Điều phối local] --> B[Antigravity: upload và chọn L4]
    B --> C[Colab: chuẩn bị dữ liệu / train / evaluate]
    C --> D[Drive: trạng thái, log, checkpoint]
    D --> A
    A -->|Có lỗi code| E[Codex: sửa và kiểm thử]
    E -->|Kiểm thử đạt| B
```

## Thiết lập một lần

Máy cần Python với `PyYAML` và `pytest`, CLI `codex` đã đăng nhập, `agy` đã đăng nhập, Node/npx và Chrome 144 trở lên. Cấu hình Chrome DevTools MCP 1.13.0 cho workspace ở `.agents/mcp_config.json`; file này chứa đường dẫn máy cục bộ và không được theo dõi trong Git, nên cần tự thiết lập khi clone sang máy khác. Quyền Antigravity cho lần chạy nằm trong `colab/autopilot-agy-settings.json`, không sửa quyền toàn tài khoản.

Trong **Chrome hiện có**, mở `chrome://inspect/#remote-debugging`, bật **Allow remote debugging for this browser instance**. Khi Chrome hiện xác nhận kết nối DevTools, chọn **Allow**. Đăng nhập tài khoản Google chứa hai notebook và gói ZIP đã giao. Các bước Google login/CAPTCHA/cấp quyền Drive cần thao tác trực tiếp; bộ điều phối sẽ ghi chính xác bước đang chờ.

Từ `D:\ICCIES\Dual_Branch_FA_ViT_and_CNN`:

```powershell
python colab/package_bundle.py
python colab/autopilot.py doctor
python colab/autopilot.py start
```

`doctor` kiểm tra kết nối thật qua Antigravity; mã thoát 2 nghĩa là còn bước thiết lập cần hoàn thành. `start` mở worker nền ẩn trên Windows, không mở thêm terminal. Không bấm **Run all**, tự đổi GPU hay chạy song song hai notebook khi worker đang hoạt động.

```powershell
python colab/autopilot.py status
python colab/autopilot.py resume
python colab/autopilot.py stop
```

`resume` tiếp tục cùng hàng đợi sau khi đã xử lý điều kiện chờ. Không đặt lại giới hạn sửa. `stop` ngăn tác vụ mới, yêu cầu worker Colab dừng và giữ checkpoint cuối epoch đã ghi; khi đang cài môi trường hoặc sửa code, việc dừng có thể phải chờ bước đó kết thúc. Không tắt Chrome/máy ngay nếu trạng thái còn `stopping`.

## Lưu trạng thái và giao tiếp

- Local: `experiment-output/automation/state.json`, `supervisor.log`, `doctor.json`, `agent-logs/`, `inbox/` và `repairs/`. Mỗi lần sửa lưu bản sao source trước khi thay đổi, log Codex, kết quả kiểm thử và danh sách file đổi. Đây là dữ liệu làm việc riêng, không đóng vào ZIP.
- Drive: `MyDrive/FA_ViT_CNN_Experiments/automation/latest.json`, `automation/tasks/<task_id>.json`, `automation/errors/<task_id>.json` và `logs/`. Checkpoint vẫn ở `runs/<variant>/seed-<seed>/`.
- Tác vụ có ID, stage, dataset/variant/seed và SHA256 ZIP. Antigravity trả JSON kèm bản ghi worker; trạng thái thành công cần đúng ID, SHA, GPU L4 và bằng chứng riêng cho stage. Kết thúc chỉ khi báo cáo xác nhận đủ hai lượt bổ sung thật, với coverage của cả ba dataset.
- API notebook: `AUTOPILOT['submit'](task)`, `AUTOPILOT['status']()`, `AUTOPILOT['stop']()`. Worker nạp từ `colab/autopilot_runtime.py`, tự thiết lập hai môi trường Python 3.11 riêng. Bộ điều phối chuyển cấu hình JSON vào cell điều khiển; không chạy toàn bộ notebook.

ZIP được thay theo cùng Drive ID, không tạo bản trùng. Sau upload, worker xác minh SHA trước khi chạy. Hai notebook giữ phần người dùng đã chỉnh; Antigravity chỉ dùng cell điều khiển riêng. Giá trị chấp nhận điều khoản FF++ được kế thừa từ checkbox bạn đã bật trong notebook; đổi URL script sẽ dừng để xác nhận lại.

## Chính sách lỗi và tiếp tục

Đầu tiên chuẩn bị riêng FF++ để lấy nguyên nhân lỗi hiện tại, rồi CelebDF/UADFV, preprocess, calibrate, baseline `favit_linear/42`, các lượt còn lại và tổng hợp. Cache hoàn chỉnh được dùng lại; run hoàn tất được kiểm tra trước khi bỏ qua.

Antigravity đọc tiến độ mỗi hai phút, worker ghi heartbeat mỗi phút. Heartbeat quá 10 phút hoặc browser mất kết nối không đủ để khẳng định GPU đã ngừng: hệ thống dừng chờ xác minh, không tạo runtime thứ hai. Khi giao diện Colab xác nhận backend đã bị xóa/kết thúc, hệ thống phục hồi trên L4; nếu raw/cache chưa hoàn tất thì chuẩn bị lại dữ liệu local đã mất, còn training tiếp tục từ cuối epoch. Giới hạn 3 lần phục hồi backend cho một tác vụ.

Khi không có L4, chờ và kiểm tra mỗi 30 phút, tối đa 24 giờ rồi báo `needs_attention`. Không tự đổi GPU, mua quota, tạo hoạt động giả để giữ Colab hoặc vượt giới hạn của dịch vụ. Lỗi truyền tin thử lại sau 1, 5 và 15 phút, kiểm tra job cũ trước khi gửi lại.

Lỗi code cho phép tối đa 3 bản sửa đã kiểm thử cho một tác vụ, kể cả nội dung lỗi thay đổi. Codex không được đổi protocol, dữ liệu/split, kiến trúc, metric, số epoch/seed hoặc xóa video lỗi để chạy qua. Bản sửa ảnh hưởng code khoa học/dependencies sau khi đã có checkpoint sẽ dừng để đánh giá tương thích; không nối checkpoint cũ vào một thí nghiệm mới.

Khi trạng thái `needs_attention`, xem `details` trong `state.json`. Trường hợp quyền truy cập, token Kaggle, quota, thay đổi protocol, thiếu bằng chứng GPU/SHA hoặc hết số lần sửa đều giữ nguyên dữ liệu và chờ. Token được che trong log; không đặt token vào cấu hình, prompt agent hoặc source ZIP.

## Kiểm thử và giới hạn xác minh

```powershell
python -m pytest tests -q -p no:cacheprovider --disable-warnings
```

Kiểm thử dùng lỗi giả lập để kiểm tra vòng sửa/upload/resume, giới hạn sửa, sai SHA/GPU, dừng tiến trình im lặng, che token, checksum shard, heartbeat cũ và phục hồi backend. Đây không phải kết quả GPU hay kết quả paper. Kết nối Chrome, quyền Google và việc Colab cấp L4 chỉ được xác nhận khi chạy `doctor` và tác vụ thật; không suy ra từ unit test.
