"""Build the source bundle; excludes credentials, Git metadata, bytecode and run data."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ALLOWED = {"experiments", "colab", "tests", "training_model", "preprocess_deepfake", "assets"}


def package():
    output = ROOT / "colab-bundle"
    output.mkdir(exist_ok=True)
    archive = output / "FA-ViT-CNN-Colab-E2E.zip"
    manifest = {}
    selected = []
    candidates = [ROOT / "README.md", ROOT / ".gitignore"]
    for directory in sorted(ALLOWED):
        candidates.extend((ROOT / directory).rglob("*"))
    for path in sorted(candidates):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if relative.parts[0] not in ALLOWED and relative.as_posix() not in ("README.md", ".gitignore"):
            continue
        if any(part in ("__pycache__", ".pytest_cache", ".ipynb_checkpoints") for part in relative.parts):
            continue
        if path.suffix.lower() not in (".py", ".ps1", ".ipynb", ".yaml", ".yml", ".txt", ".md", ".png", ".jpg", ".jpeg", ".svg", ".gitignore") and path.name not in (".gitignore", "autopilot-agy-settings.json"):
            continue
        # A session config or real manifest is never part of a source release.
        if "session" in path.name.lower() or path.name.startswith(".") and path.name != ".gitignore":
            continue
        selected.append((path, relative.as_posix()))
        manifest[relative.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as packed:
        for path, relative in selected:
            packed.write(path, relative)
        packed.writestr("BUNDLE-MANIFEST.json", json.dumps(manifest, indent=2))
    with zipfile.ZipFile(archive) as packed:
        assert packed.testzip() is None
        assert "colab/01_prepare_data.ipynb" in packed.namelist()
        assert "colab/02_run_experiments.ipynb" in packed.namelist()
        assert "colab/FA_ViT_CNN_10Fold.ipynb" in packed.namelist()
        assert "experiments/temporal/__main__.py" in packed.namelist()
        assert "colab/requirements-acquisition.txt" in packed.namelist()
        assert not any("__pycache__" in name or name.startswith("experiment-output/") for name in packed.namelist())
    checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
    (output / "SHA256SUMS.txt").write_text(f"{checksum}  {archive.name}\n", encoding="utf-8")
    print(json.dumps({"archive": str(archive), "files": len(selected) + 1,
                      "bytes": archive.stat().st_size, "sha256": checksum}, indent=2))


if __name__ == "__main__":
    package()
