# Validation record — 2026-11-14

## Author-requested quick input indexing

The supplied PC preset now disables full image opening/verification/SHA256 and rejection of identical FF++ train/test images. It still indexes paths, labels and video membership, with progress every 10,000 crops. Quick fingerprints use relative paths, sizes and mtimes; JSON reports unverified contents and a null duplicate count, and preserves the author's previously reported FF++ overlap on result/metric records. Optional full verification and blocking remain available through `pc_input_checks`. The targeted regression run passed **47 tests**, including **14 PC cases**: tests prove quick indexing never reads image bytes, full mode can record duplicates without blocking, and training/inference/JSON export work with explicitly duplicated frames and disclose known overlap. No source images or model/training settings were changed.

## Windows direct-crop mode

Added `input_mode: pc_crops`, a Windows/RTX 5060 Ti configuration with the author's four input roots, a CUDA 12.8 setup script, and direct image-folder loading without Colab/TAR conversion. FF++ frame training accepts flat files; inference accepts FF++ `real/<video>` plus `fake/<method>/<video>`, Celeb-DF `0|1/<video>` (0 real), and UADFV `real|fake/<video>`. PC checkpoint selection, scheduling and early stopping use Celeb-DF **frame AUC**. JSON explicitly labels Celeb-DF as selection-set reuse, including per-dataset metric/statistic rows.

Eleven PC tests passed in the final focused run: layout/labels/grouping, changed-input fingerprints, exact FF++ train/test image-overlap rejection, empty/ungrouped video rejection, empty manipulation rejection, inspect/CLI dispatch, source/output separation, AUC-over-accuracy checkpoint selection, train/infer/JSON/resume, and soft-budget interruption. The full regression run had 88 passes and one Windows test-harness stdin handle failure in the CLI test; using explicit DEVNULL stdin corrected that case. The final PC run includes that CLI test and the additional empty-method regression. Existing native scientific/preprocessing modules were not changed, preserving their code hash. PowerShell setup syntax was parsed successfully. Actual E:/F: data and the physical RTX 5060 Ti were unavailable here: run setup/inspect on the author's PC to verify them. CPU tests use synthetic crops and a tiny model, not paper measurements.

## Extended supplemental runner

Added the separate `colab/run_supplemental_suite.py` with ablation-first scheduling (matched-head, CNN-only, capacity control, compatible dual reference), followed by two additional matched/dual seed pairs. Eight focused tests cover the eight-job synthetic train/evaluate/export pipeline, native completed-run reuse without retraining, corrupt predictions and stale ensemble invalidation, exact budget-boundary interruption, blocked missing datasets, frozen preprocessing, preservation of unverified historical artifacts, runtime-lock release, and bounded retries for a transient Windows JSON replacement lock. JSON is checked for strict serialization without NaN/Infinity. A full-suite run passed 77 tests and exposed the transient replacement failure in the runner integration test; after the fix, all eight runner tests passed, including the failed case (79 distinct tests are now covered across those runs). The original 71-test baseline is recorded below; these additional tests use synthetic images and a tiny encoder, not production GPU measurements. Native scientific/preprocessing implementations and the two-run default config are byte-identical to the prior bundle, preserving native checkpoint signatures.

## Supplemental scope update

Production now selects only `favit_matched` and `cnn_only`, seed 42: two train/evaluate pairs and a 10-task acquisition-to-summary queue. Data sources, official splits, preprocessing and training hyperparameters are unchanged. The 71-test suite passed across the full run and targeted rerun (the local plotting dependency was supplied from `colab-test-tools`). Added checks cover selection-only protocol migration before checkpoints, rejection of scientific changes, exact two-run completion evidence, and synthetic training/evaluation/ensemble/report generation without a dual-model run. The synthetic fixture still exercises all five supported architectures. These checks do not measure GPU throughput or establish completion within 24 hours.

## Antigravity/Codex automation

The earlier 60-test baseline validated the former 36-task matrix (15 train/evaluate pairs). The current selection uses the supplemental queue described above. Failure-injection tests cover baseline failure/repair/replacement upload/resume, the three-repair limit, invalid SHA/GPU/evidence, stale heartbeats, stop acknowledgement, silent subprocess cancellation, credential redaction, cache corruption/path escape, backend termination recovery, environment-install error capture and checkpoint compatibility gates. Additional tests cover FF++ mirror failover and connection retries without unnecessary code repair. These are CPU/synthetic orchestration fixtures, not measured GPU experiments.

Live metadata probes on 2026-11-14 reproduced the refused connection on EU/canis:8100; EU2/kaldir returned HTTP 200 with the official 500-pair file list over HTTPS. CA timed out. EU2 is now preferred; the wrapper checks official mirror metadata and retries another reachable official mirror after a failed method. This validates reachability of metadata only, not a complete video download from Colab.

Antigravity CLI was invoked successfully. Chrome DevTools MCP 1.13.0 was installed and configured for the existing Chrome profile with session-scoped MCP permissions. Real Chrome/Google access and GPU allocation remain separately verifiable by `autopilot.py doctor` and the worker's GPU/evidence records; no fixture output establishes real Colab success.

## Source configuration update

The FF++ v4 script URL, Celeb-DF-v2 ZIP URL and Kaggle UADFV handle supplied by the user are now preset in the YAML and notebook. The actual FF++ script was read and its `--help` verified to include FaceShifter. Drive metadata confirms `Celeb-DF-v2.zip` is a ZIP of 9,952,957,051 bytes. Public Kaggle file metadata confirms raw paths such as `UADFV/fake/0000_fake.mp4`; the complete Kaggle dataset has not been downloaded in this update.

All **32 tests passed** after this update. New tests exercise KaggleHub directory results, version pinning across repeated downloads, archive override, credential-safe authentication errors, configured defaults and offline smoke isolation. KaggleHub is pinned to 1.0.3 (Python >=3.11), whose package metadata and authentication support were inspected. Tokens are never placed in source configuration or Drive metadata. The mirror also contains pre-extracted PNG frames; only raw video suffixes are selected by the pipeline.

## Passed locally

- **27 automated tests**, including official-style source-pair splitting, cross-split leakage rejection, required manipulation coverage, reversed Celeb-DF labels, missing videos, UADFV pairing, archive traversal rejection, HTTP Range resume/ignored Range handling, checksum failures, crop sampling, zero-face coverage, shard restore/resume, exact paired memberships, DeLong, Holm and bootstrap labeling.
- Interrupted/resumed CPU training matches uninterrupted training for model tensors, epoch metrics, and scheduler state in a deterministic synthetic fixture.
- A staged best-model publication is recoverable after an interrupted best/last checkpoint update.
- Both notebook files are valid nbformat-4 JSON with empty saved outputs, distinct cell IDs and syntax-checked Python cells.
- Synthetic end-to-end integration covers 44 generated videos, 88 crops, three datasets, five model variants, two epochs per variant, an interruption/resume boundary for every variant, prediction export, 50:50 score ensemble, statistics, LaTeX and plots. This uses a tiny encoder and synthetic face detector; its measurements are **not scientific FA-ViT performance**.
- Production-sized model construction was checked with `pretrained=False`, without downloading weights or training. A full dual model forward pass on a zero-valued 224×224 tensor returns one logit. Encoder initialization hashes match across all four FA-ViT variants in the same seed.
- The parser was tested against the actual public official FF++ split JSON snapshot: 1,000 source IDs; 720 train / 140 validation / 140 test; 500 source pairs. This does not verify subject identity separation.

## Production model parameter checks

| Variant | Trainable parameters | Total parameters |
|---|---:|---:|
| favit_linear | 31,072,516 | 116,871,172 |
| favit_matched | 31,074,052 | 116,872,708 |
| favit_cnn | 31,332,740 | 117,131,396 |
| cnn_only | 258,689 | 258,689 |
| favit_capacity | 31,333,036 | 117,131,692 |

The CNN branch alone has 258,304 parameters. Relative to the matched-head baseline, dual adds 258,688 and capacity control adds 258,984: the added-capacity difference is approximately 0.11%, within the configured 1% objective.

## Official split snapshot hashes

- train.json: `e59386911255e6fb0a79a7808ec2210536b8c0474268342694c4bca766d1b347`
- val.json: `b48cc511f66938e05356aaa9c67e150b1e3638c355db3d745225b0022884b36e`
- test.json: `886f5a0da623c25820692e0d8dc33d197ddb1db527a7f1cfcb9bcbca60fe4f40`

Source: `ondyari/FaceForensics`, `dataset/splits`, public master snapshot fetched on 2026-11-14. Actual preprocessing freezes and hashes the split files it uses, so later upstream changes are not silently applied to existing cached data.

## Host and limits

Local verification used Windows, Python 3.14.2, CPU PyTorch 2.13.0, torchvision 0.28.0, timm 1.0.28, albumentations 2.0.8 and NumPy 2.5.1. Plotting validation used an isolated local matplotlib 3.10.8 installation.

The Colab bootstrap separately pins Python 3.11, preprocessing Torch 2.2.2/torchvision 0.17.2 and training Torch 2.5.1/torchvision 0.20.1. **Those isolated Colab environments and CUDA paths have not been executed on a real Colab account in this session.** The bootstrap performs dependency checks and GPU calibration when the user runs the notebooks.

No approved private dataset download, full MTCNN preprocessing run, pretrained GPU training, live Drive quota/sync behavior, or real-data AUC/p-value reproduction was performed. The delivered notebook has no saved experiment outputs. Authorization, account-specific download endpoints and GPU resources must be supplied by the user in Colab.

The original model implementations and legacy training scripts are unchanged. New experiments are separate and do not overwrite historical paper results.
