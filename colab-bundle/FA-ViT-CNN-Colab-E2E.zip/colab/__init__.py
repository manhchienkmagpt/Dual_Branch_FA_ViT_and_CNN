"""Colab helpers and local PC entry points for the experiment suite."""
