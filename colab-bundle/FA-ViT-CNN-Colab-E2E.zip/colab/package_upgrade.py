"""Package the upgrade separately; never replace the user's legacy Drive bundle."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from package_bundle import package


def main():
    package()
    root = Path(__file__).resolve().parents[1]
    source = root / "colab-bundle/FA-ViT-CNN-Colab-E2E.zip"
    target = source.with_name("FA-ViT-CNN-Upgrade-v2.zip")
    shutil.copyfile(source, target)
    with zipfile.ZipFile(target) as packed:
        manifest = json.loads(packed.read("BUNDLE-MANIFEST.json"))
        for relative, expected in manifest.items():
            assert hashlib.sha256(packed.read(relative)).hexdigest() == expected, relative
        for required in ("colab/FA_ViT_CNN_Upgrade_v2.ipynb", "colab/UPGRADE-V2-VI.md",
                         "experiments/temporal/upgrade.py"):
            assert required in manifest
    print(json.dumps({"upgrade_bundle": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                      "verified_files": len(manifest), "bytes": target.stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
