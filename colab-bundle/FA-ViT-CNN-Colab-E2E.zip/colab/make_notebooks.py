"""Generate standard nbformat-4 JSON notebooks; source cells stay reviewable here."""
import ast
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def md(source):
    return {"cell_type": "markdown", "metadata": {}, "source": source.strip() + "\n"}


def code(source):
    source = source.strip() + "\n"
    ast.parse(source)
    return {"cell_type": "code", "metadata": {}, "source": source, "outputs": [], "execution_count": None}


MOUNT = r'''
from google.colab import drive
drive.mount('/content/drive')
from pathlib import Path, PurePosixPath
import hashlib, json, runpy, zipfile

# Upload the delivered ZIP to this location once. Change the path if needed.
PROJECT_ZIP = '/content/drive/MyDrive/FA-ViT-CNN-Colab-E2E.zip' #@param {type:'string'}
DRIVE_ROOT = '/content/drive/MyDrive/FA_ViT_CNN_Experiments' #@param {type:'string'}
PROJECT = Path('/content/favit-code')
archive = Path(PROJECT_ZIP)
assert archive.is_file(), f'Chưa tìm thấy ZIP: {archive}. Hãy upload gói code lên Drive trước.'
PROJECT.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(archive) as packed:
    for item in packed.infolist():
        name = PurePosixPath(item.filename.replace('\\', '/'))
        target = (PROJECT / str(name)).resolve()
        assert target.is_relative_to(PROJECT.resolve()), 'Unsafe ZIP member'
        assert not (((item.external_attr >> 16) & 0o170000) == 0o120000), 'ZIP symlink unsupported'
    packed.extractall(PROJECT)
manifest = json.loads((PROJECT / 'BUNDLE-MANIFEST.json').read_text())
for relative, expected in manifest.items():
    path = (PROJECT / relative).resolve()
    assert path.is_relative_to(PROJECT.resolve()) and hashlib.sha256(path.read_bytes()).hexdigest() == expected, f'Bundle integrity error: {relative}'
assert (PROJECT / 'experiments' / '__main__.py').exists(), 'Sai gói source ZIP'
print('Code bundle SHA256:', hashlib.sha256(archive.read_bytes()).hexdigest())
bootstrap = runpy.run_path(str(PROJECT / 'colab' / 'bootstrap.py'))
'''

PREPARE_CONFIG = r'''
CONFIG = bootstrap['template_config'](PYTHON, PROJECT)
CONFIG['drive_root'] = DRIVE_ROOT
CONFIG['local_root'] = '/content/favit-work'
CONFIG_FILE = Path('/content/favit-prepare-session.json')
REBUILD_DATA = False #@param {type:'boolean'}
FFPP_SCRIPT_URL = 'https://kaldir.vc.in.tum.de/faceforensics_download_v4.py' #@param {type:'string'}
CELEBDF_ZIP_URL = 'https://drive.google.com/file/d/1iLx76wsbi9itnkxSqz9BVBl4ZvnbIazj/view' #@param {type:'string'}
UADFV_KAGGLE_HANDLE = 'adityakeshri9234/uadfv-dataset' #@param {type:'string'}
ACCEPTED_FFPP_TERMS = False #@param {type:'boolean'}
USE_KAGGLE_SECRET = False #@param {type:'boolean'}
active = Path(DRIVE_ROOT) / 'cache' / 'active.json'
USE_EXISTING_CACHE = active.is_file() and not REBUILD_DATA
if USE_EXISTING_CACHE:
    index_path = Path(DRIVE_ROOT) / json.loads(active.read_text())['index']
    assert index_path.resolve().is_relative_to((Path(DRIVE_ROOT)/'cache').resolve())
    index = json.loads(index_path.read_text())
    assert not index['smoke'], 'Không dùng cache smoke cho thí nghiệm thật'
    assert all(index['datasets'].get(d, {}).get('complete') for d in ['ffpp','celebdf','uadfv']), 'Cache chưa đủ ba dataset: bật REBUILD_DATA'
    for key in ['image_size','train_frames','eval_frames','face_margin','jpeg_quality','detector','shard_videos']:
        assert index['settings'][key] == CONFIG['data'][key], 'Preprocess protocol thay đổi: chọn Drive root mới'
    print('Dùng cache đã hoàn tất; không cần nhập link hoặc tải video lại.')
else:
    # The three sources were explicitly supplied by the author; no URL prompt.
    CONFIG['sources']['ffpp']['script'] = FFPP_SCRIPT_URL.strip()
    CONFIG['sources']['ffpp']['accepted_terms'] = ACCEPTED_FFPP_TERMS
    CONFIG['sources']['celebdf']['source'] = CELEBDF_ZIP_URL.strip()
    CONFIG['sources']['uadfv'].update(provider='kagglehub', handle=UADFV_KAGGLE_HANDLE.strip(), source='')
    assert ACCEPTED_FFPP_TERMS, 'Đọc điều khoản FF++ rồi bật ACCEPTED_FFPP_TERMS. Không tự động chấp nhận điều khoản.'
    if USE_KAGGLE_SECRET:
        import os
        from google.colab import userdata
        os.environ['KAGGLE_API_TOKEN'] = userdata.get('KAGGLE_API_TOKEN')
        print('Đã nạp Kaggle API token từ Colab Secrets; không ghi token vào config hoặc output.')
CONFIG_FILE.write_text(json.dumps(CONFIG, indent=2))
def run(stage, *arguments):
    return bootstrap['run_stage'](PYTHON, PROJECT, CONFIG_FILE, stage, *arguments, drive_root=DRIVE_ROOT)
run('doctor')
'''

TRAIN_CONFIG = r'''
CONFIG = bootstrap['template_config'](PYTHON, PROJECT)
protocol = Path(DRIVE_ROOT) / 'protocol.json'
if protocol.is_file():
    CONFIG = json.loads(protocol.read_text())
CONFIG['drive_root'] = DRIVE_ROOT
CONFIG['local_root'] = '/content/favit-work'
# Protocol parameters must stay fixed across all runs in this Drive root.
CONFIG['training']['seeds'] = [42]
CONFIG['training']['variants'] = ['favit_matched','cnn_only']
bootstrap['freeze_protocol'](CONFIG)
CONFIG_FILE = Path('/content/favit-training-session.json')
CONFIG_FILE.write_text(json.dumps(CONFIG, indent=2))
def run(stage, *arguments):
    return bootstrap['run_stage'](PYTHON, PROJECT, CONFIG_FILE, stage, *arguments, drive_root=DRIVE_ROOT)
run('doctor')
if not (Path(DRIVE_ROOT)/'runtime.json').exists():
    run('doctor', '--calibrate')
else:
    print('Giữ microbatch/precision đã chốt:', (Path(DRIVE_ROOT)/'runtime.json').read_text())
'''


def save(name, cells):
    cells.extend([
        md('''## Tự động chạy qua Antigravity và Codex
Bộ điều phối local `python colab/autopilot.py start` giao từng tác vụ, chỉ dùng L4, lưu log trên Drive và tiếp tục từ checkpoint hợp lệ. Cell dưới chỉ nạp API điều khiển; không tự bắt đầu training. Không bấm Run all khi bộ điều phối đang hoạt động.
Nếu Google yêu cầu đăng nhập hoặc cấp quyền Drive, hoàn tất trực tiếp rồi dùng `python colab/autopilot.py resume` trên máy local.'''),
        code("if 'AUTOPILOT' not in globals():\n    AUTOPILOT = runpy.run_path(str(PROJECT / 'colab' / 'autopilot_runtime.py'))['install'](globals())\nprint(AUTOPILOT['status']())")
    ])
    notebook = {"nbformat": 4, "nbformat_minor": 5,
                "metadata": {"colab": {"name": name, "gpuType": "L4"}, "accelerator": "GPU",
                             "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                             "language_info": {"name": "python"}}, "cells": cells}
    for index, cell in enumerate(cells):
        cell["id"] = f"cell-{index:03d}"
    (HERE / name).write_text(json.dumps(notebook, ensure_ascii=False, indent=1), encoding="utf-8")


def main():
    save('01_prepare_data.ipynb', [
        md('''# 01 — Tải dữ liệu, preprocess và lưu cache lên Google Drive
Chạy notebook này trước, sau đó mở notebook 02. Chọn **Runtime → Change runtime type → L4 GPU** cho bộ thực nghiệm này.

Upload `FA-ViT-CNN-Colab-E2E.zip` lên MyDrive. Mỗi cell chạy theo thứ tự từ trên xuống. Không cần push code lên GitHub.

**Nguồn chính thức:** [FF++ và FaceShifter](https://github.com/ondyari/FaceForensics), [Celeb-DF-v2](https://github.com/yuezunli/celeb-deepfakeforensics).
Đã cấu hình sẵn script FF++ v4 và file ZIP Celeb-DF-v2 do bạn cung cấp. UADFV tải bằng `kagglehub.dataset_download("adityakeshri9234/uadfv-dataset")`.
Bạn không cần nhập lại URL; chỉ xác nhận điều khoản FF++ trước bước tải. UADFV là bản mirror trên Kaggle do bạn chọn; pipeline kiểm tra video trước khi dùng.

Drive chỉ lưu crop shards, manifests, pretrained cache và kết quả. Video gốc ở `/content`, sẽ mất khi runtime bị thu hồi. Không cần lưu hàng trăm nghìn file rời trên Drive.'''),
        code(MOUNT),
        md('## Môi trường riêng cho MTCNN\nKhông thay Torch trong kernel Colab hoặc môi trường training. Lần đầu tải dependencies có thể mất vài phút.'),
        code("PYTHON = bootstrap['bootstrap_env'](PROJECT, 'preprocess')"),
        md('## Nguồn tải đã điền sẵn\nGiữ ba nguồn mặc định bạn đã cung cấp. Bật `ACCEPTED_FFPP_TERMS` sau khi đọc điều khoản. UADFV thử tải công khai; nếu Kaggle yêu cầu đăng nhập, thêm Secret `KAGGLE_API_TOKEN`, bật quyền truy cập secret cho notebook và bật `USE_KAGGLE_SECRET`. Token không được ghi vào config hoặc gói source. Nếu cache đã đầy đủ, cell bỏ qua tải lại.'),
        code(PREPARE_CONFIG),
        md('## Tải video và tạo manifest\nFF++ dùng c23 và đủ năm kiểu giả, split chính thức. Celeb-DF chỉ dùng 518 video test. UADFV dùng 49 real và 49 fake. Dữ liệu thiếu hoặc nguồn chéo split làm bước này dừng để bạn xử lý.'),
        code("if not USE_EXISTING_CACHE:\n    run('prepare')\nelse:\n    print('Bỏ qua tải lại: cache đã sẵn sàng.')"),
        md('## Crop và đóng shard\nMTCNN, largest face, margin 20%, JPEG 224×224. Train lấy tối đa 20 frame/video; validation/test 50. Cache lưu sau từng shard 64 video. Nếu ngắt phiên, chạy lại để tiếp tục; shard hợp lệ được bỏ qua. Video không có crop được ghi rõ, không coi là xử lý thành công.'),
        code("if not USE_EXISTING_CACHE:\n    run('preprocess')"),
        md('## Kiểm tra cache và ảnh mẫu\nKhông tự xóa raw video trước khi kiểm tra chất lượng. Mở notebook 02 sau khi cả ba dataset có `complete: true`.'),
        code(r'''
from IPython.display import display, Image
active = json.loads((Path(DRIVE_ROOT)/'cache'/'active.json').read_text())
index_path = Path(DRIVE_ROOT)/active['index']
index = json.loads(index_path.read_text())
for name, item in index['datasets'].items():
    print(name, 'complete:', item['complete'], 'videos:', sum(s['videos'] for s in item['shards']),
          'crops:', sum(s['frames'] for s in item['shards']),
          'zero-crop videos:', sum(len(s['no_crop_video_ids']) for s in item['shards']))
    preview = index_path.parent/'previews'/f'{name}.jpg'
    if preview.is_file(): display(Image(filename=str(preview), width=224))
assert all(index['datasets'].get(d, {}).get('complete') for d in ['ffpp','celebdf','uadfv'])
public_protocol = json.loads(json.dumps(CONFIG))
public_protocol['sources'] = {}  # Never persist authorized URLs or acceptance credentials.
protocol_path = Path(DRIVE_ROOT)/'protocol.json'
if not protocol_path.exists():
    protocol_path.write_text(json.dumps(public_protocol, indent=2))
else:
    print('Giữ protocol.json hiện có; không thay training protocol của các run trước.')
print('Sẵn sàng cho notebook 02. Cache nằm ở:', index_path.parent)
''')])
    save('02_run_experiments.ipynb', [
        md('''# 02 — Hai thí nghiệm bổ sung: FA-ViT matched-head và CNN-only
Chạy notebook 01 trước. Chọn GPU, upload cùng gói source ZIP và dùng cùng Drive root. Các lượt chạy tuần tự; bộ đầy đủ có thể cần nhiều phiên Colab.

**2 cấu hình × seed 42 = 2 lượt**: FA-ViT cùng LN–Dropout head (`favit_matched`) và CNN-only (`cnn_only`). FA-ViT linear và FA-ViT-CNN đã có kết quả trong paper; notebook này chỉ chạy hai đối chứng còn thiếu.
Giữ nguyên dữ liệu, split, MTCNN, 20/50 frame, tối đa 30 epoch và early stopping patience 5. Ensemble 50:50 của hai mô hình bổ sung dùng dự đoán có sẵn, không train thêm.

Run hoàn tất được bỏ qua. Run bị ngắt tiếp tục từ cuối epoch đã lưu; không phải từ giữa epoch. Giữ cùng code, cache và protocol giữa các phiên. Không dùng Celeb-DF/UADFV để chọn checkpoint.'''),
        code(MOUNT),
        code("PYTHON = bootstrap['bootstrap_env'](PROJECT, 'training')"),
        md('## Kiểm tra GPU và chốt cấu hình\nĐo bộ nhớ bằng dual model và chọn một microbatch chung cho tất cả biến thể. Effective batch 16, AMP theo GPU. Đổi protocol sau khi có run sẽ yêu cầu Drive root mới.'),
        code(TRAIN_CONFIG),
        md('## Huấn luyện\nĐể `all` để chạy/tiếp tục cả bộ. Hoặc chọn một biến thể và một seed cho từng phiên. Checkpoint lưu lên Drive sau mỗi epoch; chỉ FF++ validation accuracy quyết định best model.'),
        code(r'''
VARIANT = 'all' #@param ['all','favit_matched','cnn_only']
SEED = '42' #@param ['42']
arguments = ['--variant', VARIANT]
if SEED != 'all': arguments += ['--seed', SEED]
run('train', *arguments)
'''),
        md('## Đánh giá và lưu dự đoán\nDùng cùng lựa chọn biến thể/seed ở trên. Xuất frame/video predictions, mean/median aggregation và coverage. Nếu có test video không crop được, mặc định dừng thay vì âm thầm bỏ video.'),
        code("run('evaluate', *arguments)"),
        md('## Tổng hợp hai đối chứng và ensemble\nXuất kết quả matched-head, CNN-only và ensemble 50:50, không train thêm ensemble. Một seed không có độ lệch chuẩn qua seed. Chưa nhập prediction FA-ViT-CNN cũ nên các so sánh cần mô hình đó được ghi thiếu dữ liệu, không tự điền số từ paper.'),
        code("run('summarize')"),
        code(r'''
from IPython.display import display, Markdown, Image
summary = Path(DRIVE_ROOT)/'summaries'
display(Markdown((summary/'REPORT-VI.md').read_text()))
for name in ['video-auc.png', 'training-curves.png']:
    if (summary/name).is_file(): display(Image(filename=str(summary/name)))
print('CSV, JSON, bảng LaTeX và hình được lưu tại:', summary)
print((summary/'progress.json').read_text())
'''),
        md('''## Các file cần dùng để cập nhật paper
- `metrics-per-seed.csv`, `metrics-mean-std.csv`, `results.tex`.
- `paired-delong-exploratory.csv`, `primary-comparison-bootstrap.json`.
- Mỗi run có config, environment, model-info, history, best weights và prediction CSV.
- `progress.json` xác nhận có đủ hai lượt bổ sung và ba dataset hay chưa.

Kết quả bổ sung dùng seed 42; không có độ lệch chuẩn qua nhiều seed. Chỉ so trực tiếp với bảng cũ sau khi xác nhận cùng split, crop, lịch train và tập test. Không điền kết quả smoke vào paper. Pipeline không tự sửa/nộp paper.''')])
    print('Generated two standard Colab notebooks with syntax-checked Python cells')


if __name__ == '__main__':
    main()
