# Temporal pipeline validation

Explicit exclusion repair (2026-11-16):

- 25 temporal tests passed (24 in the suite, plus the new ten-fold exclusion
  integration test). The 13 detector-format regression tests also passed.
- A fixture reproduces one rejected FF++ video and the exact legacy cache
  implementation identity. All saved TAR hashes stay unchanged after an
  explicit exclusion; the pipeline completes FF++ and proceeds to UADFV.
- Unknown videos, a mismatched source manifest, changed exclusion decisions,
  and additional unapproved clip failures are rejected. Materialization filters
  excluded videos even when their clips already exist inside an old shard.
- A ten-fold fixture trains/evaluates all ten folds of one variant after an
  exclusion. Complete out-of-fold reporting covers exactly the 69 retained
  fixture videos and publishes the exclusion reason and source/included counts.
- Initial subprocess validation encountered a Windows sandbox DuplicateHandle
  error; the isolated rerun and the subsequent temporal suite passed.
- Real Drive inspection found FF++ at 94 saved shards / 6,000 source videos,
  with only `ffpp/Deepfakes/638_640` rejected. UADFV has a verified 98-video source
  manifest but no temporal crop cache. Real cache finalization and UADFV MTCNN
  processing still need to run in Colab; fixture tests are not real-data results.

Acquisition resume/progress repair:

- Missing FF++ downloads resume before video decoding. Inventories do not hash
  file contents and directory discovery is shared across manipulation methods.
- New/changed files are streamed once to local scratch, hashing during the copy;
  OpenCV checks local files. A per-file size/mtime ledger persists completed
  checks and permits reuse after interruption. Frozen manifests and preprocessing
  SHA-256 verification remain in force.
- Stage logs are initialized before launching the worker, and the temporal
  wrapper emits a 30-second no-output heartbeat. A heartbeat is not an I/O
  progress guarantee.
- Targeted temporal tests cover cache reuse without reopening unchanged videos,
  interrupted verification, changed-file rejection, download-before-validation,
  retained/repaired corrupt files and initialization of silent-worker logs.
- The 38 legacy Colab acquisition/evaluation tests passed after the shared
  manifest-builder optimization.

Local checks completed for the CPU-first Colab implementation:

- 15 temporal behavioral tests passed, including Torch-blocked acquisition,
  acquisition bootstrap without CUDA/Torch wheels, source-group fold rotation,
  synchronized clip augmentation, corrupt cache repair, all five model graphs,
  frozen encoder weights, resume, corrupt checkpoint/export detection and
  CPU-first notebook structure.
- 56 relevant legacy regression tests passed. One plotting test initially lacked
  Matplotlib in the local interpreter and passed when rerun with the existing
  workspace plotting dependencies. The Colab training requirements include
  Matplotlib; no application change was needed for that local dependency issue.
- The full production graph ran forward/backward on CPU with random weights and
  input `[1,8,3,224,224]`. Its output was finite, frozen ViT weights received no
  gradients, and CNN, temporal and patch-fusion weights received gradients.
- End-to-end synthetic smoke completed all 50 jobs, each interrupted after its
  first epoch and resumed. Completed jobs were reused. FF++/UADFV predictions
  were exported, then a manually supplied Celeb-DF ZIP with a wrapper folder was
  introduced and evaluated with all 50 checkpoints. FF++ cache identities and
  checkpoint hashes remained unchanged. Each variant had complete out-of-fold
  coverage and ten measured fold records for all three fixture datasets.
- Notebook cells compile, acquisition is the default phase, GPU metadata is
  absent, and the final code cell handles manual Celeb-DF upload/preprocessing.

All smoke metrics are synthetic fixture results, **not scientific measurements**.
The real graph check used random initialization, not pretrained performance.
This host has CPU-only Torch; actual CUDA/L4 calibration, MTCNN execution and
authorized dataset downloads must still be confirmed in the Colab environment.

Reproduce with:

```bash
python -m pytest tests/test_temporal.py -q
python -m experiments.temporal smoke --output experiment-output/temporal-smoke-new
python colab/make_temporal_notebook.py
python colab/package_bundle.py
```

Do not reuse an existing smoke output folder. Keep real experiments in a
separate Drive root with `smoke: false` and the original 30-epoch/patience-5 preset.
