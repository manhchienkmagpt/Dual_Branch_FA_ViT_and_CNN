"""Direct Windows-style crop layouts; no video grouping needed for train frames."""
import copy
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image
import pytest
import torch
import yaml

from experiments.common import ROOT, load_config, read_json, scratch_directory
from colab.pc_crops import scan_inputs, run_pc, pc_signature, PCEvidence, train_epoch, infer
from colab.run_supplemental_suite import plan


@pytest.fixture
def config():
    torch.set_num_threads(2)
    with scratch_directory(ROOT / "experiment-output", "pc-crops-test-") as work:
        config = yaml.safe_load((ROOT / "colab/experiment_config.pc.yaml").read_text(encoding="utf-8"))
        config.update(drive_root=str(work / "smoke-pc-results"), local_root=str(work / "work"), smoke=True)
        config["pc_input_checks"] = {"verify_image_contents": True, "reject_identical_train_test": True,
                                      "known_ffpp_overlap_reported": False}
        config["training"].update(epochs=2, num_workers=0, pretrained=False, effective_batch_size=4,
                                   microbatch_size=2, precision="fp32", keep_completed_resume=True)
        config["evaluation"]["bootstrap_reps"] = 20
        roots = {name: work / name for name in config["pc_data"]}
        config["pc_data"] = {name: str(path) for name, path in roots.items()}
        rng = np.random.default_rng(1234)
        def picture(path):
            path.parent.mkdir(parents=True, exist_ok=True)
            Image.fromarray(rng.integers(0, 255, (32, 32, 3), dtype=np.uint8)).save(path)
        for method in ("original", "Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures", "FaceShifter"):
            for i in range(2):
                picture(roots["ffpp_train_root"] / "train" / method / f"loose_{i}.jpg")
                category = roots["ffpp_test_root"] / ("real" if method == "original" else "fake/" + method)
                picture(category / str(i) / "frame_001.jpg")
        for key, labels in (("celebdf_test_root", ("0", "1")), ("uadfv_test_root", ("real", "fake"))):
            for label in labels:
                for video in ("v0", "v1"):
                    picture(roots[key] / label / video / "frame_001.jpg")
                    picture(roots[key] / label / video / "frame_002.jpg")
        path = work / "config.yaml"
        path.write_text(yaml.safe_dump(config), encoding="utf-8")
        yield load_config(path)


class TinyModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.classifier = torch.nn.Linear(3, 1)

    def forward(self, image):
        return self.classifier(image.mean(dim=(2, 3))).flatten()


def test_layouts_and_numeric_celeb_labels(config):
    data = scan_inputs(config)
    assert len(data["train"]) == 12 and all(r["video_id"] is None for r in data["train"])
    assert len(data["selection"]) == 8
    assert all(r["label"] == int(r["source_relative_path"].split('/')[0]) for r in data["selection"])
    assert {r["method"] for r in data["test"] if r["dataset"] == "ffpp"} == {
        "original", "Deepfakes", "Face2Face", "FaceSwap", "NeuralTextures", "FaceShifter"}
    uadfv = [r for r in data["test"] if r["dataset"] == "uadfv"]
    assert all(r["grouping_verified"] == 1 for r in uadfv)
    assert len({r["group_id"] for r in uadfv}) == 2
    assert data["audit"]["ffpp_source_video_separation"] == "not_established"


def test_input_changes_change_dataset_hash(config):
    before = scan_inputs(config)
    path = Path(before["train"][0]["local_path"])
    Image.fromarray(np.zeros((32, 32, 3), dtype=np.uint8)).save(path)
    assert scan_inputs(config)["dataset_hash"] != before["dataset_hash"]


def test_identical_ffpp_train_test_images_are_blocked(config):
    data = scan_inputs(config)
    train = Path(data["train"][0]["local_path"])
    test = next(Path(r["local_path"]) for r in data["test"] if r["dataset"] == "ffpp")
    test.write_bytes(train.read_bytes())
    with pytest.raises(ValueError, match="Identical images"):
        scan_inputs(config)


def test_quick_mode_does_not_open_images_or_block_duplicates(config, monkeypatch):
    data = scan_inputs(config)
    train = Path(data["train"][0]["local_path"])
    test = next(Path(r["local_path"]) for r in data["test"] if r["dataset"] == "ffpp")
    test.write_bytes(train.read_bytes())
    config["pc_input_checks"] = {"verify_image_contents": False, "reject_identical_train_test": False,
                                  "known_ffpp_overlap_reported": True}
    def forbidden_read(*args, **kwargs):
        raise AssertionError("Quick mode must not open image contents")
    monkeypatch.setattr(Path, "read_bytes", forbidden_read)
    quick = scan_inputs(config)
    assert len(quick["train"]) == len(data["train"])
    assert quick["audit"]["ffpp_identical_train_test_images"] is None
    assert quick["audit"]["input_verification"]["known_ffpp_overlap_reported"]
    assert quick["audit"]["input_verification"]["fingerprint_basis"] == "paths_sizes_mtimes_only"
    assert all(r["sha256"] is None and r["width"] is None for r in quick["test"])


def test_full_mode_can_record_duplicates_without_blocking(config):
    data = scan_inputs(config)
    train = Path(data["train"][0]["local_path"])
    test = next(Path(r["local_path"]) for r in data["test"] if r["dataset"] == "ffpp")
    test.write_bytes(train.read_bytes())
    config["pc_input_checks"]["reject_identical_train_test"] = False
    audit = scan_inputs(config)["audit"]
    assert audit["ffpp_identical_train_test_images"] >= 1
    assert audit["input_verification"]["known_ffpp_overlap_reported"]


def test_quick_mode_trains_and_exports_known_overlap(config):
    verified = scan_inputs(config)
    train = Path(verified["train"][0]["local_path"])
    test = next(Path(r["local_path"]) for r in verified["test"] if r["dataset"] == "ffpp")
    test.write_bytes(train.read_bytes())
    config["pc_input_checks"] = {"verify_image_contents": False, "reject_identical_train_test": False,
                                  "known_ffpp_overlap_reported": True}
    data = scan_inputs(config)
    runtime = {"device": "cpu", "precision": "fp32", "microbatch_size": 2}
    evidence = PCEvidence(config, data, runtime)
    job = plan()[0]
    build = lambda *args: TinyModel()
    train_epoch(config, data, runtime, evidence, job, build)
    assert train_epoch(config, data, runtime, evidence, job, build)
    infer(config, data, runtime, evidence, job, build)
    evidence.export("running")
    result = read_json(evidence.root / "paper-results.json")
    assert result["input_verification"]["mode"] == "quick"
    assert not result["input_verification"]["image_contents_verified"]
    assert "NOT an untouched test" in result["evaluation_protocol"]["reporting"]["ffpp"]
    ffpp_metrics = [r for r in result["metrics_per_seed"] if r["dataset"] == "ffpp"]
    assert ffpp_metrics and all(r["known_training_overlap_reported"] for r in ffpp_metrics)


def test_empty_or_flat_test_video_layout_is_blocked(config):
    root = Path(config["pc_data"]["celebdf_test_root"]) / "0"
    (root / "empty_video").mkdir()
    with pytest.raises(ValueError, match="Empty video folders"):
        scan_inputs(config)
    (root / "empty_video").rmdir()
    (root / "loose.jpg").write_bytes(next(root.rglob('*.jpg')).read_bytes())
    with pytest.raises(ValueError, match="video subfolders"):
        scan_inputs(config)


def test_empty_ffpp_method_cannot_be_reported_as_complete(config):
    method = Path(config["pc_data"]["ffpp_test_root"]) / "fake/FaceShifter"
    for image in method.rglob('*.jpg'):
        image.unlink()
    for video in list(method.iterdir()):
        video.rmdir()
    with pytest.raises(ValueError, match="Empty video folders|No video folders"):
        scan_inputs(config)


def test_inspect_writes_manifest_without_training(config):
    audit = run_pc(config, inspect_only=True)
    root = Path(config["drive_root"])
    assert audit["status"] == "checked" and not (root / "runs").exists()
    assert read_json(root / "supplemental/input-manifest.json")["frames"]


def test_cli_inspect_and_plan_dispatch_to_pc(config):
    path = Path(config["local_root"]).parent / "cli.yaml"
    path.write_text(yaml.safe_dump(config), encoding="utf-8")
    command = [sys.executable, str(ROOT / "colab/run_supplemental_suite.py"), "--config", str(path)]
    inspected = subprocess.run([*command, "--inspect"], stdin=subprocess.DEVNULL,
                               capture_output=True, text=True, encoding="utf-8", check=True)
    assert json.loads(inspected.stdout)["test_video_counts"] == {"ffpp": 12, "celebdf": 4, "uadfv": 4}
    planned = subprocess.run([*command, "--plan"], stdin=subprocess.DEVNULL,
                             capture_output=True, text=True, encoding="utf-8", check=True)
    assert len(json.loads(planned.stdout)["jobs"]) == 8
    assert not (Path(config["drive_root"]) / "runs").exists()


def test_outputs_cannot_write_into_image_roots(config):
    changed = copy.deepcopy(config)
    changed["drive_root"] = str(Path(config["pc_data"]["ffpp_train_root"]) / "output")
    with pytest.raises(ValueError, match="separate from input images"):
        run_pc(changed, inspect_only=True)
    assert not Path(changed["drive_root"]).exists()


def test_best_checkpoint_uses_celeb_frame_auc_not_accuracy(config, monkeypatch):
    import experiments.training as native
    data = scan_inputs(config)
    runtime = {"device": "cpu", "precision": "fp32", "microbatch_size": 2}
    evidence = PCEvidence(config, data, runtime)
    scores = iter([(.6, .9), (.8, .7)])
    observed_selection = []
    def controlled_epoch(model, loader, *args, **kwargs):
        optimizer = args[3] if len(args) > 3 else None
        # Native one_epoch positional tail is device, criterion, precision, optimizer.
        if optimizer is not None:
            assert {r["dataset"] for r in loader.dataset.rows} == {"ffpp"}
            return {"auc": .5, "accuracy": .5, "loss": .7}
        observed_selection.append({r["dataset"] for r in loader.dataset.rows})
        auc, accuracy = next(scores)
        return {"auc": auc, "accuracy": accuracy, "loss": .7}
    monkeypatch.setattr(native, "one_epoch", controlled_epoch)
    job = {"variant": "favit_matched", "seed": 42}
    assert not train_epoch(config, data, runtime, evidence, job, lambda *args: TinyModel())
    assert train_epoch(config, data, runtime, evidence, job, lambda *args: TinyModel())
    folder = evidence.drive / "runs/favit_matched/seed-42"
    best = torch.load(folder / "best.pt", map_location="cpu", weights_only=False)
    assert best["epoch"] == 2
    assert observed_selection == [{"celebdf"}, {"celebdf"}]
    assert read_json(folder / "state.json")["best_selection_auc"] == .8


def test_pc_end_to_end_export_resume_and_selection_disclosure(config):
    calls = []
    def build(variant, seed):
        calls.append((variant, seed))
        return TinyModel()
    result = run_pc(config, phase="ablations", max_hours=0, model_factory=build)
    assert result["complete"] and len(result["completed"]) == 4
    root = Path(config["drive_root"])
    bundle = read_json(root / "supplemental/paper-results.json")
    assert bundle["evaluation_protocol"]["checkpoint_selection"] == "maximum Celeb-DF frame AUC"
    assert "NOT an untouched test" in bundle["evaluation_protocol"]["reporting"]["celebdf"]
    measured = [r for r in bundle["run_results"] if r["status"] == "completed"]
    assert len(measured) == 4 and all(r["video_predictions"] for r in measured)
    assert all(m["evaluation_role"] == "model_selection_reuse" for m in bundle["metrics_per_seed"] if m["dataset"] == "celebdf")
    assert len(read_json(root / "supplemental/timing.json")["epochs"]) == 8
    assert {r["level"] for r in measured[0]["metrics"]} == {"frame", "video_mean", "video_median"}
    calls.clear()
    second = run_pc(config, phase="ablations", max_hours=0, model_factory=build)
    assert second["complete"] and calls == []
    assert len(read_json(root / "supplemental/timing.json")["epochs"]) == 8
    changed = copy.deepcopy(config)
    changed["training"]["lr"] = .0002
    with pytest.raises(ValueError, match="protocol/data/config/code changed"):
        run_pc(changed, phase="ablations", max_hours=0, model_factory=build)


def test_pc_budget_preserves_partial_epoch(config):
    ticks = iter(range(100))
    progress = run_pc(config, phase="ablations", max_hours=3.5/3600,
                      model_factory=lambda *args: TinyModel(), clock=lambda: next(ticks))
    assert not progress["complete"] and progress["status"] == "budget_exhausted"
    state = read_json(Path(config["drive_root"]) / "runs/favit_matched/seed-42/state.json")
    assert state["status"] == "interrupted" and state["epoch"] == 1
