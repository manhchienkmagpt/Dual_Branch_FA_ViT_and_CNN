"""Failure injection for the actual supervisor, runtime evidence, and subprocesses."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys
import threading
import time

import pytest

from experiments.common import ROOT, scratch_directory


def load(name, relative):
    spec = importlib.util.spec_from_file_location(name, ROOT / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


control = load("favit_autopilot", "colab/autopilot.py")
runtime = load("favit_autopilot_runtime", "colab/autopilot_runtime.py")
bootstrap = load("favit_bootstrap", "colab/bootstrap.py")


@pytest.fixture
def tmp_path():
    with scratch_directory(ROOT / "experiment-output", "autopilot-test-") as path:
        yield path


class FakeAgents:
    def __init__(self):
        self.actions = []
        self.repairs = []
        self.version = 0
        self.fail_key = None
        self.override = None

    def browser(self, action, task, release, config):
        self.actions.append((action, task["task_id"], release["sha256"]))
        if action == "preflight":
            return {"task_id": "preflight", "status": "completed", "runtime": {"connected": True}, "details": "connected"}
        if action == "upload":
            return {"task_id": "upload", "status": "completed", "runtime": {"file_id": control.IDS["bundle"], "uploaded": True}, "details": "uploaded"}
        proof = {"videos": {"ffpp": 6000, "celebdf": 518, "uadfv": 98}.get(task.get("dataset")),
                 "complete": True, "smoke": False, "sha256": "verified", "runtime": {"microbatch_size": 16},
                 "state": {"status": "completed"}, "best_sha256": "weights", "metrics_sha256": "metrics",
                 "predictions_sha256": "predictions", "progress": {"complete": True, "smoke": False, "measured_runs": 2, "expected_runs": 2}}
        record = {**task, "status": "completed", "gpu": ["NVIDIA L4, GPU-test"], "evidence": proof}
        if task.get("key") == self.fail_key:
            record.update(status="failed", error="baseline injected failure", traceback="Traceback: injected", has_checkpoints=False)
        if action == "stop":
            record["status"] = "stopped"
        response = {"task_id": task["task_id"], "status": record["status"], "runtime": record, "details": "fake fixture only"}
        if self.override:
            self.override(response)
        return response

    def repair(self, failure, attempt):
        self.repairs.append((failure["task_id"], attempt))
        self.version += 1
        return ["colab/bootstrap.py"]


@pytest.fixture
def supervisor(tmp_path, monkeypatch):
    agents = FakeAgents()
    supervisor = control.Supervisor(tmp_path, agents=agents, clock=lambda: 2000000000)
    monkeypatch.setattr(supervisor, "release", lambda: {"sha256": f"release-{agents.version}", "archive": "fixture.zip", "source": {"fixture": str(agents.version)}})
    monkeypatch.setattr(supervisor, "validate_and_package", lambda: None)
    return supervisor


def test_full_matrix_baseline_first_and_persisted_restart(supervisor):
    assert control.jobs()[5]["key"] == "train-favit_matched-42"
    assert len([j for j in control.jobs() if j["stage"] == "train"]) == 2
    for _ in range(len(control.jobs()) + 1):
        supervisor.tick()
    assert supervisor.state["status"] == "completed"
    assert len(supervisor.state["completed"]) == 10
    reopened = control.Supervisor(supervisor.home, agents=supervisor.agents)
    assert reopened.state["cursor"] == 10
    assert len([a for a in supervisor.agents.actions if a[0] == "upload"]) == 1


def test_baseline_error_repair_upload_and_resume(supervisor):
    supervisor.state["cursor"] = 5
    supervisor.agents.fail_key = "train-favit_matched-42"
    supervisor.tick()
    assert supervisor.state["attempts"]["train-favit_matched-42"] == 1
    assert len(supervisor.agents.repairs) == 1
    supervisor.agents.fail_key = None
    supervisor.tick()
    uploads = [a[2] for a in supervisor.agents.actions if a[0] == "upload"]
    assert uploads == ["release-0", "release-1"]
    assert supervisor.state["cursor"] == 6
    assert supervisor.state["completed"][0]["runtime"]["bundle_sha256"] == "release-1"


def test_three_repairs_do_not_reset_when_error_repeats(supervisor):
    supervisor.state["cursor"] = 5
    supervisor.agents.fail_key = "train-favit_matched-42"
    for _ in range(4):
        supervisor.tick()
    assert len(supervisor.agents.repairs) == 3
    assert supervisor.state["status"] == "needs_attention"
    assert "limit" in supervisor.state["details"]


@pytest.mark.parametrize("mutation", [
    lambda r: r["runtime"].update(bundle_sha256="wrong"),
    lambda r: r["runtime"].update(task_id="different-job"),
    lambda r: r["runtime"].update(gpu=["NVIDIA T4"]),
    lambda r: r["runtime"].update(evidence={}),
    lambda r: r["runtime"]["evidence"].update(videos=1),
])
def test_no_false_completion(supervisor, mutation):
    supervisor.agents.override = mutation
    supervisor.tick()
    assert supervisor.state["cursor"] == 0
    assert supervisor.state["status"] == "needs_attention"


def test_wait_l4_expires_without_switching_gpu(supervisor):
    supervisor.agents.override = lambda r: r.update(status="waiting_l4")
    supervisor.tick()
    assert supervisor.state["status"] == "waiting_l4"
    supervisor.clock = lambda: 2000000000 + 86401
    supervisor.tick()
    assert supervisor.state["status"] == "needs_attention"
    assert not supervisor.agents.repairs


def test_stale_heartbeat_never_restarts_runtime(supervisor):
    def stale(response):
        response.update(status="running")
        response["runtime"]["heartbeat_at"] = "2020-01-01T00:00:00+00:00"
    supervisor.agents.override = stale
    supervisor.tick()
    assert supervisor.state["status"] == "needs_attention"
    assert "heartbeat" in supervisor.state["details"]


def test_stop_waits_for_remote_acknowledgement(supervisor):
    supervisor.state["status"] = "running"
    control.atomic(supervisor.home / "stop.json", {})
    supervisor.agents.override = lambda r: r.update(status="running")
    supervisor.tick()
    assert supervisor.state["status"] == "stopping"
    supervisor.agents.override = None
    supervisor.tick()
    assert supervisor.state["status"] == "stopped"
    assert [a[0] for a in supervisor.agents.actions] == ["stop", "stop"]


def test_scientific_changes_block_resume_but_logging_fix_is_allowed():
    before = {"experiments/training.py": "old", "colab/bootstrap.py": "old"}
    assert control.compatible(before, {**before, "colab/bootstrap.py": "new"}, True) == ["colab/bootstrap.py"]
    with pytest.raises(RuntimeError, match="Checkpoint compatibility"):
        control.compatible(before, {**before, "experiments/training.py": "new"}, True)
    with pytest.raises(RuntimeError, match="protected"):
        control.compatible(before, {**before, "colab/experiment_config.yaml": "changed"}, False)


def test_summary_requires_both_supplemental_runs(supervisor):
    supervisor.state["cursor"] = len(control.jobs()) - 1
    supervisor.agents.override = lambda r: r["runtime"]["evidence"]["progress"].update(measured_runs=1)
    supervisor.tick()
    assert supervisor.state["status"] == "needs_attention"


def test_silent_subprocess_can_be_stopped_and_secret_is_redacted(tmp_path, monkeypatch, capsys):
    module = tmp_path / "experiments"
    module.mkdir()
    (module / "__init__.py").write_text("")
    (module / "__main__.py").write_text("import os,time\nprint(os.environ['KAGGLE_API_TOKEN'],flush=True)\ntime.sleep(30)\n")
    secret = "fixture-do-not-leak-12345"
    monkeypatch.setenv("KAGGLE_API_TOKEN", secret)
    event = threading.Event()
    timer = threading.Timer(.5, event.set)
    timer.start()
    start = time.monotonic()
    try:
        with pytest.raises(InterruptedError):
            bootstrap.run_stage(sys.executable, tmp_path, "session.json", "prepare", stop_event=event)
    finally:
        timer.cancel()
    assert time.monotonic() - start < 8
    log = next((tmp_path / "logs").glob("*.log")).read_text(encoding="utf-8")
    assert "[REDACTED]" in log and secret not in log
    assert secret not in capsys.readouterr().out


def test_cache_shard_checksum_and_path_escape(tmp_path):
    config = control.experiment_config()
    config["drive_root"] = str(tmp_path)
    cache = tmp_path / "cache" / "fixture"
    cache.mkdir(parents=True)
    archive = cache / "part.tar"
    archive.write_bytes(b"cache fixture")
    shard = {"path": "part.tar", "sha256": runtime.digest(archive)}
    index = {"smoke": False, "settings": config["data"],
             "datasets": {d: {"complete": True, "shards": [copy.deepcopy(shard)]} for d in ("ffpp", "celebdf", "uadfv")}}
    runtime.atomic(cache / "index.json", index)
    runtime.atomic(tmp_path / "cache" / "active.json", {"index": "cache/fixture/index.json"})
    assert runtime.cached_index(config, verify=True)["complete"]
    archive.write_bytes(b"corrupt")
    with pytest.raises(RuntimeError, match="checksum"):
        runtime.cached_index(config, verify=True)
    index["datasets"]["ffpp"]["shards"][0]["path"] = "../../outside.tar"
    runtime.atomic(cache / "index.json", index)
    with pytest.raises(ValueError, match="path"):
        runtime.cached_index(config)


def test_browser_transport_rejects_soft_denial(supervisor, monkeypatch):
    class Result:
        returncode = 0
        stdout = json.dumps({"status": "SUCCESS", "response": "", "denied_actions": [{"action": "mcp"}]})
        stderr = "mcp was auto-denied"
    monkeypatch.setattr(control.subprocess, "run", lambda *a, **k: Result())
    monkeypatch.setattr(control, "find_executable", lambda name: "fixture")
    response = control.Agents(supervisor.home).browser("preflight", {"task_id": "preflight"}, {}, {})
    assert response["status"] == "needs_attention"
    assert "denied" in response["details"]


def test_bundle_must_match_current_source(tmp_path, monkeypatch):
    import zipfile
    project = tmp_path / "project"
    (project / "colab-bundle").mkdir(parents=True)
    (project / "experiments").mkdir()
    source = project / "experiments" / "sample.py"
    source.write_text("original")
    with zipfile.ZipFile(project / "colab-bundle" / "FA-ViT-CNN-Colab-E2E.zip", "w") as archive:
        archive.writestr("BUNDLE-MANIFEST.json", json.dumps({"experiments/sample.py": control.sha(source)}))
    source.write_text("changed after packaging")
    monkeypatch.setattr(control, "ROOT", project)
    with pytest.raises(RuntimeError, match="Source changed"):
        control.Supervisor(tmp_path / "state", agents=FakeAgents()).release()


def test_confirmed_runtime_loss_rebuilds_ephemeral_preparation(supervisor):
    supervisor.state["cursor"] = 3
    def lost(response):
        response.update(status="runtime_lost", runtime={"termination_confirmed": True, "termination_message": "Runtime was deleted"})
    supervisor.agents.override = lost
    supervisor.tick()
    assert supervisor.state["cursor"] == 0
    assert supervisor.state["generation"] == 1
    supervisor.agents.override = None
    supervisor.tick()
    assert supervisor.agents.actions[-1][0] == "recover"
    assert supervisor.state["cursor"] == 1
    assert supervisor.state["recovery_pending"] is None


def test_disconnect_without_termination_proof_cannot_start_second_gpu(supervisor):
    supervisor.agents.override = lambda r: r.update(status="runtime_lost", runtime={"termination_confirmed": False})
    supervisor.tick()
    assert supervisor.state["status"] == "needs_attention"
    assert "generation" not in supervisor.state


def test_runtime_recovery_refuses_active_worker_and_unproven_termination(tmp_path):
    config = {"drive_root": str(tmp_path)}
    with pytest.raises(ValueError, match="evidence"):
        runtime.recover(config, "old", {})
    class Active:
        def is_alive(self):
            return True
    old = runtime._STATE["active"]
    runtime._STATE["active"] = Active()
    try:
        with pytest.raises(RuntimeError, match="active"):
            runtime.recover(config, "old", {"termination_confirmed": True, "termination_message": "Runtime deleted"})
    finally:
        runtime._STATE["active"] = old


def test_colab_failure_bundle_is_persisted_and_redacted(tmp_path, monkeypatch):
    config = control.experiment_config()
    config["drive_root"] = str(tmp_path / "drive")
    project = tmp_path / "project"
    project.mkdir()
    token = "fixture-kaggle-token-never-log"
    monkeypatch.setenv("KAGGLE_API_TOKEN", token)
    monkeypatch.setattr(runtime, "gpu_proof", lambda: ["NVIDIA L4, GPU-fixture"])
    monkeypatch.setattr(runtime, "cached_index", lambda c: None)
    def fail(*args, **kwargs):
        log = tmp_path / "failure.log"
        log.write_text("HTTP 403 fixture " + token, encoding="utf-8")
        kwargs["on_log"](log)
        raise RuntimeError("Download failed " + token)
    monkeypatch.setattr(runtime.runpy, "run_path", lambda path: {"bootstrap_env": lambda *a: "fixture-python", "run_stage": fail})
    # Session configuration is a cache artifact; make /content resolve locally.
    real_path = runtime.Path
    monkeypatch.setattr(runtime, "Path", lambda value: tmp_path if str(value) == "/content" else real_path(value))
    task = {"task_id": "prepare-fixture", "stage": "prepare", "dataset": "ffpp", "bundle_sha256": "fixture-sha"}
    runtime._STOP.clear()
    runtime._work(task, config, project)
    failed = runtime.read(tmp_path / "drive" / "automation" / "errors" / "prepare-fixture.json")
    assert failed["status"] == "failed"
    assert "[REDACTED]" in failed["error"] and token not in json.dumps(failed)
    assert failed["config"]["sources"] == {}
    assert failed["gpu"] == ["NVIDIA L4, GPU-fixture"]
    assert runtime.status(config)["status"] == "failed"


def test_environment_setup_retains_actual_pip_failure(tmp_path, capsys):
    path = tmp_path / "bootstrap.log"
    with pytest.raises(RuntimeError, match="No matching distribution"):
        bootstrap.bootstrap_command([sys.executable, "-c", "import sys; print('No matching distribution fixture', file=sys.stderr); sys.exit(1)"], path)
    assert "No matching distribution" in path.read_text(encoding="utf-8")


def test_dataset_connection_error_waits_and_retries_without_code_repair(supervisor):
    supervisor.agents.fail_key = "prepare-ffpp"
    supervisor.agents.override = lambda r: r["runtime"].update(error="No reachable official FF++ mirror: Connection refused")
    supervisor.tick()
    assert supervisor.state["status"] == "retry_wait"
    assert not supervisor.agents.repairs
    calls = len(supervisor.agents.actions)
    supervisor.tick()
    assert len(supervisor.agents.actions) == calls
    supervisor.clock = lambda: 2000000061
    supervisor.agents.fail_key = None
    supervisor.agents.override = None
    supervisor.tick()
    assert supervisor.state["cursor"] == 1
    assert supervisor.state["generation"] == 1
