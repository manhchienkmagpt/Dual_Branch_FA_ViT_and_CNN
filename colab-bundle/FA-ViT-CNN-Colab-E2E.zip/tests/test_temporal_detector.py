"""Regression checks for the real MTCNN output format without loading weights."""
from types import SimpleNamespace

import numpy as np
import pytest

from experiments.temporal.preprocess import FaceDetector


def detect_with(output):
    detector = FaceDetector.__new__(FaceDetector)
    detector.model = SimpleNamespace(detect=lambda image, landmarks: output)
    return detector.detect(np.zeros((16, 16, 3), dtype=np.uint8))


@pytest.mark.parametrize("dtype", [object, np.float32, np.float64])
def test_mtcnn_numeric_and_object_arrays(dtype):
    boxes = np.array([[1, 2, 12, 14]], dtype=dtype)
    probabilities = np.array([.99], dtype=dtype)
    landmarks = np.array([[[3, 4], [9, 4], [6, 7], [4, 10], [8, 10]]], dtype=dtype)

    result = detect_with((boxes, probabilities, landmarks))

    assert len(result) == 1
    box, probability, points = result[0]
    np.testing.assert_allclose(box, boxes.astype(np.float32)[0])
    np.testing.assert_allclose(points, landmarks.astype(np.float32)[0])
    assert box.dtype == points.dtype == np.float32
    assert isinstance(probability, float)
    assert probability == pytest.approx(.99)


def test_mtcnn_no_faces():
    assert detect_with((None, [None], None)) == []


@pytest.mark.parametrize("field", [0, 1, 2])
@pytest.mark.parametrize("value", [np.nan, np.inf, -np.inf])
def test_mtcnn_filters_nonfinite_detections(field, value):
    output = [
        np.ones((2, 4), dtype=object),
        np.array([.99, .98], dtype=object),
        np.ones((2, 5, 2), dtype=object),
    ]
    output[field][0] = value

    result = detect_with(output)

    assert len(result) == 1
    assert result[0][1] == pytest.approx(.98)
