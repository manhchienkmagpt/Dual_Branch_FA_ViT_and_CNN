"""Protect the two-run selection and the unchanged scientific protocol."""
import copy
import json
import runpy
import shutil
import uuid
from pathlib import Path

import pytest
import yaml


ROOT = Path(__file__).resolve().parents[1]
BOOTSTRAP = runpy.run_path(str(ROOT / "colab" / "bootstrap.py"))


@pytest.fixture
def config():
    work = ROOT / "experiment-output" / f"supplemental-test-{uuid.uuid4().hex}"
    work.mkdir(parents=True)
    settings = yaml.safe_load((ROOT / "colab" / "experiment_config.yaml").read_text(encoding="utf-8"))
    settings["drive_root"] = str(work)
    try:
        yield settings
    finally:
        shutil.rmtree(work)


def test_notebook_all_selects_two_controls_and_preserves_previous_protocol(config):
    old = copy.deepcopy(config)
    old["training"].update(variants=["favit_linear", "favit_matched", "favit_cnn", "cnn_only", "favit_capacity"],
                           seeds=[42, 123, 2026])
    protocol = Path(config["drive_root"]) / "protocol.json"
    protocol.write_text(json.dumps(old), encoding="utf-8")
    calls = []
    bootstrap = {**BOOTSTRAP, "template_config": lambda *args: copy.deepcopy(config),
                 "run_stage": lambda *args, **kwargs: calls.append(args)}
    scope = {"bootstrap": bootstrap, "PYTHON": "fixture-python", "PROJECT": ROOT,
             "DRIVE_ROOT": config["drive_root"], "Path": Path, "json": json}
    notebook = json.loads((ROOT / "colab" / "02_run_experiments.ipynb").read_text(encoding="utf-8"))
    # Redirect the transient Colab session path into this test workspace.
    source = notebook["cells"][4]["source"].replace("/content/favit-training-session.json",
                                                    (Path(config["drive_root"]) / "session.json").as_posix())
    exec(source, scope)
    selected = scope["CONFIG"]
    assert selected["training"]["variants"] == ["favit_matched", "cnn_only"]
    assert selected["training"]["seeds"] == [42]
    assert selected["data"] == old["data"]
    unchanged = lambda t: {k: v for k, v in t.items() if k not in ("variants", "seeds")}
    assert unchanged(selected["training"]) == unchanged(old["training"])
    assert selected["data"]["train_frames"] == 20 and selected["data"]["eval_frames"] == 50
    assert selected["training"]["epochs"] == 30 and selected["training"]["early_stopping_patience"] == 5
    assert json.loads(protocol.read_text())["training"] == selected["training"]
    exec(notebook["cells"][6]["source"], scope)
    assert calls[-1][3:] == ("train", "--variant", "all", "--seed", "42")


@pytest.mark.parametrize("field", ["data", "training"])
def test_selection_migration_rejects_scientific_changes(config, field):
    BOOTSTRAP["freeze_protocol"](config)
    changed = copy.deepcopy(config)
    changed[field]["train_frames" if field == "data" else "epochs"] = 4
    with pytest.raises(RuntimeError, match="scientific protocol differs"):
        BOOTSTRAP["freeze_protocol"](changed)


def test_selection_migration_cannot_relabel_started_runs(config):
    old = copy.deepcopy(config)
    old["training"]["variants"] = ["favit_linear"]
    BOOTSTRAP["freeze_protocol"](old)
    state = Path(config["drive_root"]) / "runs" / "favit_linear" / "seed-42" / "state.json"
    state.parent.mkdir(parents=True)
    state.write_text('{}')
    with pytest.raises(RuntimeError, match="selection changed after training"):
        BOOTSTRAP["freeze_protocol"](config)


@pytest.mark.parametrize("measured", [1, 2, 15])
def test_runtime_requires_exactly_the_configured_two_runs(config, measured):
    runtime = runpy.run_path(str(ROOT / "colab" / "autopilot_runtime.py"))
    folder = Path(config["drive_root"]) / "summaries"
    folder.mkdir()
    (folder / "progress.json").write_text(json.dumps({"complete": True, "smoke": False,
                                                       "measured_runs": measured, "expected_runs": 2}))
    if measured == 2:
        assert runtime["evidence"]({"stage": "summarize"}, config)["progress"]["measured_runs"] == 2
    else:
        with pytest.raises(RuntimeError, match="not complete"):
            runtime["evidence"]({"stage": "summarize"}, config)
