"""Real synthetic train/evaluate/export/resume for the extended priority runner."""
import copy
import json
from pathlib import Path
import runpy

import pytest
import torch

from experiments.common import ROOT, load_config, read_json, scratch_directory, atomic_json
from experiments.cache import preprocess, cache_info
from experiments.data import prepare
from experiments.models import build_experiment_model
from experiments.smoke import TinyEncoder, create_fixture


runner = runpy.run_path(str(ROOT / "colab" / "run_supplemental_suite.py"))


@pytest.fixture
def config():
    torch.set_num_threads(2)
    with scratch_directory(ROOT / "experiment-output", "supplemental-runner-test-") as work:
        config = load_config(create_fixture(work / "fixture"))
        config["training"]["variants"] = ["favit_matched", "cnn_only"]
        config["training"]["seeds"] = [42]
        config["evaluation"]["bootstrap_reps"] = 20
        prepare(config)
        preprocess(config)
        yield config


def factory(config, calls):
    def build(variant, seed):
        calls.append((variant, seed))
        return build_experiment_model(variant, config, seed, pretrained=False, encoder_factory=TinyEncoder)
    return build


def test_priority_plan():
    jobs = runner["plan"]()
    assert [(j["variant"], j["seed"]) for j in jobs[:4]] == [
        ("favit_matched", 42), ("cnn_only", 42), ("favit_capacity", 42), ("favit_cnn", 42)]
    assert len(jobs) == 8 and len(runner["plan"]("multiseed")) == 4
    assert len({j["id"] for j in jobs}) == 8


def test_json_export_recovers_from_transient_replace_lock(config, monkeypatch):
    evidence = runner["Evidence"](config)
    original = runner["Evidence"].save.__globals__["atomic_json"]
    calls = []
    def briefly_locked(path, value):
        calls.append(path)
        if len(calls) < 3:
            raise PermissionError("fixture: temporary Windows read handle")
        original(path, value)
    monkeypatch.setitem(runner["Evidence"].save.__globals__, "atomic_json", briefly_locked)
    evidence.save("timing.json", {"epochs": [{"epoch": 1, "seconds": 2.5}]})
    assert read_json(evidence.root / "timing.json") == {"epochs": [{"epoch": 1, "seconds": 2.5}]}
    assert len(calls) == 3


def test_all_jobs_json_resume_and_corruption_detection(config):
    original = copy.deepcopy(config)
    calls = []
    result = runner["run"](config, max_hours=0, model_factory=factory(config, calls))
    assert result["complete"] and len(result["completed"]) == 8
    assert config == original
    observed = list(dict.fromkeys(calls))
    assert observed == [(j["variant"], j["seed"]) for j in runner["plan"]()]
    root = Path(config["drive_root"]) / "supplemental"
    evidence = read_json(root / "paper-results.json")
    assert len(evidence["run_results"]) == 8
    assert all(r["status"] == "completed" and r["smoke"] for r in evidence["run_results"])
    assert all(r["video_predictions"] and r["metrics"] and r["artifacts"]["best.pt"]["sha256"]
               for r in evidence["run_results"])
    assert read_json(root / "ensembles/seed-42.json")["status"] == "measured"
    stats = read_json(root / "comparisons.json")
    primary = [r for r in stats["paired_bootstrap"] if r["reference"] == "favit_matched"]
    assert all(r["seeds"] == [42, 123, 2026] and r["paired_seeds"] == 3 for r in primary)
    assert all(r["status"] in ("ok", "insufficient_groups") for r in primary)
    # One-seed CNN/capacity controls have unknown across-seed SD, not zero.
    assert all(r["auc"]["sample_std"] is None for r in evidence["metrics_across_seeds"]
               if r["variant"] in ("cnn_only", "favit_capacity"))
    timing = read_json(root / "timing.json")
    assert len(timing["epochs"]) == 16
    calls.clear()
    second = runner["run"](config, max_hours=0, model_factory=factory(config, calls))
    assert second["complete"] and calls == []
    assert read_json(root / "timing.json")["epochs"] == timing["epochs"]
    csv = Path(config["drive_root"]) / "runs/favit_matched/seed-42/evaluation/frame-predictions.csv"
    csv.write_text("corrupt CSV")
    runner["Evidence"](config).export("exported")
    invalid = read_json(root / "runs/favit_matched-seed-42.json")
    assert invalid["status"] == "invalid" and not invalid["metrics"]
    assert read_json(root / "ensembles/seed-42.json")["status"] == "missing_paired_run"
    # Every JSON file is standards-compliant; no NaN or Infinity placeholders.
    def invalid_constant(value):
        raise AssertionError(value)
    for path in root.rglob("*.json"):
        json.loads(path.read_text(encoding="utf-8"), parse_constant=invalid_constant)


def test_budget_preserves_partial_epoch_status(config):
    ticks = iter(range(100))
    result = runner["run"](config, max_hours=3.5 / 3600,
                           model_factory=factory(config, []), clock=lambda: next(ticks))
    assert result["status"] == "budget_exhausted" and not result["complete"]
    root = Path(config["drive_root"]) / "supplemental"
    first = read_json(root / "runs/favit_matched-seed-42.json")
    assert first["status"] == "interrupted" and len(first["history"]) == 1 and not first["metrics"]
    assert not (Path(config["drive_root"]) / "runs/cnn_only").exists()


def test_missing_dataset_is_blocked_with_json(config):
    cache, index = cache_info(config)
    index["datasets"]["celebdf"]["complete"] = False
    atomic_json(cache / "index.json", index)
    with pytest.raises(ValueError, match="Complete caches required: celebdf"):
        runner["run"](config, model_factory=factory(config, []))
    root = Path(config["drive_root"]) / "supplemental"
    assert read_json(root / "failure.json")["status"] == "blocked"
    assert read_json(root / "progress.json")["status"] == "blocked"
    assert not read_json(root / "paper-results.json")["metrics_per_seed"]


def test_preprocessing_cannot_silently_change(config):
    config["data"]["eval_frames"] = 10
    with pytest.raises(ValueError, match="Frozen preprocessing settings differ: eval_frames"):
        runner["run"](config, model_factory=factory(config, []))


def test_unverified_historical_checkpoint_is_preserved(config):
    folder = Path(config["drive_root"]) / "runs/favit_matched/seed-42"
    folder.mkdir(parents=True)
    weights = folder / "best.pt"
    weights.write_bytes(b"historical weights; missing provenance")
    with pytest.raises(ValueError, match="unverified artifacts"):
        runner["run"](config, model_factory=factory(config, []))
    assert weights.read_bytes() == b"historical weights; missing provenance"


def test_runtime_lock_releases_after_exception(config):
    with pytest.raises(ValueError):
        with runner["execution_lock"](config):
            with pytest.raises(RuntimeError, match="Another supplemental runner"):
                with runner["execution_lock"](config):
                    pass
            raise ValueError("fixture")
    with runner["execution_lock"](config):
        pass
