"""Behavioral checks for the CPU-first video protocol and its model contrasts."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import runpy
import subprocess
import sys
import zipfile

import numpy as np
import pytest
import torch

from experiments.common import ROOT, atomic_json, fingerprint, read_json, scratch_directory, sha256
from experiments.temporal import VARIANTS
from experiments.temporal.config import freeze_protocol, load_config, run_folder
from experiments.temporal.data import prepare
from experiments.temporal.dataset import select_clips, transform_clip
from experiments.temporal.folds import roles, split_rows
from experiments.temporal.preprocess import SyntheticFaceDetector, clip_starts, materialize, preprocess
from experiments.temporal.reporting import aggregate, binary_metrics, summarize
from experiments.temporal.smoke import create_fixture, factory_for
from experiments.temporal.training import calibration, device_for, evaluate_one, train_one


@pytest.fixture
def work():
    torch.set_num_threads(2)
    with scratch_directory(ROOT / "experiment-output", "temporal-test-") as path:
        yield path


@pytest.fixture
def config(work):
    return load_config(create_fixture(work / "fixture"))


def test_rotation_groups_and_preparation_are_repeatable(config):
    prepare(config); prepare(config)
    from experiments.temporal.data import load_manifest
    rows, _ = load_manifest(config, "ffpp")
    assert len(rows) == 70
    assert roles(1) == {"train": list(range(1, 9)), "val": [9], "test": [10]}
    assert roles(10) == {"train": [10, 1, 2, 3, 4, 5, 6, 7], "val": [8], "test": [9]}
    appearances = {r["video_id"]: [] for r in rows}
    for fold in range(1, 11):
        groups = [{r["group_id"] for r in split_rows(rows, fold, split)} for split in ("train", "val", "test")]
        assert not groups[0] & groups[1] and not groups[0] & groups[2] and not groups[1] & groups[2]
        for split in ("train", "val", "test"):
            for row in split_rows(rows, fold, split):
                appearances[row["video_id"]].append(split)
    assert all(v.count("train") == 8 and v.count("val") == 1 and v.count("test") == 1 for v in appearances.values())


def test_prepare_resume_reuses_verification_without_reopening_videos(config, monkeypatch):
    from experiments.temporal import data
    prepare(config, ["ffpp"])
    _, before = data.load_manifest(config, "ffpp")
    def forbidden(path):
        raise AssertionError("Unchanged video was decoded again")
    monkeypatch.setattr(data, "check_video", forbidden)
    prepare(config, ["ffpp"])
    assert data.load_manifest(config, "ffpp")[1]["sha256"] == before["sha256"]


def test_interrupted_verification_keeps_finished_files(config, monkeypatch):
    from experiments.temporal import data
    original = data.check_video
    calls = []
    def interrupted(path):
        calls.append(path)
        if len(calls) == 2:
            raise KeyboardInterrupt()
        return original(path)
    monkeypatch.setattr(data, "check_video", interrupted)
    with pytest.raises(KeyboardInterrupt):
        prepare(config, ["ffpp"])
    ledger = read_json(Path(config["drive_root"])/"temporal-manifests/verification-ffpp.json")
    assert len(ledger["files"]) == 1
    calls.clear()
    def resumed(path):
        calls.append(path)
        return original(path)
    monkeypatch.setattr(data, "check_video", resumed)
    prepare(config, ["ffpp"])
    assert len(calls) == 69


def test_resume_downloads_missing_video_before_decoding_existing_ones(config, work, monkeypatch):
    from experiments.temporal import data
    from experiments.data import build_ffpp_manifest as actual_builder
    missing = next((Path(config["drive_root"])/"raw/ffpp/Deepfakes").glob("*.mp4"))
    saved = missing.read_bytes(); missing.unlink()
    script = work/"downloader.py"; script.write_text("# fixture downloader\n")
    config["smoke"] = False
    config["sources"]["ffpp"] = {"script": str(script), "accepted_terms": True}
    events = []
    def builder(root, splits, smoke=False, **kwargs):
        assert kwargs.get("digest") is not None
        if not missing.exists():
            raise ValueError("Fixture video is missing")
        return actual_builder(root, splits, True, **kwargs)
    def download(*args):
        events.append("download")
        missing.write_bytes(saved)
    original = data.check_video
    def checker(path):
        events.append("decode")
        return original(path)
    monkeypatch.setattr(data, "build_ffpp_manifest", builder)
    monkeypatch.setattr(data, "download_ffpp", download)
    monkeypatch.setattr(data, "check_video", checker)
    prepare(config, ["ffpp"])
    assert events[0] == "download" and events.count("decode") == 70


def test_changed_video_is_rehashed_and_frozen_manifest_rejects_change(config):
    import os
    prepare(config, ["ffpp"])
    path = next((Path(config["drive_root"])/"raw/ffpp/original").glob("*.mp4"))
    with path.open("ab") as stream:
        stream.write(b"changed trailing bytes")
    os.utime(path, None)
    with pytest.raises(ValueError, match="Frozen ffpp videos changed"):
        prepare(config, ["ffpp"])


def test_incomplete_video_is_retained_repaired_and_good_files_are_not_decoded_twice(config, work, monkeypatch):
    from experiments.temporal import data
    from experiments.data import build_ffpp_manifest as actual_builder
    damaged = next((Path(config["drive_root"])/"raw/ffpp/original").glob("*.mp4"))
    saved = damaged.read_bytes(); damaged.write_bytes(b"broken mp4")
    script = work/"downloader.py"; script.write_text("# fixture\n")
    config["smoke"] = False
    config["sources"]["ffpp"] = {"script": str(script), "accepted_terms": True}
    def builder(root, splits, smoke=False, **kwargs):
        return actual_builder(root, splits, True, **kwargs)
    downloads, decoded = [], []
    def download(*args):
        downloads.append(True)
        damaged.write_bytes(saved)
    original = data.check_video
    def checker(path):
        assert Path(path).is_relative_to(Path(config["local_root"]))
        decoded.append(path)
        return original(path)
    monkeypatch.setattr(data, "build_ffpp_manifest", builder)
    monkeypatch.setattr(data, "download_ffpp", download)
    monkeypatch.setattr(data, "check_video", checker)
    prepare(config, ["ffpp"])
    assert len(downloads) == 1 and len(decoded) == 71
    assert damaged.read_bytes() == saved
    retained = list(damaged.parent.glob(damaged.name+".incomplete-*"))
    assert len(retained) == 1 and retained[0].read_bytes() == b"broken mp4"


def test_temporal_stage_logs_start_even_when_worker_is_silent(work, capsys):
    project = work/"silent-worker"
    package = project/"experiments/temporal"
    package.mkdir(parents=True)
    (project/"experiments/__init__.py").write_text("")
    (package/"__init__.py").write_text("")
    (package/"__main__.py").write_text("# successful worker without stdout\n")
    bootstrap = runpy.run_path(str(ROOT/"colab/bootstrap.py"))
    bootstrap["run_stage"](sys.executable, project, "fixture.json", "prepare",
                            drive_root=work/"drive", module="experiments.temporal")
    assert "Drive log opened successfully" in capsys.readouterr().out
    log = next((work/"drive/logs").glob("*.log"))
    assert "Starting experiments.temporal stage=prepare" in log.read_text()


def test_late_manual_zip_verification_preserves_existing_ffpp_cache(config, work):
    from experiments.smoke import make_video
    prepare(config); preprocess(config)
    identity = materialize(config, "ffpp")[1]
    raw = work/"late/wrapper"
    make_video(raw/"Celeb-real/real.mp4", frames=3)
    make_video(raw/"Celeb-synthesis/fake.mp4", fake=True, frames=3)
    (raw/"List_of_testing_videos.txt").write_text("1 Celeb-real/real.mp4\n0 Celeb-synthesis/fake.mp4\n")
    archive = work/"late.zip"
    with zipfile.ZipFile(archive, "w") as packed:
        for path in raw.rglob("*"):
            if path.is_file():
                packed.write(path, path.relative_to(raw.parent))
    config["sources"]["celebdf"] = {"archive": str(archive)}
    prepare(config, ["celebdf"]); preprocess(config, ["celebdf"])
    assert materialize(config, "ffpp")[1] == identity
    assert len(materialize(config, "celebdf")[0]) == 4


def test_prepare_and_doctor_with_torch_import_blocked(config, work):
    config_path = work / "fixture/config.yaml"
    source = r'''
import importlib.abc, sys
class RejectTorch(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in ('torch','torchvision','timm','facenet_pytorch'):
            raise AssertionError('Acquisition imported forbidden ML dependency: '+fullname)
sys.meta_path.insert(0, RejectTorch())
from experiments.temporal.__main__ import main
for stage in ['doctor','prepare']:
    sys.argv=['temporal',stage,'--config',sys.argv[1]] if len(sys.argv)==2 else ['temporal',stage,'--config',config_path]
    config_path=sys.argv[-1]
    main()
assert 'torch' not in sys.modules
'''
    result = subprocess.run([sys.executable, "-c", source, str(config_path)], cwd=ROOT, capture_output=True, text=True)
    assert result.returncode == 0, result.stdout+result.stderr


def test_acquisition_bootstrap_installs_no_torch_or_cuda(work, monkeypatch):
    bootstrap = runpy.run_path(str(ROOT/"colab/bootstrap.py"))
    function = bootstrap["bootstrap_env"]
    globals_ = function.__globals__
    project = work / "project"
    (project / "colab").mkdir(parents=True)
    (project/"colab/requirements-acquisition.txt").write_text("PyYAML==6.0.2\n")
    actual_path = Path
    def redirected(path):
        if str(path) == "/content":
            return work / "content"
        return actual_path(path)
    commands = []
    def command(args, log):
        commands.append(args)
        if "venv" in args:
            Path(args[-1]).mkdir(parents=True, exist_ok=True)
    monkeypatch.setitem(globals_, "Path", redirected)
    monkeypatch.setitem(globals_, "bootstrap_command", command)
    monkeypatch.setattr(globals_["shutil"], "which", lambda name: None)
    python = function(project, "acquisition", device="cpu")
    assert "acquisition-cpu" in python
    assert not any("torch==" in str(c) or "download.pytorch.org" in str(c) for c in commands)
    assert not any("assert torch.cuda" in str(c) for c in commands)


def test_clip_contiguity_sync_augmentation_and_cache_repair(config):
    prepare(config); preprocess(config)
    clips, identity = materialize(config, "ffpp")
    first = clips[0]
    indices = [r["frame_index"] for r in first["frames"]]
    assert indices == list(range(indices[0], indices[0]+config["data"]["clip_length"]))
    # Identical source frames must receive identical geometry/colour/JPEG parameters.
    sample = transform_clip([first["paths"][0]]*2, True, seed=42)
    assert torch.equal(sample[0], sample[1])
    chosen = select_clips(clips, True, 42, 1, 1)
    assert len({c["video_id"] for c in chosen}) == len(chosen)
    assert clip_starts(1, 8, 8) == []
    base = Path(config["drive_root"])/"temporal-cache/ffpp"
    index_path = base/read_json(base/"active.json")["index"]
    before = [s["sha256"] for s in read_json(index_path)["shards"]]
    broken = index_path.parent/read_json(index_path)["shards"][0]["path"]
    broken.write_bytes(b"incomplete upload")
    with pytest.raises(ValueError, match="Corrupt Drive cache"):
        # A new local root forces verification rather than using an already restored copy.
        different = copy.deepcopy(config); different["local_root"] += "-new-session"
        materialize(different, "ffpp")
    preprocess(config, ["ffpp"])
    assert [s["sha256"] for s in read_json(index_path)["shards"]][1:] == before[1:]
    assert materialize(config, "ffpp")[0]


def test_no_valid_clip_stops_without_padding(config):
    config["data"]["clip_length"] = 8
    prepare(config)
    with pytest.raises(ValueError, match="no valid consecutive clip"):
        preprocess(config, ["ffpp"])


def test_explicit_exclusion_resumes_legacy_cache_without_reprocessing_and_reaches_uadfv(config, monkeypatch):
    from experiments.temporal import preprocess as module
    from experiments.temporal.data import load_manifest
    from experiments.temporal.exclusions import register_exclusion
    prepare(config)
    rows, manifest = load_manifest(config, "ffpp")
    rejected_id = rows[0]["video_id"]
    original = module.process_video

    def one_failure(row, *args):
        if row["video_id"] == rejected_id:
            return [], {"video_id": rejected_id, "valid_clips": 0, "status": "NO_VALID_CLIP"}
        return original(row, *args)

    monkeypatch.setattr(module, "process_video", one_failure)
    with pytest.raises(ValueError, match="1 videos have no valid"):
        preprocess(config)
    base = Path(config["drive_root"]) / "temporal-cache/ffpp"
    index_path = base / read_json(base / "active.json")["index"]
    index = read_json(index_path)
    assert not (base.parent / "uadfv/active.json").exists()

    # Reproduce the exact pre-fix identity without changing the TAR payloads.
    index["preprocessing"]["implementation"] = next(iter(module.COMPATIBLE_IMPLEMENTATIONS))
    index["identity"] = fingerprint({"manifest": manifest["sha256"],
                                     "preprocessing": fingerprint(index["preprocessing"])})
    legacy_folder = base / index["identity"][:20]
    index_path.parent.rename(legacy_folder)
    index_path = legacy_folder / "index.json"
    for record in index["shards"]:
        record["identity"] = index["identity"]
        atomic_json((legacy_folder / record["path"]).with_suffix(".json"), record)
    atomic_json(index_path, index)
    atomic_json(base / "active.json", {"index": f"{legacy_folder.name}/index.json"})
    before = {r["path"]: sha256(legacy_folder / r["path"]) for r in index["shards"]}
    register_exclusion(config, "ffpp", rejected_id, "Author approved: no valid consecutive clip")

    def reject_ffpp_reprocessing(row, *args):
        assert row["dataset"] != "ffpp", "A saved FF++ shard was unnecessarily reprocessed"
        return original(row, *args)

    monkeypatch.setattr(module, "process_video", reject_ffpp_reprocessing)
    preprocess(config)
    completed = read_json(index_path)
    assert completed["complete"] and completed["included_videos"] == 69
    assert completed["source_videos"] == 70
    assert before == {r["path"]: sha256(legacy_folder / r["path"]) for r in completed["shards"]}
    clips, _ = materialize(config, "ffpp")
    assert {c["video_id"] for c in clips} == {r["video_id"] for r in rows} - {rejected_id}
    assert len({c["video_id"] for c in materialize(config, "uadfv")[0]}) == 4
    summarize(config)
    report = read_json(Path(config["drive_root"]) / "temporal-summaries/results.json")
    assert report["coverage"]["ffpp"]["included_videos"] == 69
    assert report["coverage"]["ffpp"]["excluded_videos"][0]["video_id"] == rejected_id


def test_excluded_video_has_no_train_or_oof_predictions(config):
    from experiments.temporal.data import load_manifest
    from experiments.temporal.exclusions import register_exclusion
    variant = "favit_clip"
    config["training"]["variants"] = [variant]
    prepare(config)
    rows, _ = load_manifest(config, "ffpp")
    rejected_id = rows[0]["video_id"]
    register_exclusion(config, "ffpp", rejected_id, "Author approved coverage exclusion")
    preprocess(config)
    clips, identity = materialize(config, "ffpp")
    assert rejected_id not in {c["video_id"] for c in clips}
    factory = factory_for(config)
    calibration(config, factory)
    for fold in range(1, 11):
        train_one(config, variant, fold, clips, identity, factory)
        evaluate_one(config, variant, fold, "ffpp", clips, identity, factory)
    report = summarize(config)[0]
    assert report["oof_complete"]
    assert report["oof_video_metrics"]["samples"] == 69


def test_exclusions_do_not_hide_other_failures_and_reject_unknown_or_changed_policy(config, monkeypatch):
    from experiments.temporal.data import load_manifest
    from experiments.temporal.exclusions import exclusion_path, register_exclusion
    prepare(config)
    rows, _ = load_manifest(config, "ffpp")
    register_exclusion(config, "ffpp", rows[0]["video_id"], "Approved exclusion")
    with pytest.raises(ValueError, match="frozen manifest"):
        register_exclusion(config, "ffpp", "ffpp/Deepfakes/not-a-video", "Typo")
    from experiments.temporal import preprocess as module
    original = module.process_video
    def another_failure(row, *args):
        if row["video_id"] == rows[1]["video_id"]:
            return [], {"video_id": row["video_id"], "valid_clips": 0}
        return original(row, *args)
    monkeypatch.setattr(module, "process_video", another_failure)
    with pytest.raises(ValueError, match="1 videos have no valid"):
        preprocess(config, ["ffpp"])
    monkeypatch.setattr(module, "process_video", original)
    preprocess(config, ["ffpp"])
    assert len({c["video_id"] for c in materialize(config, "ffpp")[0]}) == 69
    register_exclusion(config, "ffpp", rows[2]["video_id"], "Second explicit exclusion")
    with pytest.raises(ValueError, match="Exclusions changed"):
        materialize(config, "ffpp")
    preprocess(config, ["ffpp"])
    assert len({c["video_id"] for c in materialize(config, "ffpp")[0]}) == 68
    path = exclusion_path(config, "ffpp")
    record = read_json(path); record["source_manifest_sha256"] = "wrong"
    atomic_json(path, record)
    with pytest.raises(ValueError, match="do not match"):
        preprocess(config, ["ffpp"])


@pytest.mark.parametrize("variant", VARIANTS)
def test_model_shapes_and_gradients(config, variant):
    model = factory_for(config)(variant).train()
    output = model(torch.randn(2, 2, 3, 224, 224))
    assert output.shape == (2,)
    output.square().sum().backward()
    assert all(p.grad is None and not p.requires_grad for p in model.encoder.vit.parameters())
    assert any(p.grad is not None and p.grad.abs().sum() > 0 for p in model.encoder.adapter.parameters())
    if model.has_temporal:
        assert model.temporal.project.weight.grad.abs().sum() > 0
    if model.has_patch:
        assert model.fusion.attention.in_proj_weight.grad.abs().sum() > 0
    with pytest.raises(ValueError, match="Expected"):
        model(torch.randn(2, 3, 224, 224))


def test_no_temporal_variants_are_frame_permutation_invariant(config):
    image = torch.randn(1, 2, 3, 224, 224)
    for variant in ("favit_clip", "favit_cnn_clip", "favit_cnn_no_temporal"):
        model = factory_for(config)(variant).eval()
        with torch.no_grad():
            assert torch.allclose(model(image), model(image.flip(1)), atol=1e-6)


def test_resume_checkpoint_integrity_and_late_archive(config, work):
    prepare(config); preprocess(config)
    clips, identity = materialize(config, "ffpp"); factory = factory_for(config)
    calibration(config, factory)
    variant = "favit_cnn_temporal"
    train_one(config, variant, 1, clips, identity, factory, epoch_limit=1)
    folder = run_folder(config, variant, 1)
    assert read_json(folder/"state.json")["status"] == "interrupted"
    train_one(config, variant, 1, clips, identity, factory)
    assert read_json(folder/"state.json")["epoch"] == 2
    assert len(read_json(folder/"history.json")) == 2
    report = evaluate_one(config, variant, 1, "ffpp", clips, identity, factory)
    assert report["video"]["samples"] == 7
    prediction_file = folder/"predictions-ffpp-videos.csv"
    prediction_file.write_text("damaged export", encoding="utf-8")
    with pytest.raises(ValueError, match="checksum mismatch"):
        summarize(config)
    evaluate_one(config, variant, 1, "ffpp", clips, identity, factory)
    assert sha256(prediction_file) == read_json(folder/"metrics-ffpp.json")["prediction_checksums"]["videos"]
    saved = sha256(folder/"best.pt")
    config["sources"]["celebdf"] = {"archive": str(work/"not-uploaded.zip")}
    freeze_protocol(config)
    with pytest.raises(FileNotFoundError, match="Upload"):
        prepare(config, ["celebdf"])
    assert materialize(config, "ffpp")[1] == identity
    assert sha256(folder/"best.pt") == saved
    (folder/"best.pt").write_bytes(b"broken")
    with pytest.raises(ValueError, match="corrupt"):
        train_one(config, variant, 1, clips, identity, factory)


def test_production_never_falls_back_to_cpu(config, monkeypatch):
    config["smoke"] = False
    monkeypatch.setattr(torch.cuda, "is_available", lambda: False)
    with pytest.raises(RuntimeError, match="Enable a GPU"):
        device_for(config)


def test_metrics_match_sklearn_and_keep_video_units():
    from sklearn.metrics import roc_auc_score
    y = [0, 0, 1, 1, 0, 1]; p = [.1, .5, .5, .9, .4, .4]
    result = binary_metrics(y, p)
    assert result["auc"] == pytest.approx(roc_auc_score(y, p))
    rows = [dict(dataset="ffpp", video_id="a", clip_id=str(i), label=0, group_id="pair", partition=1,
                 method="original", probability=value) for i, value in enumerate([.2, .8])]
    assert aggregate(rows)[0]["probability"] == .5
    with pytest.raises(ValueError, match="Duplicate"):
        aggregate(rows+rows)


def test_notebook_is_cpu_first_gated_and_celebdf_last():
    notebook = json.loads((ROOT/"colab/FA_ViT_CNN_10Fold.ipynb").read_text(encoding="utf-8"))
    assert "accelerator" not in notebook["metadata"] and "gpuType" not in notebook["metadata"]["colab"]
    cells = notebook["cells"]
    assert "RUN_STAGE == 'celebdf'" in cells[-1]["source"]
    source = "\n".join(c["source"] for c in cells if c["cell_type"] == "code")
    assert "RUN_STAGE = 'download'" in source and "stage, *arguments" in source
    assert "CELEBDF_ZIP_URL" not in source
    assert "'acquisition', device='cpu'" in source
    for cell in cells:
        if cell["cell_type"] == "code":
            ast.parse(cell["source"])
            assert cell["outputs"] == []


def upgrade_fixture(config, work):
    prepare(config); preprocess(config)
    upgraded = copy.deepcopy(config)
    upgraded["cache_root"] = config["drive_root"]
    upgraded["drive_root"] = str(work / "smoke-upgrade")
    upgraded["training"].update(strategy="balanced_v2", label_smoothing=0., head_dropout=.1,
                                backbone_lr=1e-5, head_lr=3e-4, finetune_blocks=2,
                                augmentation_warmup_epochs=2)
    return upgraded


def test_balanced_batches_have_both_classes_and_training_only_samples(config):
    from experiments.temporal.dataset import BalancedBatchSampler, loader
    prepare(config); preprocess(config)
    clips, _ = materialize(config, "ffpp")
    train = split_rows(clips, 1, "train")
    config["training"].update(strategy="balanced_v2", label_smoothing=0.)
    batches = loader(train, config, True, 1, 2)
    seen = set()
    for images, labels, indices in batches:
        assert sorted(labels.tolist()) == [0., 1.]
        assert images.shape[1:] == (2, 3, 224, 224)
        seen.update(batches.dataset.rows[i]["video_id"] for i in indices.tolist())
    assert seen <= {r["video_id"] for r in train}
    assert not seen & {r["video_id"] for r in split_rows(clips, 1, "val")}
    rows = batches.dataset.rows
    assert list(BalancedBatchSampler(rows, 2, 42)) == list(BalancedBatchSampler(rows, 2, 42))
    assert list(BalancedBatchSampler(rows, 2, 42)) != list(BalancedBatchSampler(rows, 2, 43))


def test_upgrade_reuses_readonly_cache_diagnoses_trains_and_resumes(config, work, capsys):
    from experiments.temporal.upgrade import diagnose, pilot
    from experiments.temporal.exclusions import register_exclusion
    upgraded = upgrade_fixture(config, work)
    cache_files = {str(p): sha256(p) for p in Path(config["drive_root"]).rglob("*") if p.is_file()}
    factory = factory_for
    diagnostic = diagnose(upgraded, "favit_clip", 1, steps=8, factory=factory(upgraded))
    assert diagnostic["passed_gradient_update_checks"] and diagnostic["head_max_abs_change"] > 0
    assert len(diagnostic["video_ids"]) <= 16
    history = pilot(upgraded, "favit_clip", 1, epochs=1, factory=factory(upgraded))
    assert history[-1]["epoch"] == 1 and history[-1]["train"]["gradient_norm_mean"] > 0
    assert "balanced_accuracy" in history[-1]["validation_video"]
    clips, identity = materialize(upgraded, "ffpp")
    train_one(upgraded, "favit_clip", 1, clips, identity, factory(upgraded))
    assert read_json(run_folder(upgraded, "favit_clip", 1)/"history.json")[-1]["epoch"] == 2
    assert cache_files == {str(p): sha256(p) for p in Path(config["drive_root"]).rglob("*") if p.is_file()}
    for call in (lambda: prepare(upgraded), lambda: preprocess(upgraded),
                 lambda: register_exclusion(upgraded, "ffpp", "invalid", "reason")):
        with pytest.raises(ValueError, match="read-only"):
            call()
    output = capsys.readouterr().out
    assert "validation video AUC=" in output and "checkpoint committed:" in output


def test_upgrade_enables_only_last_two_real_vit_blocks_and_removes_batchnorm(config):
    from experiments.temporal.models import build_model
    from experiments.temporal.training import make_optimizer
    config["training"].update(strategy="balanced_v2", finetune_blocks=2,
                                backbone_lr=1e-5, head_lr=3e-4)
    model = build_model(config, "favit_clip", pretrained=False)
    assert not any(p.requires_grad for block in model.encoder.vit.blocks[:-2] for p in block.parameters())
    assert all(p.requires_grad for block in model.encoder.vit.blocks[-2:] for p in block.parameters())
    assert not any(isinstance(module, torch.nn.BatchNorm2d) for module in model.modules())
    optimizer = make_optimizer(model, config["training"])
    assert {g["name"]: g["lr"] for g in optimizer.param_groups} == {
        "backbone": 1e-5, "adapters": 1e-4, "heads": 3e-4}
    model(torch.randn(1, 2, 3, 224, 224)).sum().backward()
    assert model.encoder.vit.blocks[-1].attn.qkv.weight.grad.abs().sum() > 0
    assert model.encoder.vit.blocks[0].attn.qkv.weight.grad is None
