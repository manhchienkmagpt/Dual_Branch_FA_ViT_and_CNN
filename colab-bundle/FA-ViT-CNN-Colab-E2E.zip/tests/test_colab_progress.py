"""Exercise notebook progress with real carriage-return subprocess output."""
import runpy
import shutil
import sys
import types
import uuid
from pathlib import Path

import pytest


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def work():
    path = ROOT / "experiment-output" / f"progress-test-{uuid.uuid4().hex}"
    path.mkdir(parents=True)
    try:
        yield path
    finally:
        shutil.rmtree(path)


@pytest.mark.parametrize("exit_code", [0, 7])
def test_notebook_reuses_one_display_per_download(work, monkeypatch, capsys, exit_code):
    displays = []

    class Handle:
        def __init__(self, content):
            self.updates = [content]

        def update(self, content):
            self.updates.append(content)

    def display(content, display_id):
        assert display_id is True
        handle = Handle(content)
        displays.append(handle)
        return handle

    ipython = types.ModuleType("IPython")
    ipython.get_ipython = lambda: types.SimpleNamespace(kernel=object())
    rich = types.ModuleType("IPython.display")
    rich.HTML, rich.display = str, display
    monkeypatch.setitem(sys.modules, "IPython", ipython)
    monkeypatch.setitem(sys.modules, "IPython.display", rich)
    monkeypatch.setenv("KAGGLE_API_TOKEN", "fixture-secret-12345")
    module = work / "experiments"
    module.mkdir()
    (module / "__init__.py").write_text("")
    (module / "__main__.py").write_text(
        "import os,sys\n"
        "for method in ['original','Deepfakes']:\n"
        " print('Official FF++ download/resume: ' + method + ', server=EU2', flush=True)\n"
        " for n in [0,10,100]:\n"
        "  sys.stderr.write(f'\\r{n:3d}%|###| {n}/100 [00:01<00:02, 2it/s]')\n"
        "  sys.stderr.flush()\n"
        " sys.stderr.write('\\n')\n"
        "print('<error> ' + os.environ['KAGGLE_API_TOKEN'], flush=True)\n"
        f"sys.exit({exit_code})\n", encoding="utf-8")
    run_stage = runpy.run_path(str(ROOT / "colab" / "bootstrap.py"))["run_stage"]
    if exit_code:
        with pytest.raises(RuntimeError, match="<error> \\[REDACTED\\]"):
            run_stage(sys.executable, work, "session.json", "prepare")
    else:
        run_stage(sys.executable, work, "session.json", "prepare")
    output = capsys.readouterr().out
    assert len(displays) == 2
    assert [len(handle.updates) for handle in displays] == [3, 3]
    assert "original, server=EU2" in displays[0].updates[0]
    assert "Deepfakes, server=EU2" in displays[1].updates[0]
    assert 'value="100"' in displays[0].updates[-1]
    assert "&lt;00:02" in displays[0].updates[-1]
    assert "10%|" not in output
    assert "<error> [REDACTED]" in output
    log = next((work / "logs").glob("prepare-*.log")).read_text(encoding="utf-8")
    assert log.count("%|###|") == 6
    assert "<error> [REDACTED]" in log
    assert "fixture-secret-12345" not in log + output + repr(displays[0].updates)


def test_terminal_progress_updates_inline(monkeypatch, capsys):
    monkeypatch.setitem(sys.modules, "IPython", None)
    renderer = runpy.run_path(str(ROOT / "colab" / "bootstrap.py"))["StageOutput"]()
    renderer.write("  0%|          | 0/100 [00:00<?, ?it/s]\n")
    renderer.write("100%|##########| 100/100 [00:10<00:00, 10it/s]\n")
    renderer.write("Finished\n")
    output = capsys.readouterr().out
    assert output.count("\r") == 2
    assert output.count("\n") == 2
    assert output.endswith("\nFinished\n")
