import ast
import copy
import json
import io
from pathlib import Path
import zipfile
import types
import runpy
import sys
from urllib.error import URLError

import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import roc_auc_score
import torch

from experiments.cache import (SyntheticDetector, materialize, preprocess, process_video)
from experiments.common import ROOT, VARIANTS, atomic_json, load_config, read_json, scratch_directory, sha256
from experiments.data import (audit_manifest, build_celebdf_manifest, build_ffpp_manifest,
                              build_uadfv_manifest, download_kaggle_dataset, extract_archive, fetch, ffpp_splits, prepare, read_csv)
from experiments.evaluation import (aggregate_videos, delong_paired, ensemble, evaluate_one, holm,
                                    paired, paired_bootstrap, summarize)
from experiments.models import build_experiment_model, encoder_hash, parameter_counts
from experiments.smoke import TinyEncoder, create_fixture
from experiments.training import ensure_best, train_one


@pytest.fixture
def tmp_path():
    # Inherited Windows ACLs, unlike Python 3.14 mkdtemp mode 0700 in this host.
    with scratch_directory(ROOT / "experiment-output", "pytest-") as path:
        yield path


@pytest.fixture
def config(tmp_path):
    torch.set_num_threads(2)
    return load_config(create_fixture(tmp_path / "fixture"))


@pytest.mark.parametrize("exit_code", [0, 7])
def test_colab_subprocess_output_is_visible_and_persistent(tmp_path, capsys, exit_code):
    project = tmp_path / "project"
    module = project / "experiments"
    module.mkdir(parents=True)
    (module / "__init__.py").write_text("")
    (module / "__main__.py").write_text(
        "import sys\nprint('download started', flush=True)\n"
        "print('HTTP Error 403: Forbidden', file=sys.stderr, flush=True)\n"
        f"sys.exit({exit_code})\n")
    run_stage = runpy.run_path(str(ROOT / "colab" / "bootstrap.py"))["run_stage"]
    kwargs = {"drive_root": tmp_path / "drive"}
    if exit_code:
        with pytest.raises(RuntimeError, match="HTTP Error 403"):
            run_stage(sys.executable, project, "session.json", "prepare", **kwargs)
    else:
        run_stage(sys.executable, project, "session.json", "prepare", **kwargs)
    output = capsys.readouterr().out
    assert "download started" in output and "HTTP Error 403" in output
    logs = list((tmp_path / "drive" / "logs").glob("prepare-*.log"))
    assert len(logs) == 1
    assert logs[0].read_text(encoding="utf-8").splitlines() == [
        "download started", "HTTP Error 403: Forbidden"]


def test_ffpp_refused_eu_uses_official_eu2(monkeypatch):
    import experiments.data as acquisition
    requested = []
    class Reply:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self, size): return json.dumps([["000", "001"]] * 500).encode()
    def open_mirror(request, timeout):
        requested.append(request.full_url)
        if "canis" in request.full_url:
            raise URLError(ConnectionRefusedError(111, "Connection refused"))
        return Reply()
    monkeypatch.setattr(acquisition, "urlopen", open_mirror)
    assert acquisition.choose_ffpp_server({"server": "EU"}) == "EU2"
    assert len(requested) == 2 and "kaldir" in requested[-1]


def test_ffpp_does_not_accept_invalid_mirror_html(monkeypatch):
    import experiments.data as acquisition
    class Reply:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self, size): return b'<html>Service unavailable</html>'
    monkeypatch.setattr(acquisition, "urlopen", lambda *a, **k: Reply())
    with pytest.raises(RuntimeError, match="No reachable official"):
        acquisition.choose_ffpp_server({})


def test_ffpp_failed_method_resumes_other_mirror_without_repeating_completed_methods(monkeypatch, tmp_path):
    import experiments.data as acquisition
    runs = []
    selections = []
    def select(source, rejected=()):
        selections.append(list(rejected))
        return "EU2" if "EU2" not in rejected else "EU"
    def run(command, **kwargs):
        method, server = command[command.index('-d')+1], command[-1]
        runs.append((method, server))
        assert kwargs['input'] == 'y\n'
        return types.SimpleNamespace(returncode=int(method == "Deepfakes" and server == "EU2"))
    monkeypatch.setattr(acquisition, "choose_ffpp_server", select)
    monkeypatch.setattr(acquisition.subprocess, "run", run)
    acquisition.download_ffpp('official.py', tmp_path, {})
    assert runs[:3] == [('original','EU2'),('Deepfakes','EU2'),('Deepfakes','EU')]
    assert sum(m == 'original' for m,s in runs) == 1
    assert len(runs) == 7 and selections == [[], ['EU2']]


def test_official_source_pair_assignments(config):
    assignments, groups = ffpp_splits(config["data"]["ffpp_splits_dir"])
    assert assignments["000"] == assignments["001"] == "train"
    assert groups["000"] == groups["001"]
    assert groups["002"] != groups["000"]


def test_reject_overlapping_sources(config):
    atomic_json(Path(config["data"]["ffpp_splits_dir"]) / "test.json", [["000", "005"]])
    with pytest.raises(ValueError, match="overlapping"):
        ffpp_splits(config["data"]["ffpp_splits_dir"])


def test_reject_cross_pair_manipulation(config):
    raw = Path(config["data"]["raw_root"]) / "ffpp"
    path = raw / "Deepfakes" / "000_001.mp4"
    path.rename(path.with_name("000_002.mp4"))
    with pytest.raises(ValueError, match="Cross-split"):
        build_ffpp_manifest(raw, config["data"]["ffpp_splits_dir"], smoke=True)


def test_missing_method_cannot_silently_reduce_suite(config):
    raw = Path(config["data"]["raw_root"]) / "ffpp"
    for path in (raw / "FaceShifter").glob("*.mp4"):
        path.unlink()
    with pytest.raises(ValueError, match="FaceShifter"):
        build_ffpp_manifest(raw, config["data"]["ffpp_splits_dir"], smoke=True)


def test_celebdf_reverse_labels_and_membership(config):
    rows = build_celebdf_manifest(Path(config["data"]["raw_root"]) / "celebdf", smoke=True)
    assert {r["label"] for r in rows if r["method"] == "Celeb-real"} == {0}
    assert {r["label"] for r in rows if r["method"] == "Celeb-synthesis"} == {1}
    assert all(r["split"] == "test" and not r["grouping_verified"] for r in rows)


def test_missing_celebdf_test_video_fails(config):
    raw = Path(config["data"]["raw_root"]) / "celebdf"
    next((raw / "Celeb-real").glob("*.mp4")).unlink()
    with pytest.raises(FileNotFoundError):
        build_celebdf_manifest(raw, smoke=True)


def test_uadfv_pairs_share_group(config):
    rows = build_uadfv_manifest(Path(config["data"]["raw_root"]) / "uadfv", smoke=True)
    assert len({r["group_id"] for r in rows}) == 2
    assert all(r["grouping_verified"] for r in rows)


@pytest.mark.parametrize("member", ["../outside", "/absolute", "C:/outside", "..\\outside"])
def test_archive_path_traversal_rejected(tmp_path, member):
    packed = tmp_path / "bad.zip"
    with zipfile.ZipFile(packed, "w") as zipped:
        zipped.writestr(member, "bad")
    with pytest.raises(ValueError):
        extract_archive(packed, tmp_path / "extract")


def test_local_archive_fetch_checks_integrity(tmp_path):
    source = tmp_path / "source.zip"
    source.write_bytes(b"example")
    target = fetch(str(source), tmp_path / "download.archive", sha256(source))
    assert target.read_bytes() == b"example"
    with pytest.raises(ValueError, match="checksum"):
        fetch(str(source), target, "0" * 64)


@pytest.mark.parametrize("status", [200, 206])
def test_http_resume_handles_range_and_ignored_range(tmp_path, monkeypatch, status):
    from experiments.common import fingerprint
    source = "https://example.invalid/test-fixture.zip"  # Never contacted.
    target = tmp_path / "file.archive"
    (tmp_path / "file.archive.part").write_bytes(b"abc")
    (tmp_path / "file.archive.part-source").write_text(fingerprint(source))
    class Response(io.BytesIO):
        headers = {"Content-Range": "bytes 3-5/6"} if status == 206 else {}
    response = Response(b"def" if status == 206 else b"abcdef")
    response.status = status
    monkeypatch.setattr("experiments.data.urlopen", lambda *a, **k: response)
    assert fetch(source, target).read_bytes() == b"abcdef"


def test_short_video_unique_frames_and_zero_faces(config, tmp_path):
    rows = build_uadfv_manifest(Path(config["data"]["raw_root"]) / "uadfv", smoke=True)
    settings = dict(config["data"], eval_frames=50)
    frames, coverage = process_video(rows[0], tmp_path / "crops", settings, SyntheticDetector())
    assert len(frames) == 2 and len({r["frame_index"] for r in frames}) == 2
    class NoFace:
        def largest_face(self, image):
            return None
    frames, coverage = process_video(rows[0], tmp_path / "none", settings, NoFace())
    assert frames == [] and coverage["status"] == "NO_CROPS" and coverage["no_face"] == 2


def test_shards_restore_and_resume(config):
    prepare(config)
    first = preprocess(config)
    checksums = [s["sha256"] for entry in first["datasets"].values() for s in entry["shards"]]
    second = preprocess(config)
    assert checksums == [s["sha256"] for entry in second["datasets"].values() for s in entry["shards"]]
    frames, coverage, _ = materialize(config)
    assert len(frames) == 88 and len(coverage) == 44
    assert all(Path(r["local_path"]).is_file() for r in frames)
    assert materialize(config)[0] == frames


def test_corrupt_drive_shard_is_rejected(config):
    from experiments.cache import cache_info
    prepare(config)
    preprocess(config)
    cache, index = cache_info(config)
    shard = cache / index["datasets"]["ffpp"]["shards"][0]["path"]
    shard.write_bytes(b"corrupt")
    with pytest.raises(ValueError, match="checksum mismatch"):
        materialize(config)


def predictions():
    rows = []
    for video, label, score in [("a", 0, .1), ("b", 0, .35), ("c", 1, .6), ("d", 1, .8)]:
        for frame, probability in enumerate((score, score + .1)):
            rows.append(dict(dataset="celebdf", video_id=video, crop_path=f"{video}/{frame}.jpg",
                             label=label, probability=probability, group_id=video,
                             grouping_verified=0, method="real" if label == 0 else "fake"))
    return pd.DataFrame(rows)


def test_aggregation_and_ensemble_use_same_memberships():
    frame = predictions()
    videos = aggregate_videos(frame)
    assert videos.frames.eq(2).all()
    assert videos.probability.iloc[0] == pytest.approx(.15)
    other = frame.copy()
    other.probability *= .5
    combined = ensemble(frame, other)
    assert np.allclose(combined.probability, frame.probability * .75)
    with pytest.raises(ValueError, match="memberships"):
        ensemble(frame, other.iloc[:-1])


def test_metadata_inconsistent_frames_rejected():
    frame = predictions()
    frame.loc[0, "label"] = 1
    with pytest.raises(ValueError, match="metadata"):
        aggregate_videos(frame)


def test_delong_matches_auc_and_is_symmetric():
    rng = np.random.default_rng(7)
    labels = np.array([0] * 30 + [1] * 30)
    a, b = rng.normal(labels, .8), rng.normal(labels * .7, .9)
    result = delong_paired(labels, a, b)
    inverse = delong_paired(labels, b, a)
    assert result["delta_auc"] == pytest.approx(roc_auc_score(labels, a) - roc_auc_score(labels, b))
    assert result["p_nominal"] == pytest.approx(inverse["p_nominal"])
    assert delong_paired(labels, a, a)["p_nominal"] == 1
    assert delong_paired([0, 1], [0, 1], [1, 0])["p_nominal"] is None


def test_delong_covariance_against_direct_pairwise_definition():
    from scipy.stats import norm
    labels = np.array([0, 1, 0, 1, 0, 1, 0, 1])
    a = np.array([.2, .7, .6, .5, .3, .6, .1, .8])
    b = np.array([.3, .6, .2, .7, .8, .4, .1, .5])
    placement_pos, placement_neg = [], []
    for scores in (a, b):
        positive, negative = scores[labels == 1], scores[labels == 0]
        matrix = (positive[:, None] > negative[None, :]).astype(float)
        matrix += .5 * (positive[:, None] == negative[None, :])
        placement_pos.append(matrix.mean(axis=1))
        placement_neg.append(matrix.mean(axis=0))
    covariance = np.cov(placement_pos) / 4 + np.cov(placement_neg) / 4
    delta = roc_auc_score(labels, a) - roc_auc_score(labels, b)
    variance = np.array([1., -1.]) @ covariance @ np.array([1., -1.])
    expected = 2 * norm.sf(abs(delta) / np.sqrt(variance))
    assert delong_paired(labels, a, b)["p_nominal"] == pytest.approx(expected)


def test_holm_keeps_full_preplanned_family():
    assert holm([.01, .04, .03, .002]) == pytest.approx([.03, .06, .06, .008])
    assert holm([.01, None, None, None]) == [.04, None, None, None]


def test_bootstrap_explicitly_flags_unverified_groups():
    frame = aggregate_videos(predictions())
    result = paired_bootstrap([(frame, frame)], reps=40)
    assert result["mean_delta_auc"] == 0 and result["ci95"] == [0, 0]
    assert not result["grouping_verified"] and "EXPLORATORY" in result["interpretation"]


def test_variants_share_initial_encoder_and_matched_heads(config):
    built = {}
    for variant in VARIANTS:
        model = build_experiment_model(variant, config, 42, pretrained=False, encoder_factory=TinyEncoder)
        model.eval()
        with torch.inference_mode():
            assert model(torch.zeros(2, 3, 224, 224)).shape == (2,)
        built[variant] = model
    assert len({encoder_hash(m) for m in built.values() if hasattr(m, "encoder")}) == 1
    assert all(not p.requires_grad for m in built.values() if hasattr(m, "encoder") for p in m.encoder.vit.parameters())
    assert not hasattr(built["cnn_only"], "encoder")
    assert not hasattr(built["favit_matched"], "cnn")
    assert torch.equal(built["favit_matched"].classifier[-1].weight, built["favit_capacity"].classifier[-1].weight)
    assert all(torch.equal(value, built["favit_cnn"].cnn.state_dict()[name])
               for name, value in built["cnn_only"].cnn.state_dict().items())
    assert parameter_counts(built["cnn_only"].cnn)["trainable"] == 258304


def test_resume_equals_continuous_training(config, tmp_path):
    prepare(config)
    preprocess(config)
    frames, coverage, index = materialize(config)
    config["training"]["variants"] = ["favit_matched"]
    factory = lambda: build_experiment_model("favit_matched", config, 42, pretrained=False, encoder_factory=TinyEncoder)
    train_one(config, "favit_matched", 42, frames, index, model_factory=factory, epochs_override=1)
    run = Path(config["drive_root"]) / "runs" / "favit_matched" / "seed-42"
    assert read_json(run / "state.json")["status"] == "interrupted"
    train_one(config, "favit_matched", 42, frames, index, model_factory=factory)
    resumed = torch.load(run / "last.pt", map_location="cpu", weights_only=False)
    other = copy.deepcopy(config)
    other["drive_root"] = str(tmp_path / "continuous-smoke-drive")
    train_one(other, "favit_matched", 42, frames, index, model_factory=factory)
    continuous = torch.load(Path(other["drive_root"]) / "runs/favit_matched/seed-42/last.pt", map_location="cpu", weights_only=False)
    assert resumed["history"] == continuous["history"]
    assert resumed["scheduler"] == continuous["scheduler"]
    assert all(torch.equal(value, continuous["model"][name]) for name, value in resumed["model"].items())
    evaluate_one(config, "favit_matched", 42, frames, coverage, index, model_factory=factory)
    assert (run / "evaluation/video-predictions.csv").is_file()
    missing = copy.deepcopy(coverage)
    next(r for r in missing if r["split"] == "test")["saved_frames"] = 0
    with pytest.raises(ValueError, match="no crops"):
        evaluate_one(config, "favit_matched", 42, frames, missing, index, model_factory=factory)
    altered = copy.deepcopy(config)
    altered["training"]["label_smoothing"] = .1
    with pytest.raises(ValueError, match="mismatch"):
        train_one(altered, "favit_matched", 42, frames, index, model_factory=factory)


def test_best_publication_can_recover_committed_candidate(tmp_path):
    (tmp_path / "best.pt").write_bytes(b"old")
    staged = tmp_path / ".best-candidate.pt"
    staged.write_bytes(b"new")
    expected = sha256(staged)
    ensure_best(tmp_path, expected)
    assert (tmp_path / "best.pt").read_bytes() == b"new" and not staged.exists()


def test_notebooks_are_valid_and_every_code_cell_compiles():
    for path in (ROOT / "colab").glob("*.ipynb"):
        notebook = json.loads(path.read_text(encoding="utf-8"))
        assert notebook["nbformat"] == 4 and len(notebook["cells"]) >= 10
        assert len({cell["id"] for cell in notebook["cells"]}) == len(notebook["cells"])
        for cell in notebook["cells"]:
            if cell["cell_type"] == "code":
                ast.parse(cell["source"])
                assert cell["outputs"] == []


def test_default_sources_are_preconfigured():
    import yaml
    config = yaml.safe_load((ROOT / "colab/experiment_config.yaml").read_text(encoding="utf-8"))
    assert config["sources"]["ffpp"]["script"] == "https://kaldir.vc.in.tum.de/faceforensics_download_v4.py"
    assert "1iLx76wsbi9itnkxSqz9BVBl4ZvnbIazj" in config["sources"]["celebdf"]["source"]
    assert config["sources"]["uadfv"]["provider"] == "kagglehub"
    assert config["sources"]["uadfv"]["handle"] == "adityakeshri9234/uadfv-dataset"
    assert config["sources"]["ffpp"]["accepted_terms"] is False


def mock_kaggle(monkeypatch, folder, calls):
    import importlib.metadata
    import sys
    def download(handle):
        calls.append(handle)
        return str(folder)
    monkeypatch.setitem(sys.modules, "kagglehub", types.SimpleNamespace(dataset_download=download))
    original_version = importlib.metadata.version
    monkeypatch.setattr(importlib.metadata, "version", lambda name: "1.0.3" if name == "kagglehub" else original_version(name))


def test_kagglehub_source_prepares_video_manifest_without_copying_raw(config, monkeypatch):
    from experiments.common import public_config
    import shutil
    local, drive = Path(config["local_root"]), Path(config["drive_root"])
    downloaded = local / "kagglehub-cache/datasets/adityakeshri9234/uadfv-dataset/versions/7"
    shutil.copytree(Path(config["data"]["raw_root"]) / "uadfv", downloaded / "UADFV")
    for video in (downloaded / "UADFV/fake").glob("*.mp4"):
        video.rename(video.with_stem(video.stem + "_fake"))
    cached_frame = downloaded / "UADFV/fake/frames/0000_fake/001.png"
    cached_frame.parent.mkdir(parents=True)
    cached_frame.write_bytes(b"preexisting Kaggle frame; not a raw video")
    calls = []
    mock_kaggle(monkeypatch, downloaded, calls)
    config["sources"]["uadfv"] = {"provider": "kagglehub", "handle": "adityakeshri9234/uadfv-dataset"}
    prepare(config, ["uadfv"])
    rows = read_csv(local / "manifests/videos-uadfv.csv")
    assert len(rows) == 4 and all("kagglehub-cache" in r["raw_path"] for r in rows)
    assert {r["grouping_verified"] for r in rows} == {"1"}
    provenance = read_json(drive / "manifests/uadfv-kaggle-source.json")
    assert provenance["resolved_handle"].endswith("/versions/7") and provenance["validated_videos"] == 4
    prepare(config, ["uadfv"])
    assert calls == ["adityakeshri9234/uadfv-dataset", "adityakeshri9234/uadfv-dataset/versions/7"]
    assert public_config(config)["sources"]["uadfv"]["configured"]


def test_kaggle_archive_override_does_not_contact_kaggle(config, tmp_path, monkeypatch):
    packed = tmp_path / "uadfv.zip"
    raw = Path(config["data"]["raw_root"])
    with zipfile.ZipFile(packed, "w") as zipped:
        for path in (raw / "uadfv").rglob("*.mp4"):
            zipped.write(path, path.relative_to(raw / "uadfv"))
    config["data"]["raw_root"] = str(tmp_path / "archive-raw")
    config["sources"]["uadfv"] = {"provider": "kagglehub", "handle": "unused/source", "source": str(packed)}
    def unexpected(*args):
        raise AssertionError("Archive override must not invoke KaggleHub")
    monkeypatch.setattr("experiments.data.download_kaggle_dataset", unexpected)
    prepare(config, ["uadfv"])
    assert len(read_csv(Path(config["local_root"]) / "manifests/videos-uadfv.csv")) == 4


def test_kaggle_auth_error_has_actionable_message_without_secrets(config, monkeypatch):
    import sys
    def unauthorized(handle):
        raise RuntimeError("secret-credential-must-not-be-printed")
    monkeypatch.setitem(sys.modules, "kagglehub", types.SimpleNamespace(dataset_download=unauthorized))
    with pytest.raises(RuntimeError, match="KAGGLE_API_TOKEN") as error:
        download_kaggle_dataset({"handle": "owner/dataset"}, "uadfv", config["drive_root"], config["local_root"])
    assert "secret-credential" not in str(error.value)


def test_smoke_fixture_never_uses_real_source_defaults(config):
    assert config["sources"] == {}


def test_two_supplemental_runs_summarize_without_retraining_dual(config):
    config["training"]["variants"] = ["favit_matched", "cnn_only"]
    prepare(config)
    preprocess(config)
    frames, coverage, index = materialize(config)
    for variant in config["training"]["variants"]:
        factory = lambda variant=variant: build_experiment_model(
            variant, config, 42, pretrained=False, encoder_factory=TinyEncoder)
        train_one(config, variant, 42, frames, index, model_factory=factory)
        evaluate_one(config, variant, 42, frames, coverage, index, model_factory=factory)
    summarize(config)
    drive = Path(config["drive_root"])
    progress = read_json(drive / "summaries" / "progress.json")
    assert progress["complete"] and progress["expected_runs"] == progress["measured_runs"] == 2
    assert {p.name for p in (drive / "runs").iterdir()} == {"favit_matched", "cnn_only"}
    assert (drive / "summaries" / "ensemble-seed-42.csv").is_file()
    report = (drive / "summaries" / "REPORT-VI.md").read_text(encoding="utf-8")
    assert "chưa có cặp FA-ViT-CNN/matched-head" in report
    assert "N/A (chỉ một seed)" in report
